# School Schedule Manager — Mac version

The schedule overlay from the Windows app (`code.py` + `school_schedule.py`), rebuilt for macOS.
It sits in the bottom-left corner above the Dock, shows the current class, a progress bar and
what's next, and expands when you hover over it.

## Start it

**Easiest:** run `./make_app.sh` once in Terminal (from this folder). That creates
**School Schedule.app** in your home folder's Applications folder. Double-click it to start the overlay.
To start it every time you log in, add it under **System Settings → General → Login Items**.

**From Terminal:** `./run.sh` (the first run downloads what it needs, about 15 MB).

A clock icon appears in the menu bar. It's the overlay's **on/off button**: click it to turn the
overlay off (the icon gets an ✕), click again to turn it back on.
**Right-click** it (or two-finger click / Control-click) for the menu: Homework, Edit Classes,
Settings, Advisory Days on or off, and Quit.

## Using the overlay

1. **Hover** over the overlay for 1 second to expand it (timeline of today's classes).
2. Hover over **Focus** (top right) for 1 second to make it clickable.
3. Now the top buttons are **Homework** (left) and **Settings** (right). Click them.
   - **Homework:** today's homework with check boxes. Click a row to check it off.
     Unchecked homework from earlier days shows in red ("late") until you check it.
   - **Settings:** the same list as on Windows, plus **Advisory Days: On/Off**.
4. Move the mouse away and it shrinks back and becomes click-through again.

Hovering over **Hide (10s)** (top left, before Focus) hides the overlay for 10 seconds, same as on Windows.

## Settings and homework pages

The settings windows open as a page in your web browser. This Mac's built-in Python ships an
old Tk that freezes, so the Windows version's Tk windows can't run here. The page only works
on this computer while the app is running.

- **Homework:** pick the class, type the homework, and pick when it's **due**: click a date in the
  calendar box or a quick button (Today, Tomorrow, or a weekday), and whether it's due
  **🏫 In class** or **🌙 At night** (just a label; it remembers your last pick). Homework due later shows in
  today's list as "due Fri" until you check it. Click **Edit** to change the text, class or due date.
  If it isn't checked off by its due date, that day shows a red ✗ and it stays in your list as "late".
- **Events:** after-school events (practice, clubs, games) with a start and end time, on one
  date or repeating on chosen weekdays. On school days the overlay shows **Free Time** counting down
  to the event after your last class, then the event itself with how much time is left.
- **Classes:** class names, icons (with live previews), colors and lunch waves.
- **Settings:** advisory on/off and which weekday, transparency, time format, size.
- **Style**, **Yearly Info** (import code), **Raw Config**, **About**: same as the Windows menus.

## Where things are saved

`~/Library/Application Support/WHSSchoolScheduleManager/`
(`config.json`, `default.config.json`, `homework.json`, and `app.log` when started from the app).

## Files

| File | What it is |
| --- | --- |
| `main.py` | The overlay (ported from `code.py`) |
| `school_schedule.py` | Schedule logic, unchanged from the Windows version |
| `mac_platform.py` | Mac window tricks, menu bar icon, message boxes |
| `web_settings.py`, `web/index.html` | The settings + homework page |
| `homework.py` | Homework list and the ✓ / ✗ / late rules |
| `default_config.py` | Builds the default config on first launch |
| `icons.py` | Lucide icons |
| `resources/` | JetBrains Mono font (SIL Open Font License) |

Developer option: `SSM_SNAPSHOT_DIR=/some/folder ./run.sh` saves PNGs of each overlay view and quits.
