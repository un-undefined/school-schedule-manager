"""macOS replacements for the Windows-only parts of the app.

  Windows (code.py)                        Mac (this file)
  ---------------------------------------  ----------------------------------------
  win32gui WS_EX_LAYERED + color key        non-opaque NSWindow, rounded layer mask
  WS_EX_TRANSPARENT (click-through)         NSWindow.setIgnoresMouseEvents_
  WS_EX_TOOLWINDOW (no taskbar button)      accessory app (no Dock icon)
  HWND_TOPMOST                              status-level window on every Space
  win32gui.GetCursorInfo                    NSEvent.mouseLocation
  pystray tray icon                         menu bar icon (NSStatusItem)
  tkinter message windows                   NSAlert

Everything degrades to a no-op when there is no real window (for example when
running with SDL_VIDEODRIVER=dummy for tests).
"""

import os
import sys
import traceback

try:
    import objc
    import AppKit
    from Foundation import NSObject
    HAVE_APPKIT = True
except ImportError:  # pragma: no cover - only without PyObjC
    HAVE_APPKIT = False
    NSObject = object


def _app():
    return AppKit.NSApplication.sharedApplication() if HAVE_APPKIT else None


def make_accessory_app():
    """No Dock icon / Cmd-Tab entry, like the hidden taskbar button on Windows."""
    if HAVE_APPKIT:
        _app().setActivationPolicy_(AppKit.NSApplicationActivationPolicyAccessory)


def activate_app():
    if not HAVE_APPKIT:
        return
    app = _app()
    if hasattr(app, "activate"):
        try:
            app.activate()
            return
        except Exception:
            pass
    app.activateIgnoringOtherApps_(True)


def overlay_start_position(width, height, margin=6):
    """Top-left corner (SDL coordinates, points) for the bottom-left of the screen, above the Dock."""
    if HAVE_APPKIT:
        screens = AppKit.NSScreen.screens()
        if screens and len(screens) > 0:
            primary = screens[0]
            full = primary.frame()
            visible = primary.visibleFrame()
            x = visible.origin.x + margin
            bottom = full.size.height - visible.origin.y - margin
            return int(x), int(bottom - height)
    return margin, 800 - height


class OverlayWindow:
    """Native handle for the pygame window."""

    def __init__(self, title):
        self.ns = None
        if HAVE_APPKIT:
            for w in _app().windows():
                if str(w.title()) == title:
                    self.ns = w
                    break

    @property
    def ok(self):
        return self.ns is not None

    def setup(self):
        if not self.ok:
            return
        w = self.ns
        w.setOpaque_(False)
        w.setBackgroundColor_(AppKit.NSColor.clearColor())
        w.setHasShadow_(False)
        w.setLevel_(AppKit.NSStatusWindowLevel)
        w.setCollectionBehavior_(
            AppKit.NSWindowCollectionBehaviorCanJoinAllSpaces
            | AppKit.NSWindowCollectionBehaviorStationary
            | AppKit.NSWindowCollectionBehaviorFullScreenAuxiliary
            | AppKit.NSWindowCollectionBehaviorIgnoresCycle
        )
        view = w.contentView()
        view.setWantsLayer_(True)
        view.layer().setMasksToBounds_(True)

    def set_corner_radius(self, radius_points):
        if self.ok:
            self.ns.contentView().layer().setCornerRadius_(float(radius_points))

    def set_ignores_mouse(self, ignore):
        if self.ok:
            self.ns.setIgnoresMouseEvents_(bool(ignore))

    def show(self):
        if self.ok:
            self.ns.orderFrontRegardless()  # show without stealing focus from the app you're using

    def hide(self):
        if self.ok:
            self.ns.orderOut_(None)

    def set_frame_keep_bottom(self, width, height):
        """Resize while keeping the bottom edge still (Cocoa's origin is bottom-left)."""
        if self.ok:
            f = self.ns.frame()
            self.ns.setFrame_display_(AppKit.NSMakeRect(f.origin.x, f.origin.y, width, height), True)

    def mouse_relative(self):
        """Mouse position in points relative to the window's top-left, or None."""
        if not self.ok:
            return None
        m = AppKit.NSEvent.mouseLocation()
        f = self.ns.frame()
        return m.x - f.origin.x, (f.origin.y + f.size.height) - m.y


# - menu bar icon -
class _MenuTarget(NSObject):
    def fire_(self, sender):
        # an exception escaping into Objective-C would crash the app, so catch it here
        try:
            callback = self.callbacks.get(int(sender.tag()))
            if callback is not None:
                callback()
        except Exception:
            traceback.print_exc()

    def menuNeedsUpdate_(self, menu):
        try:
            if self.on_update is not None:
                self.on_update()
        except Exception:
            traceback.print_exc()

    def statusClicked_(self, sender):
        # left click = on/off, right-click (or Control-click) = the menu
        try:
            event = AppKit.NSApp.currentEvent()
            menu_click = event is not None and (
                event.type() == AppKit.NSEventTypeRightMouseUp
                or bool(event.modifierFlags() & AppKit.NSEventModifierFlagControl))
            if menu_click or self.on_click is None:
                self.owner.show_menu()
            else:
                self.on_click()
        except Exception:
            traceback.print_exc()


class StatusItem:
    """The clock icon in the menu bar (the Windows version's tray icon).

    items: list of (title, callback) tuples, or None for a separator line.
    on_update: called right before the menu opens, to refresh enabled/checked states.
    on_click: if given, clicking the icon calls this (the overlay on/off button) and
              right-click / Control-click opens the menu instead.
    """

    def __init__(self, tooltip, items, on_update=None, on_click=None):
        self.item = None
        self.menu_items = {}
        if not HAVE_APPKIT:
            return
        self.target = _MenuTarget.alloc().init()
        self.target.callbacks = {}
        self.target.on_update = on_update
        self.target.on_click = on_click
        self.target.owner = self

        bar = AppKit.NSStatusBar.systemStatusBar()
        self.item = bar.statusItemWithLength_(AppKit.NSVariableStatusItemLength)
        self.tooltip = tooltip
        self.set_on(True)

        menu = AppKit.NSMenu.alloc().initWithTitle_(tooltip)
        menu.setAutoenablesItems_(False)
        for tag, entry in enumerate(items, start=1):
            if entry is None:
                menu.addItem_(AppKit.NSMenuItem.separatorItem())
                continue
            title, callback = entry
            mi = AppKit.NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(title, "fire:", "")
            mi.setTarget_(self.target)
            mi.setTag_(tag)
            self.target.callbacks[tag] = callback
            self.menu_items[title] = mi
            menu.addItem_(mi)
        menu.setDelegate_(self.target)
        self.menu = menu
        if on_click is None:
            self.item.setMenu_(menu)
        else:
            button = self.item.button()
            button.setTarget_(self.target)
            button.setAction_("statusClicked:")
            button.sendActionOn_(AppKit.NSEventMaskLeftMouseUp | AppKit.NSEventMaskRightMouseUp)

    def show_menu(self):
        if self.item is None:
            return
        self.item.setMenu_(self.menu)      # attach the menu just long enough to open it
        self.item.button().performClick_(None)
        self.item.setMenu_(None)

    def set_on(self, on):
        """Clock icon when the overlay is on, clock with an X when it's off."""
        if self.item is None:
            return
        button = self.item.button()
        image = AppKit.NSImage.imageWithSystemSymbolName_accessibilityDescription_("clock" if on else "clock.badge.xmark", self.tooltip)
        if image is not None:
            image.setTemplate_(True)
            button.setImage_(image)
        else:
            button.setTitle_("⏰" if on else "⏰✕")
        state = "on" if on else "off"
        button.setToolTip_("%s (overlay is %s)\nClick: turn the overlay %s\nRight-click: menu" % (self.tooltip, state, "off" if on else "on"))

    def set_enabled(self, title, enabled):
        mi = self.menu_items.get(title)
        if mi is not None:
            mi.setEnabled_(bool(enabled))

    def set_checked(self, title, checked):
        mi = self.menu_items.get(title)
        if mi is not None:
            mi.setState_(AppKit.NSControlStateValueOn if checked else AppKit.NSControlStateValueOff)

    def remove(self):
        if self.item is not None:
            AppKit.NSStatusBar.systemStatusBar().removeStatusItem_(self.item)
            self.item = None


# - message boxes (replace the Tk popups) -
def alert(title, text, buttons=("OK",), details=None, warning=False):
    """Show a native alert. Returns the index of the button that was clicked.

    The first button is the default (Return key) and appears on the right.
    details: long text (like a traceback) shown in a scrollable, selectable box.
    """
    if not HAVE_APPKIT or os.environ.get("SSM_SNAPSHOT_DIR"):  # tests: print instead of waiting for a click
        print("\n== %s ==\n%s\n%s" % (title, text, details or ""), file=sys.stderr)
        return 0
    activate_app()
    a = AppKit.NSAlert.alloc().init()
    a.setMessageText_(title)
    a.setInformativeText_(text)
    a.setAlertStyle_(AppKit.NSAlertStyleWarning if warning else AppKit.NSAlertStyleInformational)
    for b in buttons:
        a.addButtonWithTitle_(b)
    if details:
        scroll = AppKit.NSScrollView.alloc().initWithFrame_(AppKit.NSMakeRect(0, 0, 460, 180))
        scroll.setHasVerticalScroller_(True)
        scroll.setBorderType_(AppKit.NSBezelBorder)
        text_view = AppKit.NSTextView.alloc().initWithFrame_(AppKit.NSMakeRect(0, 0, 445, 180))
        text_view.setEditable_(False)
        text_view.setSelectable_(True)
        text_view.setFont_(AppKit.NSFont.monospacedSystemFontOfSize_weight_(10.5, 0.0))
        text_view.setString_(details)
        scroll.setDocumentView_(text_view)
        a.setAccessoryView_(scroll)
    a.layout()
    a.window().setLevel_(AppKit.NSStatusWindowLevel + 1)  # above the overlay
    response = int(a.runModal())
    return max(0, response - int(AppKit.NSAlertFirstButtonReturn))
