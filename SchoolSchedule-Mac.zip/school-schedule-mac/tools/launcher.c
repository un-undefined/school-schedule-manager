// Tiny app launcher: runs Contents/Resources/launch.sh as a child process and
// waits, so this signed binary stays the "app" macOS sees (menu bar icon rules).
#include <mach-o/dyld.h>
#include <libgen.h>
#include <limits.h>
#include <signal.h>
#include <spawn.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <stdlib.h>
extern char **environ;
static pid_t child = 0;
static void forward(int sig) { if (child > 0) kill(child, sig); }
int main(void) {
    char exe[PATH_MAX], real[PATH_MAX], script[PATH_MAX];
    uint32_t size = sizeof(exe);
    if (_NSGetExecutablePath(exe, &size) != 0 || !realpath(exe, real)) return 1;
    snprintf(script, sizeof(script), "%s/../Resources/launch.sh", dirname(real));
    char *argv[] = {"/bin/bash", script, NULL};
    signal(SIGTERM, forward); signal(SIGINT, forward); signal(SIGHUP, forward);
    if (posix_spawn(&child, "/bin/bash", NULL, NULL, argv, environ) != 0) return 1;
    int status = 0;
    while (waitpid(child, &status, 0) < 0) {}
    return WIFEXITED(status) ? WEXITSTATUS(status) : 1;
}
