"""Homework list, saved to homework.json.

Rules (what the overlay and the browser page show):
  * Each item has a due date ("date"), a class, and "due_when": "class" (due in class)
    or "night" (due at night). due_when is only a label; it never changes the rules.
  * Checking it off marks it done on the day you checked it.
  * Today's list = homework due today
                 + older homework that still isn't checked ("late")
                 + homework due later that isn't checked yet ("upcoming", e.g. "due Fri").
    Anything checked today stays visible (checked) until tomorrow.
  * Looking back at a past day: homework due that day that was checked on or
    before that day gets a check mark; everything else gets an X (with a note
    if it was finished later).

Both the overlay (main thread) and the settings web server (another thread)
use this store, so every method takes a lock.
"""

import copy
import datetime as _dt
import json
import os
import threading
import uuid

STATUS_OPEN = "open"            # today / future, not done yet
STATUS_DONE = "done"            # checked on time
STATUS_LATE = "late"            # from an earlier day, still not checked (shown today)
STATUS_LATE_DONE = "late_done"  # from an earlier day, checked today
STATUS_MISSED = "missed"        # past day, never checked -> X
STATUS_MISSED_DONE_LATER = "missed_done_later"  # past day, checked on a later day -> X + note
STATUS_UPCOMING = "upcoming"            # due on a later day, not done yet (shown today)
STATUS_UPCOMING_DONE = "upcoming_done"  # due on a later day, checked today

_ORDER = {STATUS_LATE: 0, STATUS_OPEN: 1, STATUS_UPCOMING: 2, STATUS_MISSED: 3, STATUS_MISSED_DONE_LATER: 4,
          STATUS_LATE_DONE: 5, STATUS_DONE: 6, STATUS_UPCOMING_DONE: 7}


def iso(day):
    return day.isoformat()


def parse_day(text):
    return _dt.date.fromisoformat(str(text)[:10])


DUE_WHEN = ("class", "night")  # due in class, or due at night (just a label)


def clean_due_when(value):
    if value in (None, ""):
        return None
    if value not in DUE_WHEN:
        raise ValueError("Pick \"In class\" or \"At night\".")
    return value


class HomeworkStore:
    def __init__(self, path):
        self.path = path
        self.lock = threading.RLock()
        self.items = []
        self._load()

    # - storage -
    def _load(self):
        if not os.path.exists(self.path):
            return
        try:
            with open(self.path, "r") as f:
                data = json.load(f)
            items = data.get("items", []) if isinstance(data, dict) else []
            self.items = [i for i in items if isinstance(i, dict) and "id" in i and "date" in i]
        except Exception:
            # Keep the broken file instead of overwriting the user's homework.
            os.replace(self.path, self.path + ".broken")
            self.items = []

    def _save(self):
        tmp = self.path + ".tmp"
        with open(tmp, "w") as f:
            json.dump({"version": 1, "items": self.items}, f, indent=2)
        os.replace(tmp, self.path)

    def _find(self, item_id):
        for item in self.items:
            if item["id"] == item_id:
                return item
        raise KeyError("That homework item no longer exists.")

    # - changes -
    def add(self, day, period, class_name, text, due_when=None):
        text = (text or "").strip()
        if not text:
            raise ValueError("Type what the homework is first.")
        item = {
            "id": uuid.uuid4().hex[:12],
            "date": iso(day),
            "period": str(period or ""),
            "class_name": str(class_name or ""),
            "text": text[:300],
            "due_when": clean_due_when(due_when),
            "done": False,
            "done_date": None,
            "created": _dt.datetime.now().isoformat(timespec="seconds"),
        }
        with self.lock:
            self.items.append(item)
            self._save()
            return copy.deepcopy(item)

    def set_done(self, item_id, done, today):
        with self.lock:
            item = self._find(item_id)
            item["done"] = bool(done)
            item["done_date"] = iso(today) if done else None
            self._save()
            return copy.deepcopy(item)

    def toggle(self, item_id, today):
        with self.lock:
            return self.set_done(item_id, not self._find(item_id)["done"], today)

    def edit(self, item_id, text=None, period=None, class_name=None, day=None, due_when=None):
        with self.lock:
            item = self._find(item_id)
            if text is not None:
                text = text.strip()
                if not text:
                    raise ValueError("Homework text can't be empty.")
                item["text"] = text[:300]
            if period is not None:
                item["period"] = str(period)
            if class_name is not None:
                item["class_name"] = str(class_name)
            if day is not None:
                item["date"] = iso(day)
            if due_when is not None:
                item["due_when"] = clean_due_when(due_when)
            self._save()
            return copy.deepcopy(item)

    def delete(self, item_id):
        with self.lock:
            self.items.remove(self._find(item_id))
            self._save()

    # - views -
    @staticmethod
    def status_on(item, view_day, today):
        """Status of an item when looking at view_day, or None if it isn't shown that day."""
        item_day = parse_day(item["date"])
        done = bool(item.get("done"))
        done_day = parse_day(item["done_date"]) if done and item.get("done_date") else None

        if view_day == today:
            if item_day == today:
                return STATUS_DONE if done else STATUS_OPEN
            if not done:
                return STATUS_LATE if item_day < today else STATUS_UPCOMING
            if done_day == today:
                return STATUS_LATE_DONE if item_day < today else STATUS_UPCOMING_DONE
            return None

        if item_day != view_day:
            return None
        if view_day > today:
            return STATUS_DONE if done else STATUS_OPEN
        # a past day
        if done and done_day is not None and done_day <= view_day:
            return STATUS_DONE
        return STATUS_MISSED_DONE_LATER if done else STATUS_MISSED

    def list_for(self, view_day, today):
        with self.lock:
            rows = []
            for item in self.items:
                status = self.status_on(item, view_day, today)
                if status is not None:
                    row = copy.deepcopy(item)
                    row["status"] = status
                    rows.append(row)
        rows.sort(key=lambda r: (_ORDER.get(r["status"], 9), r["date"], r.get("created", "")))
        return rows

    def days_with_items(self):
        with self.lock:
            return sorted({item["date"] for item in self.items})
