#!/bin/bash
# Builds "School Schedule.app" in ~/Applications so you can start the overlay by
# double-clicking (or add it to System Settings > General > Login Items to start
# it automatically). The app just runs run.sh from this folder, so keep this
# folder where it is (run this script again if you move it).
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
APP="$HOME/Applications/School Schedule.app"
ID="com.whs.school-schedule-manager"
LOG="$HOME/Library/Application Support/WHSSchoolScheduleManager/app.log"

rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

cat > "$APP/Contents/Resources/launch.sh" <<LAUNCH
mkdir -p "\$(dirname "$LOG")"
exec "$ROOT/run.sh" >> "$LOG" 2>&1
LAUNCH

# The app's main program is a tiny compiled launcher (tools/launcher.c) that stays
# running while the overlay is open. macOS 26 only shows menu bar icons for apps it
# can identify, and a plain script launcher gets its clock icon hidden.
BUILT=""
for SDK in "" /Library/Developer/CommandLineTools/SDKs/MacOSX26*.sdk /Library/Developer/CommandLineTools/SDKs/MacOSX15*.sdk; do
  FLAGS=(); [ -n "$SDK" ] && FLAGS=(-isysroot "$SDK")
  if clang -O2 "${FLAGS[@]}" -mmacosx-version-min=11.0 -o "$APP/Contents/MacOS/School Schedule" "$ROOT/tools/launcher.c" 2>/dev/null; then
    BUILT=1; break
  fi
done
if [ -z "$BUILT" ]; then
  echo "Note: couldn't compile the launcher, using a script instead (the menu bar icon may be hidden)."
  printf '#!/bin/bash\nexec /bin/bash "$(dirname "$0")/../Resources/launch.sh"\n' > "$APP/Contents/MacOS/School Schedule"
  chmod +x "$APP/Contents/MacOS/School Schedule"
fi

cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key>               <string>School Schedule</string>
  <key>CFBundleDisplayName</key>        <string>School Schedule</string>
  <key>CFBundleIdentifier</key>         <string>$ID</string>
  <key>CFBundleExecutable</key>         <string>School Schedule</string>
  <key>CFBundlePackageType</key>        <string>APPL</string>
  <key>CFBundleVersion</key>            <string>1.0.0</string>
  <key>CFBundleShortVersionString</key> <string>1.0.0</string>
  <key>LSMinimumSystemVersion</key>     <string>11.0</string>
  <key>LSUIElement</key>                <true/>
  <!-- if the launcher is a script, Apple Silicon Macs would ask for Rosetta (error -10669) without this -->
  <key>LSArchitecturePriority</key>     <array><string>arm64</string><string>x86_64</string></array>
</dict>
</plist>
PLIST

codesign --force --sign - --identifier "$ID" "$APP" >/dev/null 2>&1 || true

echo "Built: $APP"
echo "Double-click it in Finder (Go > Home > Applications) to start the overlay."
