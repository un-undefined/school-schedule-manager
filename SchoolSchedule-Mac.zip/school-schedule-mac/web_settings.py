"""Settings + homework pages, served to your browser from this Mac only.

The Windows version used Tk windows for settings. Apple's built-in Python ships
an old Tk that freezes on current macOS, so the same settings live on a local
web page instead (http://127.0.0.1:<port>/<secret>/).

Safety: the server only listens on 127.0.0.1, every URL needs a random secret
that is stored in the app's folder, and changes also need that secret in a
request header, so other websites open in your browser can't change anything.

Threading: the server runs on its own thread. Anything that touches pygame or
the config is handed to the main loop through MainThreadBridge.
"""

import json
import os
import queue
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
INDEX_HTML = os.path.join(HERE, "web", "index.html")
PREFERRED_PORT = 47321


class AppBusy(Exception):
    pass


class MainThreadBridge:
    """Runs functions on the pygame main loop and waits for the result."""

    def __init__(self):
        self.jobs = queue.Queue()

    def call(self, fn, timeout=6.0):
        job = {"fn": fn, "done": threading.Event(), "result": None, "error": None}
        self.jobs.put(job)
        if not job["done"].wait(timeout):
            raise AppBusy("The overlay is busy (is a message box open?). Try again in a moment.")
        if job["error"] is not None:
            raise job["error"]
        return job["result"]

    def run_pending(self):
        """Called once per frame by the main loop."""
        while True:
            try:
                job = self.jobs.get_nowait()
            except queue.Empty:
                return
            try:
                job["result"] = job["fn"]()
            except Exception as e:  # handed back to the web request
                job["error"] = e
            finally:
                job["done"].set()


def load_token(path):
    try:
        with open(path) as f:
            token = f.read().strip()
        if len(token) >= 16:
            return token
    except OSError:
        pass
    token = secrets.token_urlsafe(18)
    with open(path, "w") as f:
        f.write(token + "\n")
    os.chmod(path, 0o600)
    return token


class SettingsServer:
    """routes: {"GET": {path: fn(query)}, "POST": {path: fn(body)}}; fn returns a JSON-able value.
    raw_routes: {path: fn(query) -> (content_type, bytes)} for non-JSON GETs (icons)."""

    def __init__(self, token, routes, raw_routes):
        self.token = token
        self.routes = routes
        self.raw_routes = raw_routes
        self.httpd = None
        self.port = None

    def start(self):
        handler = self._make_handler()
        for port in (PREFERRED_PORT, 0):
            try:
                self.httpd = ThreadingHTTPServer(("127.0.0.1", port), handler)
                break
            except OSError:
                continue
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        threading.Thread(target=self.httpd.serve_forever, name="settings-web", daemon=True).start()
        return self

    def url(self, page=""):
        return "http://127.0.0.1:%d/%s/%s" % (self.port, self.token, ("#" + page) if page else "")

    def stop(self):
        if self.httpd is not None:
            self.httpd.shutdown()
            self.httpd.server_close()

    def _make_handler(self):
        server = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "SchoolSchedule"

            def log_message(self, fmt, *args):
                pass

            def _send(self, status, body, content_type="application/json; charset=utf-8"):
                if isinstance(body, str):
                    body = body.encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Referrer-Policy", "no-referrer")
                self.end_headers()
                self.wfile.write(body)

            def _json(self, status, data):
                self._send(status, json.dumps(data))

            def _route(self):
                """Return the path after /<token>, or None if the request isn't allowed."""
                host = (self.headers.get("Host") or "").split(":")[0]
                if host not in ("127.0.0.1", "localhost"):
                    return None
                path = urlparse(self.path).path
                prefix = "/" + server.token
                if path == prefix:
                    return "/"
                if not path.startswith(prefix + "/"):
                    return None
                return path[len(prefix):]

            def do_GET(self):
                route = self._route()
                if route is None:
                    self._send(404, "Not found", "text/plain; charset=utf-8")
                    return
                query = {k: v[-1] for k, v in parse_qs(urlparse(self.path).query).items()}
                try:
                    if route == "/":
                        with open(INDEX_HTML, "rb") as f:
                            self._send(200, f.read(), "text/html; charset=utf-8")
                    elif route in server.raw_routes:
                        content_type, data = server.raw_routes[route](query)
                        self._send(200, data, content_type)
                    elif route in server.routes["GET"]:
                        self._json(200, server.routes["GET"][route](query))
                    else:
                        self._json(404, {"error": "Unknown page."})
                except Exception as e:
                    self._json(400, {"error": str(e) or e.__class__.__name__})

            def do_POST(self):
                route = self._route()
                if route is None or self.headers.get("X-SSM-Token") != server.token:
                    self._json(403, {"error": "Not allowed."})
                    return
                handler_fn = server.routes["POST"].get(route)
                if handler_fn is None:
                    self._json(404, {"error": "Unknown action."})
                    return
                try:
                    length = min(int(self.headers.get("Content-Length") or 0), 2_000_000)
                    body = json.loads(self.rfile.read(length) or b"{}")
                    if not isinstance(body, dict):
                        raise ValueError("Bad request.")
                    self._json(200, handler_fn(body))
                except AppBusy as e:
                    self._json(503, {"error": str(e)})
                except Exception as e:
                    self._json(400, {"error": str(e) or e.__class__.__name__})

        return Handler
