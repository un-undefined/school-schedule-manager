#!/bin/bash
# Sets up School Schedule on this Mac and starts it. Needs internet the first time.
cd "$(dirname "$0")" || exit 1
if ! /usr/bin/python3 --version >/dev/null 2>&1; then
  echo "This Mac needs Apple's developer tools first. A window should pop up: click Install,"
  echo "wait for it to finish, then run this again."
  xcode-select --install
  exit 1
fi
echo "Setting up School Schedule (about a minute)..."
/usr/bin/python3 -m venv .venv && .venv/bin/python -m pip install --quiet --upgrade pip && .venv/bin/python -m pip install --quiet -r requirements.txt || { echo "Setup failed. Check your internet and try again."; exit 1; }
bash ./make_app.sh && open "$HOME/Applications/School Schedule.app"
echo "Done! Look for the overlay in the bottom-left corner and the clock in the menu bar."
