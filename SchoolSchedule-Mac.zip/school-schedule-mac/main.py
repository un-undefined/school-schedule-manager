"""School Schedule Manager - macOS version.

Ported from the Windows version (code.py). The drawing code and behaviour are
the same; these parts changed:
  * win32gui / pystray  ->  mac_platform.py (native macOS window + menu bar icon)
  * Tk settings windows ->  a settings page in your browser (web_settings.py + web/index.html),
                            because Apple's built-in Python has a Tk that freezes on new macOS
  * Retina screens are drawn at full resolution (layout.scale)
  * New: homework list with check boxes, and an advisory on/off switch

Start it with ./run.sh
"""

# - stdlib imports -
import colorsys
import copy
from datetime import date, datetime, time as dtime
import fcntl
import io
import json
import math
import os
from pathlib import Path
import platform
import re
import shutil
import sys
import time
import traceback
import webbrowser

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
# let the first click on the overlay count even while another app is in front
os.environ["SDL_MOUSE_FOCUS_CLICKTHROUGH"] = "1"

# - 3rd party imports -
import pygame
from pygame import draw, gfxdraw, transform

# - local app imports -
import school_schedule
import events as school_events
import homework as hw
import icons
import mac_platform
import web_settings
from default_config import DEFAULT_UI_CONFIG, build_default_config

pygame.init()
pygame.font.init()
mac_platform.make_accessory_app()  # no Dock icon, like the hidden taskbar button on Windows

APP_VERSION = "1.0.0 (Mac)"
GITHUB_URL = "https://github.com/un-undefined/school-schedule-manager"
FORM_URL = "https://forms.gle/oKoyiL4BcA96MvTv6"
SNAPSHOT_DIR = os.environ.get("SSM_SNAPSHOT_DIR")  # developer option: save PNGs of each view, then quit

HOMEWORK_DONE_COLOR = (62, 178, 92)
HOMEWORK_LATE_COLOR = (236, 112, 112)

# <--== HELPER FUNCTIONS ==-->
def lerp(start, end, t):
    return start + (end - start) * t

def lerp_hue(h1, h2, t):
    diff = h2 - h1
    if diff > 0.5:
        h1 += 1.0
    elif diff < -0.5:
        h2 += 1.0

    return lerp(h1, h2, t) % 1.0

def lerp_color(color1_rgb, color2_rgb, t):
    r1, g1, b1 = [x / 255.0 for x in color1_rgb]
    r2, g2, b2 = [x / 255.0 for x in color2_rgb]

    rgb_lerp_r = lerp(r1, r2, t)
    rgb_lerp_g = lerp(g1, g2, t)
    rgb_lerp_b = lerp(b1, b2, t)

    h1, s1, v1 = colorsys.rgb_to_hsv(r1, g1, b1)
    h2, s2, v2 = colorsys.rgb_to_hsv(r2, g2, b2)

    if s1 == 0 or v1 == 0: h1 = h2
    if s2 == 0 or v2 == 0: h2 = h1

    h_blend = lerp_hue(h1, h2, t)
    s_blend = lerp(s1, s2, t)
    v_blend = lerp(v1, v2, t)

    hsv_lerp_r, hsv_lerp_g, hsv_lerp_b = colorsys.hsv_to_rgb(h_blend, s_blend, v_blend)

    final_r = (1.3 * rgb_lerp_r + 0.7 * hsv_lerp_r) / 2.0
    final_g = (1.3 * rgb_lerp_g + 0.7 * hsv_lerp_g) / 2.0
    final_b = (1.3 * rgb_lerp_b + 0.7 * hsv_lerp_b) / 2.0

    return (round(final_r * 255), round(final_g * 255), round(final_b * 255))

def format_exception(e):
    # traceback.format_exception(e) needs Python 3.10; this Mac has 3.9
    return "".join(traceback.format_exception(type(e), e, e.__traceback__))

def show_exception(title, text, e):
    mac_platform.alert(title, text, ("Ok.",), details=format_exception(e), warning=True)

def mac_time_format(fmt):
    # Windows writes "hour without a leading zero" as %#I; macOS writes it as %-I
    return str(fmt).replace("%#", "%-")

def as_bool(value):
    if isinstance(value, str):
        return value.strip().lower() in ("true", "1", "yes", "on")
    return bool(value)

def write_json(path, data):
    tmp = str(path) + ".tmp"
    with open(tmp, "w") as file:
        json.dump(data, file, indent=4)
    os.replace(tmp, path)

def fit_text(font, text, max_width):
    """Shorten text with an ellipsis so it fits in max_width pixels."""
    if font.size(text)[0] <= max_width:
        return text
    lo, hi = 0, len(text)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if font.size(text[:mid].rstrip() + "…")[0] <= max_width:
            lo = mid
        else:
            hi = mid - 1
    return text[:lo].rstrip() + "…"

def short_day(date_str):
    d = hw.parse_day(date_str)
    days_away = (d - date.today()).days
    if days_away == 1:
        return "tmrw"
    if -7 < days_away < 7:
        return d.strftime("%a")
    return "%d/%d" % (d.month, d.day)

def schedule_problems(cfg):
    """Things in a config that would crash the schedule, as plain-English sentences."""
    try:
        manager = school_schedule.ScheduleManager()
        manager.reload("custom", cfg)
    except Exception as e:
        return ["The schedule part of the config doesn't load (%s: %s)." % (e.__class__.__name__, e)]
    sched = manager.schedule
    problems = []
    missing = {}
    for day_number, day in enumerate(sched.class_schedules, start=1):
        for code in day:
            if sched.get_course_from_schedule(code) is None:
                missing.setdefault(code[0], set()).add(day_number)
    for period, days in sorted(missing.items()):
        problems.append("There's no class for period %s (it's on your schedule on day %s). Add a class with period %s." % (period, ", ".join(str(d) for d in sorted(days)), period))
    for blocks in sched.block_times.values():
        for block in blocks:
            if "class" not in block.block_type.split("_") and sched.get_course(block.block_type) is None:
                problems.append("The built-in \"%s\" entry is missing from the course list." % block.block_type)
    for name in ("lunch", "none"):
        if sched.get_course(name) is None:
            problems.append("The built-in \"%s\" entry is missing from the course list." % name)
    waves = min([len(v) for v in sched.lunch_times.values()] or [0])
    if len(sched.lunches) < len(sched.class_schedules) or any(not 1 <= int(n) <= waves for n in sched.lunches):
        problems.append("Every rotation day needs a lunch wave between 1 and %d." % waves)
    return list(dict.fromkeys(problems))

def list_rows(scroll, total, starting, height):
    """Visible rows of a scrolling list (settings / homework): (index, slot, rect)."""
    rows = []
    for k in range(6):
        i = k
        count = i + math.floor(scroll)
        i -= scroll % 1
        if 0 <= count < total:
            rows.append((count, i, pygame.Rect((0, starting + height / 5 * (i + 0.4), layout.width, height / 6))))
    return rows

# <--== CLASSES ==-->
def get_resource_path(relative_path):
    return Path(__file__).resolve().parent / "resources" / relative_path

LOCAL_APP_DIR = Path.home() / "Library" / "Application Support" / "WHSSchoolScheduleManager"
LOCAL_APP_DIR.mkdir(parents=True, exist_ok=True)

# - only one copy at a time (two overlays would fight over the same files) -
_instance_lock = open(LOCAL_APP_DIR / "app.lock", "w")
try:
    fcntl.flock(_instance_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
except OSError:
    mac_platform.alert("Already running", "School Schedule is already open. Look for the clock icon in the menu bar at the top of the screen.")
    sys.exit(0)

class Config:
    CONFIG_PATH = LOCAL_APP_DIR / "config.json"
    FALLBACK_CONFIG_PATH = LOCAL_APP_DIR / "default.config.json"

    def __init__(self):
        self.fallback_config = self.load_fallback()

        self.config_open = False

        self.config_buttons = []
        self.config_scroll = 0

        self.config = self.read_from_file()

        self.save()

    def load_fallback(self):
        # On Windows the installer provided default.config.json; here it's built on first launch.
        try:
            with open(Config.FALLBACK_CONFIG_PATH, "r") as file:
                fallback = json.load(file)
            fallback["ui_config"], fallback["class_data"]
        except FileNotFoundError:
            fallback = build_default_config()
            write_json(Config.FALLBACK_CONFIG_PATH, fallback)
        except Exception as e:
            show_exception("Default Configuration Rebuilt", "The default configuration file was damaged, so it was rebuilt from the built-in schedule.", e)
            fallback = build_default_config()
            write_json(Config.FALLBACK_CONFIG_PATH, fallback)

        # schema test: add settings that are newer than the file
        changed = False
        for key, value in DEFAULT_UI_CONFIG.items():
            if key not in fallback["ui_config"]:
                fallback["ui_config"][key] = copy.deepcopy(value)
                changed = True
        if changed:
            write_json(Config.FALLBACK_CONFIG_PATH, fallback)
        return fallback

    def read_from_file(self):
        if not Config.CONFIG_PATH.exists():
            return copy.deepcopy(self.fallback_config)  # first launch
        try:
            with open(Config.CONFIG_PATH, "r") as file:
                c = json.load(file)

            for key, item in self.fallback_config["ui_config"].items():
                if key not in c["ui_config"]:
                    c["ui_config"][key] = copy.deepcopy(item)
            problems = schedule_problems(c)  # make sure the schedule part works
            if problems:
                raise ValueError("\n".join(problems))
        except Exception as e:
            try:
                shutil.copyfile(Config.CONFIG_PATH, LOCAL_APP_DIR / "config.broken.json")
            except OSError:
                pass
            show_exception("Error Validating Configuration File", "There was an error reading your configuration file. It is likely corrupted, or a mistake was made while editing the file directly. Reverting to default values.\n\nA copy of the broken file was saved as config.broken.json. Paste the details below into a bug report form.", e)
            return copy.deepcopy(self.fallback_config)

        return c

    def show_config_warning(self, e, text):
        show_exception("An Exception has occurred!", text + "\n\nEither edit the configuration file directly or use the Settings page to change it back.", e)

    def save(self):
        try:
            WindowHandler.DEFAULT_ALPHA_VALUE = int(self.config["ui_config"]["default_transparency"])
        except Exception:
            pass
        try:
            float(self.config["ui_config"]["scroll_speed"])
        except Exception as e:
            self.show_config_warning(e, "You have set the scroll speed multiplier to a non-float / non-decimal value. Reverting to default scroll speed 1.3.")
            self.config["ui_config"]["scroll_speed"] = 1.3
        try:
            int(self.config["ui_config"]["width"])
        except Exception as e:
            self.show_config_warning(e, "You have set the window width to a non-integer value. Reverting to default window width 376")
            self.config["ui_config"]["width"] = 376
        try:
            int(self.config["ui_config"]["height"])
        except Exception as e:
            self.show_config_warning(e, "You have set the window height to a non-integer value. Reverting to default window height 94.")
            self.config["ui_config"]["height"] = 94
        write_json(Config.CONFIG_PATH, self.config)

config = Config()

def advisory_enabled():
    return as_bool(config.config["ui_config"].get("advisory_enabled", True))

# - ui styling -
class Layout:
    EXPANSION_FACTOR = 4

    def __init__(self):
        # pixels per point: 2 on Retina screens. Window sizes are in points, drawing is in pixels.
        self.scale = 1
        self._load_size()
        self.current_height = self.collapsed_height
        self.height_target = self.collapsed_height

        # - window hover info -
        self.mouse_hovered = False
        self.hovered_since = None
        self.hovered_percent = 0

        self._calculate_dependent_properties()

    def _load_size(self):
        self.width = round(int(config.config["ui_config"]["width"]) * self.scale)
        self.collapsed_height = round(int(config.config["ui_config"]["height"]) * self.scale)
        self.expanded_height = self.collapsed_height * Layout.EXPANSION_FACTOR

    def _calculate_dependent_properties(self):
        self.class_circle_radius = round(self.collapsed_height * 31 / 94)
        self.class_icon_radius = self.class_circle_radius // 2 + 1
        self.class_progress_bar_height = self.class_circle_radius
        self.class_progress_bar_offset = (self.collapsed_height // 2 - self.class_progress_bar_height // 2) * 0.7
        self.class_progress_bar_radius = round(5 * self.scale)

        self.border_radius = round(self.collapsed_height * 13 / 94)
        self.border_width = round(self.collapsed_height * 3 / 94)

        self.top_button_padding = round(self.expanded_height * 8 / 470)
        self.top_button_height = round(self.expanded_height * 42 / 470)
        self.top_button_border = round(self.expanded_height * 2 / 470)
        self.top_button_icon_radius = round(self.expanded_height * 13 / 470)

        self.homework_box_size = round(self.collapsed_height * 18 / 94)
        self.homework_box_border = max(1, round(self.collapsed_height * 2 / 94))
        self.homework_check_radius = round(self.collapsed_height * 7 / 94)
        self.homework_circle_radius = round(self.collapsed_height * 12 / 94)

        self.font_factor = (1 / 94 * self.collapsed_height)

        try:
            resources.reload_all()
        except NameError:
            pass

    def update(self):
        # re-read the size from the config, keeping the expanded / collapsed state
        was_collapsed = self.height_target == self.collapsed_height
        self._load_size()
        self.height_target = self.collapsed_height if was_collapsed else self.expanded_height

        self._calculate_dependent_properties()

    def set_scale(self, scale):
        if abs(scale - self.scale) < 0.01:
            return
        was_collapsed = self.height_target == self.collapsed_height
        self.scale = scale
        self._load_size()
        self.height_target = self.collapsed_height if was_collapsed else self.expanded_height
        self.current_height = self.height_target
        self._calculate_dependent_properties()

    def size_points(self, height=None):
        height = self.current_height if height is None else height
        return (round(self.width / self.scale), round(height / self.scale))

    def update_hover(self):
        if prev_mouse_hovered:
            if self.hovered_percent < 1:
                if not self.mouse_hovered:
                    if self.hovered_since is not None and time.time() - self.hovered_since < 1:
                        self.hovered_since = 2 * time.time() - self.hovered_since - 1
                    else:
                        self.hovered_since = time.time()
                    self.mouse_hovered = True
                self.hovered_percent = min(1.0, time.time() - self.hovered_since)
                if self.hovered_percent >= 1.0:
                    layout.height_target = layout.expanded_height
        else:
            if self.hovered_since is not None and self.mouse_hovered:
                if time.time() - self.hovered_since < 1:
                    self.hovered_since = 2 * time.time() - self.hovered_since - 1
                else:
                    self.hovered_since = time.time()
            self.mouse_hovered = False
            if self.hovered_percent > 0:
                self.hovered_percent = 1 - min(1.0, time.time() - self.hovered_since)
                if self.hovered_percent <= 0:
                    layout.height_target = layout.collapsed_height
                    self.hovered_since = 0
                    return True
        return False

layout = Layout()

# - homework panel state -
class HomeworkView:
    """Today's homework inside the expanded overlay (the Homework button in focus mode)."""
    def __init__(self):
        self.open = False
        self.scroll = 0
        self.hover = {}
        self._rows = None
        self._rows_time = 0

    def invalidate(self):
        self._rows = None

    def rows(self):
        # re-read the list a couple of times a second (the browser page can change it too)
        now = time.time()
        if self._rows is None or now - self._rows_time > 0.5:
            today = date.today()
            items = homework.list_for(today, today)
            rows = [("item", item) for item in items]
            if not items:
                rows.append(("empty", None))
            rows.append(("add", None))
            self._rows, self._rows_time = rows, now
        return self._rows

    def click(self, kind, item):
        if kind == "item":
            homework.toggle(item["id"], date.today())
            self.invalidate()
        elif kind == "add":
            open_web_page("homework")

homework_view = HomeworkView()

# - window handler -
class WindowHandler:
    WINDOW_NAME = "School Schedule Manager"
    try:
        DEFAULT_ALPHA_VALUE = int(config.config["ui_config"]["default_transparency"])
    except Exception as e:
        show_exception("An Exception has occurred!", "You have set the default transparency to a non-integer value. Reverting to default alpha 200.\n\nEither edit the configuration file directly or use the Settings page to change it back.", e)
        DEFAULT_ALPHA_VALUE = 200

    def __init__(self):
        width, height = layout.size_points()
        position = mac_platform.overlay_start_position(width, height)
        self.screen = pygame.Window(WindowHandler.WINDOW_NAME, size=(width, height), position=position, borderless=True, always_on_top=True, allow_high_dpi=True)
        self.native = mac_platform.OverlayWindow(WindowHandler.WINDOW_NAME)
        self.native.setup()
        self.tray = None

        self.app_state = {
                "window_shown": True,
                "window_state": "default", # default, temp_show, temp_hide,
                "clickthrough": True,
                "window_alpha": WindowHandler.DEFAULT_ALPHA_VALUE
            }

        self.set_window_alpha()
        self.set_window_clickthrough(True)

    def get_surface(self):
        return self.screen.get_surface()

    def pixel_scale(self):
        width = self.screen.size[0]
        return self.screen.get_surface().get_width() / width if width else 1

    def mouse_relative(self):
        """Mouse position in points, relative to the window's top-left corner."""
        rel = self.native.mouse_relative()
        if rel is not None:
            return rel
        if self.screen.focused:
            return pygame.mouse.get_pos()
        return (-100, -100)

    # - window resize -

    def resize_keep_bottom(self, width, height):
        self.native.set_frame_keep_bottom(width, height)
        if tuple(self.screen.size) != (width, height):
            # no native window, or it was hidden so SDL didn't notice the change
            x, y = self.screen.position
            bottom = y + self.screen.size[1]
            self.screen.size = (width, height)
            self.screen.position = (x, bottom - height)

    # - window properties -

    def show_window(self):
        if self.native.ok:
            self.native.show()
        else:
            self.screen.show()
        self.app_state["window_shown"] = True
        if self.tray is not None:
            self.tray.set_on(True)

    def hide_window(self):
        if self.native.ok:
            self.native.hide()
        else:
            self.screen.hide()
        self.app_state["window_shown"] = False
        if self.tray is not None:
            self.tray.set_on(False)
        config.config_open = False
        homework_view.open = False

    def reset_state(self):
        self.show_window()
        self.app_state["window_state"] = "default"
        self.set_window_alpha()
        self.set_window_clickthrough(True)
        config.config_open = False
        homework_view.open = False

    def set_window_clickthrough(self, enabled=None):
        enabled = (not self.app_state["clickthrough"]) if enabled is None else enabled
        self.app_state["clickthrough"] = enabled
        self.native.set_ignores_mouse(enabled)

    def set_window_alpha(self, alpha_value=None):
        alpha_value = WindowHandler.DEFAULT_ALPHA_VALUE if alpha_value is None else alpha_value
        alpha_value = max(25, min(255, int(alpha_value)))  # never fully invisible
        self.app_state["window_alpha"] = alpha_value
        try:
            self.screen.opacity = alpha_value / 255
        except pygame.error:
            pass  # not supported by the test-only "dummy" video driver

    # - quit handlers -

    def quit_all(self):
        if self.tray is not None:
            self.tray.remove()
        if web_server is not None:
            web_server.stop()
        pygame.quit()
        sys.exit()

    def quit_pressed(self):
        pygame.event.post(pygame.event.Event(pygame.QUIT))

web_server = None  # started further down

window = WindowHandler()
layout.set_scale(window.pixel_scale())
window.native.set_corner_radius(layout.border_radius / layout.scale)
ds = window.get_surface()

clock = pygame.time.Clock()

# - school schedule manager -
schedule = school_schedule.ScheduleManager()

def reload_schedule():
    schedule.reload("custom", config.config)
    if not advisory_enabled():
        schedule.special_days["advisory"] = -1  # no weekday matches, so advisory days use the normal schedule

reload_schedule()
schedule_day = date.today()  # the bell times are built for this date (see the main loop)

# - homework -
homework = hw.HomeworkStore(str(LOCAL_APP_DIR / "homework.json"))

# - after-school events -
events_store = school_events.EventStore(str(LOCAL_APP_DIR / "events.json"))

# - resource manager -
class ResourceManager:
    def __init__(self):
        self.top_icon_surfaces = {}
        self.top_text_surfaces = {}
        self.top_buttons = []
        self.homework_icons = {}
        self.general_course = school_schedule.Course("", "general", "General", "notebook-pen", "#8C909C")
        self.free_course = school_schedule.Course("F", "free_time", "Free Time", "coffee", "#7A8394")  # gap before an event
        self.event_courses = {}  # after-school events, made on demand by event_course()

        self.special_surfaces = {}

    def reload_all(self):
        self.reload_fonts()
        self.reload_icons()
        self.reload_texts()

        self.reload_top_buttons()
        self.reload_config_icons()
        self.reload_special_surfaces()

    # - special surfaces -
    def reload_special_surfaces(self):
        fls = self.font_15.get_linesize()
        surf = pygame.Surface((fls, fls), pygame.SRCALPHA)
        for i in range(fls):
            draw.rect(surf, list(config.config["ui_config"]["bg_color"]) + [min(round(255*i/fls), 255),], (i, 0, i+1, fls))
        self.special_surfaces["text_gradient"] = transform.smoothscale(surf, (fls*2, fls))
        self.special_surfaces["top_gradient"] = transform.smoothscale(transform.rotate(surf, 90), (layout.width, fls*1.5))
        self.special_surfaces["bottom_gradient"] = transform.rotate(self.special_surfaces["top_gradient"], 180)

    # - config icons -
    def reload_config_icons(self):
        for icon in config.config_buttons:
            icon.reload()

    # - top buttons -
    def reload_top_buttons(self):
        for top_button in self.top_buttons:
            top_button.reload()

    # - text Surfaces & fonts -
    def reload_fonts(self):
        font_path = str(get_resource_path("JetBrainsMono-Medium.ttf"))

        self.font_15 = pygame.font.Font(font_path, round(15 * layout.font_factor))
        self.font_17 = pygame.font.Font(font_path, round(17 * layout.font_factor))
        self.font_20 = pygame.font.Font(font_path, round(20 * layout.font_factor))

    def reload_texts(self):
        text_color = config.config["ui_config"]["text_color"]
        for key, text in (("show", "Focus"), ("hide", "Hide (10s)"), ("settings", "Settings"), ("exit_settings", "Exit Settings"), ("homework", "Homework"), ("exit_homework", "Exit Homework")):
            self.top_text_surfaces[key] = resources.font_15.render(text, True, text_color)

    # - Lucide icons -
    def reload_icons(self):
        # - course icons -
        self.event_courses = {}
        for course in list(schedule.schedule.courses) + [self.general_course, self.free_course]:
            course.load_icon(self.load_icon(course.icon, layout.class_icon_radius), self.load_icon(course.icon, round(layout.class_icon_radius / 2)))

        # - top icon surfaces -
        self.top_icon_surfaces["show"] = self.load_icon("mouse-pointer-click", layout.top_button_icon_radius)
        self.top_icon_surfaces["hide"] = self.load_icon("panel-bottom-close", layout.top_button_icon_radius)
        self.top_icon_surfaces["settings"] = self.load_icon("settings", layout.top_button_icon_radius)
        self.top_icon_surfaces["exit_settings"] = self.load_icon("log-out", layout.top_button_icon_radius)
        self.top_icon_surfaces["homework"] = self.load_icon("notebook-pen", layout.top_button_icon_radius)
        self.top_icon_surfaces["exit_homework"] = self.load_icon("log-out", layout.top_button_icon_radius)

        # - homework icons -
        self.homework_icons["check"] = self.load_icon("check", layout.homework_check_radius)
        self.homework_icons["plus"] = self.load_icon("plus", layout.homework_check_radius + 1, tuple(config.config["ui_config"]["button_accent_color"]))
        muted = tuple(config.config["ui_config"]["muted_text_color"])
        self.homework_icons["class"] = self.load_icon("school", layout.homework_check_radius, muted)  # due in class
        self.homework_icons["night"] = self.load_icon("moon", layout.homework_check_radius, muted)    # due at night

    def load_icon(self, icon_name, radius, color=(255, 255, 255)):
        r, g, b = color
        svg_string = icons.svg(icon_name, stroke=f"#{r:02x}{g:02x}{b:02x}", width=radius * 2, height=radius * 2)
        svg_bytes = io.BytesIO(svg_string.encode("utf-8"))
        return pygame.image.load(svg_bytes, "svg").convert_alpha()

resources = ResourceManager()

def course_for_homework(item):
    for course in schedule.schedule.courses:
        if course.nid == "class" and course.cid == item.get("period"):
            return course
    return resources.general_course

def event_course(event):
    """A Course for an after-school event (its icons are cached until the next reload)."""
    key = (event["id"], event["name"], event["icon"], event["color"])
    course = resources.event_courses.get(key)
    if course is None:
        course = school_schedule.Course("EV", "event", event["name"], event["icon"], event["color"])
        course.load_icon(resources.load_icon(course.icon, layout.class_icon_radius), resources.load_icon(course.icon, round(layout.class_icon_radius / 2)))
        resources.event_courses[key] = course
    return course

def apply_events(current):
    """Fit today's after-school events into the day's schedule (school days only).

    The "End of School Day" block is split into: Free Time (counting down to the
    event), the event itself, ..., then End of School Day after the last event.
    An event that starts before school is out starts when school ends.
    """
    if current.timeinfo.day_type == "break":
        return
    end_index = next((i for i, c in enumerate(current.schedule) if c.course.nid == "end_of_school_day"), None)
    if end_index is None:
        return
    todays_events = events_store.on_day(current.timeinfo.dt.date())
    if not todays_events:
        return
    dt = current.timeinfo.dt
    school_out = current.schedule[end_index]
    day = school_out.start_time.date()
    cursor, day_end = school_out.start_time, school_out.end_time
    blocks = []
    for event in todays_events:
        start = max(datetime.combine(day, dtime(*school_events.parse_time(event["start"]))), cursor)
        end = min(datetime.combine(day, dtime(*school_events.parse_time(event["end"]))), day_end)
        if end <= start:
            continue
        if start > cursor:
            blocks.append(school_schedule.Class(dt, resources.free_course, school_schedule.Block(cursor, start, "free_time", "Free Time"), cursor, start))
        blocks.append(school_schedule.Class(dt, event_course(event), school_schedule.Block(start, end, "event", event["name"]), start, end))
        cursor = end
    if not blocks:
        return
    blocks.append(school_schedule.Class(dt, school_out.course, school_out.block, cursor, day_end))
    day_schedule = current.schedule[:end_index] + blocks + current.schedule[end_index + 1:]

    # pick the current and next block the same way school_schedule.py does
    current_class = next_class = None
    for block in day_schedule:
        if current_class is not None and next_class is None and block.course.nid not in ("transition", "free_time"):
            next_class = block
        if block.start_time <= dt <= block.end_time:
            current_class = block
    current.schedule = day_schedule
    current.current_class = current_class or schedule.schedule.get_none_class(dt)
    current.next_class = next_class or schedule.schedule.get_none_class(dt)

def timeline_position():
    """Classes shown on the timeline (no transitions) and which one is current."""
    stripped_schedule = [c for c in current.schedule if c.course.name != "Transition"]
    _class = current.current_class
    if _class.course.name == "Transition":
        prev_class = None
        for iclass in current.schedule:
            if iclass.course.name != "Transition":
                prev_class = iclass
            elif iclass == _class:
                break
        _class = prev_class
    shift = stripped_schedule.index(_class) if _class in stripped_schedule else max(0, len(stripped_schedule) - 1)
    return stripped_schedule, shift

def content_area():
    starting = layout.top_button_height * 1.3 + layout.top_button_padding
    height = (round(layout.current_height) - layout.collapsed_height) - layout.top_button_height * 1.2 - layout.top_button_padding
    return starting, height

# <--== UI HANDLERS & RENDERERS ==-->

# - render handler -
class RenderHandler:
    def render_basic_texts():
        # - draw primary texts -
        next_label = "Next: " if current.next_class.course.nid == "event" else "Next Class: "
        next_class_text = resources.font_15.render(next_label, True, config.config["ui_config"]["text_color"], config.config["ui_config"]["bg_color"])
        ds.blit(next_class_text, (layout.collapsed_height * 0.9, layout.collapsed_height * 0.92 - next_class_text.height + base_y))

        next_class_name_text = resources.font_15.render(current.next_class.course.name, True, current.next_class.course.accent_color, config.config["ui_config"]["bg_color"])
        ds.blit(next_class_name_text, (layout.collapsed_height * 0.9 + next_class_text.width, layout.collapsed_height * 0.92 - next_class_name_text.height + base_y))

        # - draw progress bar -
        bar_width = layout.width - layout.collapsed_height // 2 - layout.class_circle_radius * 0.93 - layout.class_progress_bar_offset

        draw.rect(ds, config.config["ui_config"]["progress_bar_bg_color"], (layout.collapsed_height // 2 + layout.class_circle_radius * 0.93, layout.collapsed_height // 2 - layout.class_progress_bar_height // 2 + base_y, bar_width, layout.class_progress_bar_height), border_bottom_right_radius=layout.class_progress_bar_radius, border_top_right_radius=layout.class_progress_bar_radius)
        draw.rect(ds, accent_color, (layout.collapsed_height // 2 + layout.class_circle_radius * 0.93, layout.collapsed_height // 2 - layout.class_progress_bar_height // 2 + base_y, bar_width * current_class.class_percent, layout.class_progress_bar_height), border_bottom_right_radius=layout.class_progress_bar_radius, border_top_right_radius=layout.class_progress_bar_radius)

        # - draw hover expansion bar -
        bar_surface = pygame.Surface((layout.width, layout.collapsed_height * 0.08), pygame.SRCALPHA)

        pygame.draw.rect(bar_surface, temp_accent_color, (0, 0, layout.width * layout.hovered_percent, layout.collapsed_height * 0.08))
        mask = pygame.Surface((layout.width, layout.collapsed_height * 0.08), pygame.SRCALPHA)

        pygame.draw.rect(mask, (255, 255, 255, 255), (0, layout.collapsed_height * 0.08 - layout.current_height, layout.width, layout.current_height), border_radius=layout.border_radius)
        bar_surface.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)

        ds.blit(bar_surface, (0, layout.current_height - layout.collapsed_height * 0.08))

        # - draw secondary texts -
        percent_text = resources.font_20.render(str(round(current_class.class_percent * 100, 2)) + "%", True, config.config["ui_config"]["text_color"])
        ds.blit(percent_text, ((layout.collapsed_height * 1.1) // 2 + layout.class_circle_radius, layout.collapsed_height // 2 - percent_text.height // 2 + base_y))

        time_remaining_text = resources.font_20.render(current_class.time_remaining, True, config.config["ui_config"]["text_color"])
        ds.blit(time_remaining_text, (layout.collapsed_height // 2 + layout.class_circle_radius * 0.6 + bar_width - time_remaining_text.width, layout.collapsed_height // 2 - percent_text.height // 2 + base_y))

        day_text = resources.font_15.render(current.timeinfo_text, True, config.config["ui_config"]["text_color"], config.config["ui_config"]["bg_color"])
        day_text_pos = (layout.collapsed_height // 2 + layout.class_circle_radius * 0.6 + bar_width - day_text.width, layout.collapsed_height * 0.085 + base_y)

        class_name_text = resources.font_15.render(current_course.name, True, config.config["ui_config"]["text_color"], config.config["ui_config"]["bg_color"])
        class_name_pos = (layout.collapsed_height * 0.9, layout.collapsed_height * 0.085 + base_y)
        if day_text_pos[0] < class_name_text.width + class_name_pos[0]:
            gradient = resources.special_surfaces["text_gradient"]
            if class_name_pos[0] < mx < day_text_pos[0] + day_text.width and class_name_pos[1] < my < class_name_pos[1] + class_name_text.height:
                ds.blit(class_name_text, class_name_pos, (0, 0, min(class_name_text.width, ds.width - class_name_pos[0] - layout.border_width), class_name_text.height))
                ds.blit(gradient, (ds.width - layout.border_width - class_name_text.height * 3, class_name_pos[1]))
            else:
                ds.blit(class_name_text, class_name_pos, (0, 0, min(class_name_text.width, day_text_pos[0] - class_name_pos[0]), class_name_text.height))
                ds.blit(gradient, (day_text_pos[0] - class_name_text.height * 2.3, class_name_pos[1]))
                draw.rect(ds, config.config["ui_config"]["bg_color"], (day_text_pos[0] - class_name_text.height * 2.3 + gradient.width, class_name_pos[1], gradient.width / 2, gradient.height))
                ds.blit(day_text, day_text_pos)
        else:
            ds.blit(class_name_text, class_name_pos, (0, 0, min(class_name_text.width, day_text_pos[0] - class_name_pos[0]), class_name_text.height))
            ds.blit(day_text, day_text_pos)

        # - draw icon circle -
        gfxdraw.filled_circle(ds, layout.collapsed_height // 2, layout.collapsed_height // 2 + base_y, layout.class_circle_radius, accent_color)
        gfxdraw.aacircle(ds, layout.collapsed_height // 2, layout.collapsed_height // 2 + base_y, layout.class_circle_radius, accent_color)

        # - draw icon -
        ds.blit(current_course.icon_surf, (layout.collapsed_height // 2 - layout.class_icon_radius, layout.collapsed_height // 2 - layout.class_icon_radius + base_y))

    def render_top_buttons():
        draw.rect(ds, config.config["ui_config"]["button_bg_color"], hide_button.button_rect, border_top_left_radius=round(layout.border_radius * 0.6))
        draw.rect(ds, config.config["ui_config"]["button_bg_color"], show_button.button_rect, border_top_right_radius=round(layout.border_radius * 0.6))

        focused = window.app_state["window_state"] == "temp_show"

        # - right button: Focus -> Settings / Exit Settings -
        smooth_percent = 2 * ((show_button.hover_percent) ** 0.5) - show_button.hover_percent
        center_pos = (layout.width * 3 // 4 + layout.top_button_padding * 0.35 - round(layout.top_button_padding * 0.675), layout.top_button_padding + layout.top_button_height // 2)

        if focused:
            key, text_k, icon_k = ("exit_settings", 0.35, 0.6) if config.config_open else ("settings", 0.25, 0.55)
        else:
            key, text_k, icon_k = ("show", 0.2, 0.8)
        text_surface = resources.top_text_surfaces[key].copy()
        text_surface.set_alpha(round(smooth_percent * 255))
        ds.blit(text_surface, (center_pos[0] - text_k * text_surface.width * smooth_percent, center_pos[1] - text_surface.height // 2))
        ds.blit(resources.top_icon_surfaces[key], (center_pos[0] - layout.top_button_icon_radius - icon_k * text_surface.width * smooth_percent, center_pos[1] - layout.top_button_icon_radius))

        # - left button: Hide (10s) -> Homework / Exit Homework -
        smooth_percent = 2 * ((hide_button.hover_percent) ** 0.5) - hide_button.hover_percent
        center_pos = (round(layout.top_button_padding * 0.325) + layout.width // 4, layout.top_button_padding + layout.top_button_height // 2)

        if focused:
            key, text_k, icon_k = ("exit_homework", 0.35, 0.6) if homework_view.open else ("homework", 0.25, 0.55)
        else:
            key, text_k, icon_k = ("hide", 0.3, 0.6)
        text_surface = resources.top_text_surfaces[key].copy()
        text_surface.set_alpha(round(smooth_percent * 255))
        ds.blit(text_surface, (center_pos[0] - text_k * text_surface.width * smooth_percent, center_pos[1] - text_surface.height // 2))
        ds.blit(resources.top_icon_surfaces[key], (center_pos[0] - layout.top_button_icon_radius - icon_k * text_surface.width * smooth_percent, center_pos[1] - layout.top_button_icon_radius))

        # - hover progress bars (only while the buttons work by hovering) -
        if not focused:
            draw.rect(ds, config.config["ui_config"]["button_accent_color"], (hide_button.button_rect.x, hide_button.button_rect.y + hide_button.button_rect.height * 0.9, hide_button.button_percent * hide_button.button_rect.width, hide_button.button_rect.height * 0.1))
            draw.rect(ds, config.config["ui_config"]["button_accent_color"], (show_button.button_rect.x, show_button.button_rect.y + show_button.button_rect.height * 0.9, show_button.button_percent * show_button.button_rect.width, show_button.button_rect.height * 0.1))

    def render_schedule_preview(starting, height):
        # - calculate schedule display -
        stripped_schedule, shift = timeline_position()
        current_course = current.current_class.course
        time_format = mac_time_format(config.config["ui_config"]["time_format"])

        # - draw timeline -
        for k in range(6):
            i = k
            count = i - 2 + shift + math.floor(timeline_scroll)
            if current_course.name == "Transition":
                i -= 0.5
            i -= timeline_scroll % 1
            if count < 0 or count >= len(stripped_schedule):
                continue
            rendering_class = stripped_schedule[count]
            rendering_course = rendering_class.course
            color = rendering_course.accent_color
            if len(stripped_schedule) > count + 1:
                next_color = stripped_schedule[count + 1].course.accent_color
                if i < 5 * (config.config["ui_config"]["timeline_gradient"]):
                    section_height = round(height * (0.9 - 0.2 * i)) if i == 4 else round(height / 5)
                    for j in range(section_height):
                        c = lerp_color(color, next_color, min(1, j / (height / 5)))
                        draw.rect(ds, c, (layout.width * 0.08, starting + height / 5 * (i + 0.5) + j, layout.width * 0.015, 1))
                else:
                    draw.rect(ds, color, (layout.width * 0.08, starting + height / 5 * (i + 0.5), layout.width * 0.015, height / 5 * (4.5 - i)))
            draw.circle(ds, color, (layout.width * 0.0875, starting + height / 5 * (i + 0.5)), layout.width / 50)

            ds.blit(rendering_course.small_icon_surf, (layout.width * 0.195, starting + height / 5 * (i + 0.125)))

            primary_text = resources.font_17.render(rendering_course.name, True, config.config["ui_config"]["text_color"])
            ds.blit(primary_text, (layout.width * 0.26, starting + height / 5 * (i + 0.05)))

            subtext = rendering_class.start_time.strftime(time_format) + " - " + rendering_class.end_time.strftime(time_format)
            small_text = resources.font_15.render(subtext, True, config.config["ui_config"]["muted_text_color"])
            ds.blit(small_text, (layout.width * 0.195, starting + height / 5 * (i + 0.46)))

        # - draw arrow -
        arrow_surf = resources.font_17.render("<", True, config.config["ui_config"]["text_color"])
        ds.blit(arrow_surf, (layout.width * 0.14, starting + height / 2 - arrow_surf.height / 2 + height / 5 * (-timeline_scroll)))

    def render_settings(starting, height):
        buttons = config.config_buttons
        for count, i, rect in list_rows(config.config_scroll, len(buttons), starting, height):
            button = buttons[count]

            hovered = rect.collidepoint(mx, my)
            if hovered and window.app_state["window_state"] == "temp_show":
                button.hover_state = min(1, button.hover_state + 0.1)
            else:
                button.hover_state = max(0, button.hover_state - 0.1)
            hover_anim = 1 - ((1 - button.hover_state) ** 1.6)
            bg_color = lerp_color(config.config["ui_config"]["config_bg_color"], button.color, hover_anim * 0.15)
            draw.rect(ds, bg_color, rect)

            ds.blit(button.surf, (layout.width * 0.06, starting + height / 5 * (i + 0.62)))
            text = "This is a pointless button." if button.text == "This is a button." and hovered else button.text
            button_text = resources.font_17.render(text, True, button.color)
            ds.blit(button_text, (layout.width * 0.15, starting + height / 5 * (i + 0.6)))

            if button.arrow is not None:
                ds.blit(button.arrow_surf, (layout.width * (0.82 + hover_anim * 0.05), starting + height / 5 * (i + 0.62)))

    def render_homework(starting, height):
        ui = config.config["ui_config"]
        rows = homework_view.rows()
        focused = window.app_state["window_state"] == "temp_show"
        box_x = round(layout.width * 0.07)
        circle_x = round(layout.width * 0.155)
        text_x = layout.width * 0.225
        right_edge = layout.width * 0.95

        for count, i, rect in list_rows(homework_view.scroll, len(rows), starting, height):
            kind, item = rows[count]
            key = item["id"] if item else kind

            hovered = focused and rect.collidepoint(mx, my)
            state = homework_view.hover.get(key, 0)
            state = min(1, state + 0.1) if hovered else max(0, state - 0.1)
            homework_view.hover[key] = state
            hover_anim = 1 - ((1 - state) ** 1.6)

            course = course_for_homework(item) if item else None
            tint = course.accent_color if course else ui["button_accent_color"]
            draw.rect(ds, lerp_color(ui["config_bg_color"], tint, hover_anim * 0.15), rect)
            cy = rect.centery

            if kind == "item":
                status = item["status"]
                done = status in (hw.STATUS_DONE, hw.STATUS_LATE_DONE, hw.STATUS_UPCOMING_DONE)
                late = status in (hw.STATUS_LATE, hw.STATUS_LATE_DONE)
                upcoming = status in (hw.STATUS_UPCOMING, hw.STATUS_UPCOMING_DONE)

                # - check box -
                size = layout.homework_box_size
                box = pygame.Rect(0, 0, size, size)
                box.center = (box_x, cy)
                radius = max(2, size // 4)
                if done:
                    draw.rect(ds, HOMEWORK_DONE_COLOR, box, border_radius=radius)
                    check = resources.homework_icons["check"]
                    ds.blit(check, check.get_rect(center=box.center))
                else:
                    edge = HOMEWORK_LATE_COLOR if late else ui["muted_text_color"]
                    draw.rect(ds, edge, box, width=layout.homework_box_border, border_radius=radius)

                # - class icon -
                r = layout.homework_circle_radius
                gfxdraw.filled_circle(ds, circle_x, cy, r, course.accent_color)
                gfxdraw.aacircle(ds, circle_x, cy, r, course.accent_color)
                icon = course.small_icon_surf
                ds.blit(icon, icon.get_rect(center=(circle_x, cy)))

                # - "late Tue" / "due Fri" tag + homework text -
                limit = right_edge
                when = item.get("due_when")
                tag_text, tag_color = None, ui["muted_text_color"]
                if late:
                    tag_text, tag_color = "late " + short_day(item["date"]), HOMEWORK_LATE_COLOR
                elif upcoming:
                    tag_text = "due " + short_day(item["date"])
                elif when:
                    tag_text = "in class" if when == "class" else "tonight"
                if tag_text:
                    tag = resources.font_15.render(tag_text, True, tag_color)
                    ds.blit(tag, (right_edge - tag.width, cy - tag.height / 2))
                    limit = right_edge - tag.width - layout.width * 0.03
                    if when and not late:
                        # small school / moon icon in front of the tag
                        icon = resources.homework_icons[when]
                        ds.blit(icon, icon.get_rect(midright=(round(limit + layout.width * 0.02), cy)))
                        limit -= icon.get_width() + layout.width * 0.01
                color = ui["muted_text_color"] if done else ui["text_color"]
                text = resources.font_15.render(fit_text(resources.font_15, item["text"], limit - text_x), True, color)
                ds.blit(text, (text_x, cy - text.height / 2))
                if done:
                    draw.line(ds, color, (text_x, cy), (text_x + text.width, cy), max(1, layout.homework_box_border // 2))
            elif kind == "add":
                plus = resources.homework_icons["plus"]
                ds.blit(plus, plus.get_rect(center=(box_x, cy)))
                label = resources.font_15.render("Add homework (opens browser)", True, ui["text_color"])
                ds.blit(label, (layout.width * 0.13, cy - label.height / 2))
            else:
                label = resources.font_15.render("Nothing due today!", True, ui["muted_text_color"])
                ds.blit(label, (layout.width * 0.13, cy - label.height / 2))

# - opening the settings / homework page in the browser -
def open_web_page(page=""):
    if web_server is None:
        mac_platform.alert("Settings page unavailable", "The settings page couldn't start, so this option isn't available right now. Try restarting the app.")
        return
    webbrowser.open(web_server.url(page))

def set_advisory(enabled, weekday=None):
    config.config["ui_config"]["advisory_enabled"] = bool(enabled)
    if weekday is not None:
        config.config["class_data"]["yearly_data"]["special_dates"]["advisory"] = str(int(weekday))
    ConfigOnClickFunctions.reload_all()

def reset_config_to_defaults():
    ConfigOnClickFunctions.reload_all(copy.deepcopy(config.fallback_config))
    layout.update()
    if window.app_state["window_state"] == "default":
        window.set_window_alpha()

# - config buttons onclick -
class ConfigOnClickFunctions:
    def reload_all(config_json=None):
        if config_json is not None:
            config.config = config_json
        config.save()
        reload_schedule()
        resources.reload_all()
        refresh_web_cache()
        homework_view.invalidate()
        try:
            advisory_button.refresh()
        except NameError:
            pass

    def cocf_exit_config():
        # - closes the config -
        config.config_open = False

    def cocf_edit_classes():
        open_web_page("classes")

    def cocf_toggle_advisory():
        set_advisory(not advisory_enabled())

    def cocf_homework_page():
        open_web_page("homework")

    def cocf_edit_style():
        open_web_page("style")

    def cocf_edit_format():
        open_web_page("settings")

    def cocf_edit_special_dates():
        open_web_page("yearly")

    def cocf_edit_config_file():
        open_web_page("raw")

    def cocf_resize():
        open_web_page("settings")

    def cocf_app_info():
        open_web_page("about")

    def cocf_github():
        # - open github page -
        webbrowser.open_new_tab(GITHUB_URL)

    def cocf_form():
        # - open feedback / bug report form -
        webbrowser.open_new_tab(FORM_URL)

    def cocf_copyright():
        open_web_page("about")

    def cocf_close_app():
        # - closes the app (saves your settings first) -
        choice = mac_platform.alert("Close the app?", "Are you sure that you want to close the application? You can reopen it by running run.sh again.", ("Yes, save and close the app.", "No, go back!"))
        if choice == 0:
            config.save()
            window.quit_pressed()

    def cocf_reset_config():
        # - reset config to fallback -
        choice = mac_platform.alert("Reset everything?", "Are you sure that you want to reset all your information? The configuration file will be reset, meaning your color styles, classes, and year-based information will be removed. The program will revert to Owen's courses.\n\nYour homework list is kept.", ("No, go back!", "Yes, reset all my data."), warning=True)
        if choice == 1:
            reset_config_to_defaults()

    def clicked():
        mac_platform.alert("I guessed you clicked it, huh?", "Well, technically, it did something...", ("Close",))

# - config buttons -
class ConfigButton:
    def __init__(self, text, icon, color=(255, 255, 255), onclick=None, arrow=None):
        config.config_buttons.append(self)

        self.text = text
        self.icon = icon
        self.color = color
        self.arrow = arrow

        self.onclick = onclick
        self.hover_state = 0

        self.reload()

    def reload(self):
        self.surf = resources.load_icon(self.icon, layout.top_button_icon_radius, color=self.color)
        if self.arrow is not None:
            self.arrow_surf = resources.load_icon(self.arrow, layout.top_button_icon_radius, color=self.color)

    def clicked(self):
        if self.onclick is not None:
            self.onclick()

class AdvisoryToggleButton(ConfigButton):
    """Turns advisory days on or off right from the overlay."""
    def __init__(self):
        ConfigButton.__init__(self, "Advisory Days", "users", (170, 255, 170), ConfigOnClickFunctions.cocf_toggle_advisory, arrow="toggle-right")
        self.refresh()

    def refresh(self):
        on = advisory_enabled()
        self.text = "Advisory Days: On" if on else "Advisory Days: Off"
        self.color = (170, 255, 170) if on else (255, 170, 170)
        self.arrow = "toggle-right" if on else "toggle-left"
        self.reload()

exit_config = ConfigButton("Exit Configuration", "log-out", (255, 170, 170), ConfigOnClickFunctions.cocf_exit_config, arrow="square-arrow-right-exit")
edit_classes = ConfigButton("Edit Classes", "school", (170, 220, 255), ConfigOnClickFunctions.cocf_edit_classes, arrow="external-link")
advisory_button = AdvisoryToggleButton()
homework_page = ConfigButton("Homework Page", "notebook-pen", (255, 220, 170), ConfigOnClickFunctions.cocf_homework_page, arrow="external-link")
edit_style = ConfigButton("Edit Style", "paint-roller", (255, 255, 255), ConfigOnClickFunctions.cocf_edit_style, arrow="external-link")
edit_format = ConfigButton("Edit UX Variables", "monitor-cog", (200, 170, 255), ConfigOnClickFunctions.cocf_edit_format, arrow="external-link")
resize = ConfigButton("Resize Window", "scaling", (170, 220, 255), ConfigOnClickFunctions.cocf_resize, arrow="external-link")
edit_special_dates = ConfigButton("Edit Yearly Info", "calendar-days", (255, 220, 170), ConfigOnClickFunctions.cocf_edit_special_dates, arrow="external-link")
edit_config_file = ConfigButton("Edit Raw Config File", "code", (170, 255, 170), ConfigOnClickFunctions.cocf_edit_config_file, arrow="external-link")
app_info = ConfigButton("App Info", "book-text", (255, 255, 255), ConfigOnClickFunctions.cocf_app_info, arrow="external-link")
github = ConfigButton("Open GitHub", "folder-git-2", (170, 255, 170), ConfigOnClickFunctions.cocf_github, arrow="external-link")
bug_reports = ConfigButton("Bug Reports", "bug", (255, 170, 170), ConfigOnClickFunctions.cocf_form, arrow="external-link")
feedback = ConfigButton("Feedback", "message-square-reply", (200, 170, 255), ConfigOnClickFunctions.cocf_form, arrow="external-link")
copyright = ConfigButton("Copyright", "copyright", (170, 220, 255), ConfigOnClickFunctions.cocf_copyright, arrow="external-link")
source_code = ConfigButton("View Source Code", "file-code-corner", (170, 255, 170), ConfigOnClickFunctions.cocf_github, arrow="external-link")
close_app = ConfigButton("Close Application", "circle-x", (255, 170, 170), ConfigOnClickFunctions.cocf_close_app, arrow="circle-arrow-right")
reset_config = ConfigButton("Reset Configuration", "list-restart", (255, 170, 170), ConfigOnClickFunctions.cocf_reset_config, arrow="rotate-ccw")
a_button = ConfigButton("This is a button.", "mouse-pointer-click", (255, 255, 255), ConfigOnClickFunctions.clicked)

# - show / hide buttons -
class TopButton:
    def __init__(self, mode):
        resources.top_buttons.append(self)

        self.button_time = None
        self.button_hovered = False
        self.button_percent = 0
        self.hover_percent = 0

        self.mode = mode
        self.reload()

    def reload(self):
        if self.mode == "hide":
            self.button_rect = pygame.Rect(layout.top_button_padding, layout.top_button_padding, layout.width // 2 - layout.top_button_padding * 1.35, layout.top_button_height)
        elif self.mode == "show":
            self.button_rect = pygame.Rect(layout.width // 2 + layout.top_button_padding * 0.35, layout.top_button_padding, layout.width // 2 - layout.top_button_padding * 1.35, layout.top_button_height)

    def update(self):
        if self.button_rect.collidepoint((mx, my)):
            self.hover_percent = min(1, self.hover_percent + 0.06)
            if not self.button_hovered:
                self.button_hovered = True
                if self.button_time is not None and time.time() - self.button_time < 1:
                    self.button_time = 2 * time.time() - self.button_time - 1
                else:
                    self.button_time = time.time()
            else:
                self.button_percent = min(1, time.time() - self.button_time)
                if self.button_percent == 1:
                    return True
        else:
            self.hover_percent = max(0, self.hover_percent - 0.06)
            if self.button_hovered:
                self.button_hovered = False
                if self.button_time is not None and time.time() - self.button_time < 1:
                    self.button_time = 2 * time.time() - self.button_time - 1
                else:
                    self.button_time = time.time()
            else:
                if self.button_time is not None:
                    self.button_percent = max(0, 1 - time.time() + self.button_time)
        return False

show_button = TopButton("show")
hide_button = TopButton("hide")

hide_time_start = None

# <--== SETTINGS / HOMEWORK WEB PAGE ==-->
HEX_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
PERIOD_RE = re.compile(r"^[0-9A-Za-z]{1,3}$")
COLOR_KEYS = [k for k, v in DEFAULT_UI_CONFIG.items() if isinstance(v, list)]
BOOL_KEYS = [k for k, v in DEFAULT_UI_CONFIG.items() if isinstance(v, bool)]
NUMBER_RULES = {
    "default_transparency": (int, 25, 255, "Transparency"),
    "width": (int, 150, 3000, "Window width"),
    "height": (int, 50, 600, "Window height"),
    "scroll_speed": (float, 0.05, 10, "Scroll speed"),
}
YEARLY_ENCODING = "0123456789ABCDEFGHIJ"

web_bridge = web_settings.MainThreadBridge()
web_cache = {"class_courses": []}

def refresh_web_cache():
    courses = config.config["class_data"]["yearly_data"]["student_data"]["courses"]
    web_cache["class_courses"] = [copy.deepcopy(c) for c in courses if c.get("class_type") == "class"]

refresh_web_cache()

def web_state():
    # runs on the main loop
    data = config.config["class_data"]
    lunch_times = data["constant_data"].get("lunch_times", {})
    return copy.deepcopy({
        "app_version": APP_VERSION,
        "config_path": str(Config.CONFIG_PATH),
        "data_folder": str(LOCAL_APP_DIR),
        "python": platform.python_version(),
        "pygame": pygame.version.ver,
        "macos": platform.mac_ver()[0],
        "ui_config": config.config["ui_config"],
        "default_ui_config": config.fallback_config["ui_config"],
        "courses": data["yearly_data"]["student_data"]["courses"],
        "lunch_schedules": data["yearly_data"]["student_data"]["lunch_schedules"],
        "rotation_days": len(data["constant_data"]["class_schedules"]),
        "lunch_waves": max([len(v) for v in lunch_times.values()] or [5]),
        "special_dates": data["yearly_data"]["special_dates"],
        "advisory_enabled": advisory_enabled(),
        "today": hw.iso(date.today()),
        "day_text": schedule.current().timeinfo_text,
        "raw_config": json.dumps(config.config, indent=4),
    })

# - homework -
def web_homework(query):
    today = date.today()
    day = hw.parse_day(query["day"]) if query.get("day") else today
    return {"day": hw.iso(day), "today": hw.iso(today), "items": homework.list_for(day, today), "courses": web_cache["class_courses"]}

def web_homework_add(body):
    day = hw.parse_day(body.get("day") or hw.iso(date.today()))
    period = str(body.get("period") or "")
    name = next((c["class_name"] for c in web_cache["class_courses"] if c["period"] == period), "General")
    homework.add(day, period, name, body.get("text"), due_when=body.get("due_when"))
    return web_homework({"day": body.get("view_day") or hw.iso(day)})

def web_homework_set(body):
    homework.set_done(body.get("id"), as_bool(body.get("done")), date.today())
    return web_homework({"day": body.get("view_day")})

def web_homework_edit(body):
    period = body.get("period")
    name = None
    if period is not None:
        period = str(period)
        name = next((c["class_name"] for c in web_cache["class_courses"] if c["period"] == period), "General")
    due = hw.parse_day(body["day"]) if body.get("day") else None
    homework.edit(body.get("id"), text=body.get("text"), period=period, class_name=name, day=due, due_when=body.get("due_when"))
    return web_homework({"day": body.get("view_day")})

def web_homework_delete(body):
    homework.delete(body.get("id"))
    return web_homework({"day": body.get("view_day")})

# - classes -
def web_save_classes(body):
    rows = body.get("courses")
    if not isinstance(rows, list):
        raise ValueError("No classes were sent.")
    cleaned, errors, seen = [], [], {}
    for n, row in enumerate(rows, start=1):
        period = str(row.get("period", "")).strip()
        name = str(row.get("class_name", "")).strip()
        icon = str(row.get("icon", "")).strip().lower()
        color = str(row.get("accent_color", "")).strip()
        label = name or "Row %d" % n
        if not PERIOD_RE.match(period):
            errors.append("%s: the period should be 1-3 letters or numbers, like 3 or 5xA." % label)
        elif period in seen:
            errors.append("%s: period %s is already used by %s." % (label, period, seen[period]))
        else:
            seen[period] = label
        if not name:
            errors.append("Row %d: the class needs a name." % n)
        if not icons.exists(icon):
            errors.append("%s: there's no icon called \"%s\". Pick one from the suggestions." % (label, icon))
        if not HEX_RE.match(color):
            errors.append("%s: pick a color." % label)
        cleaned.append({"period": period, "class_type": "class", "accent_color": color.upper(), "icon": icon, "class_name": name})

    lunches = body.get("lunch_schedules")
    if lunches is not None:
        if not isinstance(lunches, list) or not all(isinstance(x, int) and 1 <= x <= 9 for x in lunches):
            errors.append("Pick a lunch wave for every day.")
    if errors:
        raise ValueError("\n".join(errors))

    def apply():
        candidate = copy.deepcopy(config.config)
        student = candidate["class_data"]["yearly_data"]["student_data"]
        if lunches is not None:
            student["lunch_schedules"] = lunches
        others = [c for c in student["courses"] if c.get("class_type") != "class"]
        student["courses"] = cleaned + others
        problems = schedule_problems(candidate)
        if problems:
            raise ValueError("\n".join(problems))
        ConfigOnClickFunctions.reload_all(candidate)
        return web_state()
    return web_bridge.call(apply)

# - style / settings -
def parse_color(value, label):
    if isinstance(value, str) and HEX_RE.match(value.strip()):
        return list(school_schedule.hex_to_rgb(value.strip()))
    if isinstance(value, (list, tuple)) and len(value) == 3 and all(isinstance(v, int) and 0 <= v <= 255 for v in value):
        return list(value)
    raise ValueError("%s: pick a color." % label)

def clean_ui_values(values):
    clean, errors = {}, []
    for key, value in values.items():
        try:
            if key in COLOR_KEYS:
                clean[key] = parse_color(value, key)
            elif key in BOOL_KEYS:
                clean[key] = as_bool(value)
            elif key in NUMBER_RULES:
                kind, low, high, label = NUMBER_RULES[key]
                try:
                    number = kind(str(value).strip())
                except ValueError:
                    raise ValueError("%s must be a number." % label)
                if not low <= number <= high:
                    raise ValueError("%s must be between %s and %s." % (label, low, high))
                clean[key] = str(number)
            elif key == "time_format":
                fmt = str(value).strip()
                if not fmt or len(fmt) > 40:
                    raise ValueError("Time format can't be empty.")
                datetime.now().strftime(mac_time_format(fmt))
                clean[key] = fmt
            else:
                raise ValueError("Unknown setting: %s" % key)
        except ValueError as e:
            errors.append(str(e))
    if errors:
        raise ValueError("\n".join(errors))
    return clean

def web_save_ui(body):
    clean = clean_ui_values(body.get("values") or {})

    def apply():
        ui = config.config["ui_config"]
        size_changed = any(k in clean and str(clean[k]) != str(ui.get(k)) for k in ("width", "height"))
        ui.update(clean)
        ConfigOnClickFunctions.reload_all()
        if size_changed:
            layout.update()
        if window.app_state["window_state"] == "default":
            window.set_window_alpha()
        return web_state()
    return web_bridge.call(apply)

def web_set_advisory(body):
    weekday = body.get("weekday")
    if weekday is not None:
        weekday = int(weekday)
        if not 0 <= weekday <= 4:
            raise ValueError("Advisory has to be on a weekday.")

    def apply():
        set_advisory(as_bool(body.get("enabled", True)), weekday)
        return web_state()
    return web_bridge.call(apply)

# - yearly info (import code, same format as the Windows version) -
def decode_yearly_code(code):
    code = "".join(str(code).split())

    def decode_dates(d_str):
        if len(d_str) % 2:
            raise ValueError("The import code looks cut off.")
        dates = []
        for i in range(0, len(d_str) // 2):
            base_int = YEARLY_ENCODING.index(d_str[2 * i]) * 20 + YEARLY_ENCODING.index(d_str[2 * i + 1]) + 30
            month, day = base_int // 31, base_int % 31 + 1
            if not 1 <= month <= 12:
                raise ValueError("The import code has a date that doesn't exist.")
            dates.append(str(month) + "," + str(day))
        return dates

    data = {}
    try:
        for item in code.split(";"):
            if not item:
                continue
            s = item.split(":")
            if s[0] == "Year":
                data["year"] = int(s[1])
            elif s[0] == "Adv":
                data["advisory"] = str(int(s[1]))
            elif s[0] == "Limit":
                data["school_bounds"] = decode_dates(s[1])
            elif s[0] == "NoS":
                data["no_school"] = decode_dates(s[1])
            elif s[0] == "Short":
                data["short_days"] = decode_dates(s[1])
    except (ValueError, IndexError):
        raise ValueError("That import code isn't valid. Make sure you copied all of it.")
    if len(data.get("school_bounds", [])) != 2 or "advisory" not in data:
        raise ValueError("That import code is missing the school year dates or the advisory day.")
    data.setdefault("no_school", [])
    data.setdefault("short_days", [])
    return data

def web_import_yearly(body):
    decoded = decode_yearly_code(body.get("code", ""))

    def apply():
        config.config["class_data"]["yearly_data"]["special_dates"] = decoded
        ConfigOnClickFunctions.reload_all()
        return web_state()
    return web_bridge.call(apply)

# - raw config -
def web_save_raw(body):
    try:
        parsed = json.loads(body.get("text", ""))
    except json.JSONDecodeError as e:
        raise ValueError("Please fix this JSON syntax error: %s (line %d, column %d)" % (e.msg, e.lineno, e.colno))
    if not isinstance(parsed, dict) or not isinstance(parsed.get("ui_config"), dict) or "class_data" not in parsed:
        raise ValueError("The config needs \"ui_config\" and \"class_data\" sections.")
    problems = schedule_problems(parsed)
    if problems:
        raise ValueError("\n".join(problems))

    def apply():
        for key, item in config.fallback_config["ui_config"].items():
            parsed["ui_config"].setdefault(key, copy.deepcopy(item))
        ConfigOnClickFunctions.reload_all(parsed)
        layout.update()
        if window.app_state["window_state"] == "default":
            window.set_window_alpha()
        return web_state()
    return web_bridge.call(apply)

def web_reset(body):
    def apply():
        reset_config_to_defaults()
        return web_state()
    return web_bridge.call(apply)

# - icons for the class editor -
def web_icon(query):
    color = query.get("color", "#ffffff")
    if not HEX_RE.match(color):
        color = "#ffffff"
    return "image/svg+xml", icons.svg(query.get("name", ""), stroke=color, width=24, height=24).encode("utf-8")

# - after-school events -
def web_events(query=None):
    return {"events": events_store.all(), "today": hw.iso(date.today())}

def web_events_save(body):
    saved = events_store.save(body.get("event") or {}, icons.exists)
    result = web_events()
    result["saved_id"] = saved["id"]
    if saved.get("date"):
        day = hw.parse_day(saved["date"])
        day_type = school_schedule.SchoolTime(datetime.combine(day, dtime(12)), special_days=dict(schedule.special_days)).day_type
        if day < date.today():
            result["warning"] = "That date already passed."
        elif day_type == "break":
            result["warning"] = "Heads up: there's no school on %s, so this event won't show on the overlay." % day.strftime("%A, %b %-d")
    return result

def web_events_delete(body):
    events_store.delete(body.get("id"))
    return web_events()

def web_icon_names(query):
    return {"names": list(icons.all_names()), "aliases": icons.ALIASES}

web_routes = {
    "GET": {
        "/api/state": lambda query: web_bridge.call(web_state),
        "/api/homework": web_homework,
        "/api/events": web_events,
        "/api/icons": web_icon_names,
    },
    "POST": {
        "/api/homework/add": web_homework_add,
        "/api/homework/set": web_homework_set,
        "/api/homework/edit": web_homework_edit,
        "/api/homework/delete": web_homework_delete,
        "/api/events/save": web_events_save,
        "/api/events/delete": web_events_delete,
        "/api/classes": web_save_classes,
        "/api/ui": web_save_ui,
        "/api/advisory": web_set_advisory,
        "/api/yearly": web_import_yearly,
        "/api/raw": web_save_raw,
        "/api/reset": web_reset,
    },
}

try:
    web_server = web_settings.SettingsServer(web_settings.load_token(str(LOCAL_APP_DIR / "web_token")), web_routes, {"/api/icon": web_icon}).start()
except Exception as e:
    web_server = None
    show_exception("Settings page couldn't start", "The overlay still works, but the settings and homework pages won't open.", e)

# - menu bar icon (was the tray icon on Windows) -
def refresh_tray():
    shown = window.app_state["window_shown"]
    window.tray.set_enabled("Show Window", not shown)
    window.tray.set_enabled("Hide Window", shown)
    window.tray.set_checked("Advisory Days", advisory_enabled())

def overlay_on():
    global hide_time_start
    hide_time_start = None
    window.reset_state()

def overlay_off():
    global hide_time_start
    hide_time_start = None  # stay off (don't come back after the "Hide (10s)" timer)
    window.hide_window()

def toggle_overlay():
    # clicking the menu bar clock: the overlay's on/off button
    if window.app_state["window_shown"]:
        overlay_off()
    else:
        overlay_on()

window.tray = mac_platform.StatusItem(WindowHandler.WINDOW_NAME, [
    ("Show Window", overlay_on),
    ("Hide Window", overlay_off),
    None,
    ("Homework…", lambda: open_web_page("homework")),
    ("Edit Classes…", lambda: open_web_page("classes")),
    ("Settings…", lambda: open_web_page("settings")),
    ("Advisory Days", ConfigOnClickFunctions.cocf_toggle_advisory),
    None,
    ("Quit School Schedule", window.quit_pressed),
], on_update=refresh_tray, on_click=toggle_overlay)
refresh_tray()

# - developer snapshots (SSM_SNAPSHOT_DIR=folder) -
def dev_snapshot(frame_no):
    global running
    if frame_no == 16:
        layout.height_target = layout.expanded_height
    elif frame_no == 31:
        window.app_state["window_state"] = "temp_show"
        config.config_open = True
    elif frame_no == 46:
        config.config_open = False
        homework_view.open = True
    elif frame_no > 61 and time.time() - SNAPSHOT_START >= float(os.environ.get("SSM_SNAPSHOT_HOLD", "0")):
        running = False
    names = {15: "collapsed", 30: "timeline", 45: "settings", 60: "homework"}
    if frame_no in names:
        pygame.image.save(ds, os.path.join(SNAPSHOT_DIR, names[frame_no] + ".png"))

# - important variables -

running = True

timeline_scroll = 0
frame_no = 0
SNAPSHOT_START = time.time()
mx = my = -100

layout._calculate_dependent_properties()

# <--== MAIN EXECUTION LOOP ==-->

try:
    while running:
        # - jobs from the settings page -
        web_bridge.run_pending()

        # - cursor & window info -
        rel_x, rel_y = window.mouse_relative() if not SNAPSHOT_DIR else (-100, -100)
        width_pts, height_pts = layout.width / layout.scale, layout.current_height / layout.scale
        prev_mouse_hovered = window.app_state["window_shown"] and 0 <= rel_x < width_pts and 0 <= rel_y < height_pts
        mx, my = rel_x * layout.scale, rel_y * layout.scale

        # - expand bar & expansion logic -
        if layout.update_hover() and hide_time_start is None and window.app_state["window_shown"]:
            # - reset app state -
            window.reset_state()

        # - expansion window updates -
        target_size = layout.size_points(layout.height_target)
        if round(layout.height_target) != round(layout.current_height) or tuple(window.screen.size) != target_size:
            layout.current_height = layout.height_target
            window.resize_keep_bottom(*target_size)

            ds = window.screen.get_surface()
            layout.set_scale(window.pixel_scale())  # e.g. a different display became the main one
            window.native.set_corner_radius(layout.border_radius / layout.scale)
            timeline_scroll = 0
            config.config_scroll = 0
            homework_view.scroll = 0
        base_y = round(layout.current_height) - layout.collapsed_height
        starting, height = content_area()

        # - new day: rebuild the bell times for today's date -
        # (school_schedule.py stamps every block with the date it was loaded, so an app left
        # running overnight would otherwise find no class "now" the next morning)
        if date.today() != schedule_day:
            schedule_day = date.today()
            ConfigOnClickFunctions.reload_all()
        
        # - get current schedule -
        current = schedule.current()
        if current.current_class is None:
            # the last minute before midnight isn't inside any block
            current.current_class = schedule.schedule.get_none_class(current.timeinfo.dt)
        apply_events(current)
        current_class = current.current_class
        current_course = current_class.course
        accent_color = current_course.accent_color

        temp_accent_color = accent_color if not config.config["ui_config"]["use_main_accent_color"] else config.config["ui_config"]["main_accent_color"]

        # - draw background (the window's rounded mask cuts the corners, so no magenta color key) -
        ds.fill(config.config["ui_config"]["bg_color"])

        # - draw expanded screen -
        if layout.current_height == layout.expanded_height:
            if config.config_open:
                RenderHandler.render_settings(starting, height)
            elif homework_view.open:
                RenderHandler.render_homework(starting, height)
            else:
                RenderHandler.render_schedule_preview(starting, height)

            # - draw overlays -
            draw.rect(ds, config.config["ui_config"]["bg_color"], (0, 0, layout.width, starting))
            draw.rect(ds, config.config["ui_config"]["bg_color"], (0, starting + height, layout.width, layout.expanded_height - starting - height))

            ds.blit(resources.special_surfaces["top_gradient"], (0, starting))
            ds.blit(resources.special_surfaces["bottom_gradient"], (0, starting + height - resources.special_surfaces["bottom_gradient"].height))

            # - draw visibility buttons -
            if show_button.update():
                if window.app_state["window_state"] == "default":
                    # - enable window interaction -
                    window.app_state["window_state"] = "temp_show"
                    window.set_window_alpha(255)
                    window.set_window_clickthrough(False)
                    show_button.hover_percent = 0

            if hide_button.update() and window.app_state["window_state"] != "temp_show":
                # - hide window temporarily -
                hide_time_start = time.time()
                window.hide_window()

            RenderHandler.render_top_buttons()

        if hide_time_start is not None and time.time() - hide_time_start >= 10:
            hide_time_start = None
            window.reset_state()

        # - render texts -
        RenderHandler.render_basic_texts()

        # - draw window border -
        draw.rect(ds, temp_accent_color, (0, 0, layout.width, layout.current_height), layout.border_width, border_radius=layout.border_radius)

        # - main event handler -
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button < 4 and layout.current_height == layout.expanded_height:
                    if show_button.button_rect.collidepoint((mx, my)):
                        config.config_open = not config.config_open
                        homework_view.open = False
                        show_button.hover_percent = 0
                        config.config_scroll = 0
                    elif hide_button.button_rect.collidepoint((mx, my)):
                        if window.app_state["window_state"] == "temp_show":
                            homework_view.open = not homework_view.open
                            config.config_open = False
                            hide_button.hover_percent = 0
                            homework_view.scroll = 0
                    elif not (starting <= my <= starting + height):
                        pass
                    elif config.config_open:
                        for count, i, rect in list_rows(config.config_scroll, len(config.config_buttons), starting, height):
                            if rect.collidepoint(mx, my):
                                config.config_buttons[count].clicked()
                                break
                    elif homework_view.open:
                        rows = homework_view.rows()
                        for count, i, rect in list_rows(homework_view.scroll, len(rows), starting, height):
                            if rect.collidepoint(mx, my):
                                homework_view.click(*rows[count])
                                break

            elif event.type == pygame.MOUSEWHEEL:
                if layout.current_height == layout.expanded_height and pygame.Rect(0, starting, layout.width, height).collidepoint((mx, my)):
                    delta = event.precise_y * float(config.config["ui_config"]["scroll_speed"])
                    if config.config_open:
                        config.config_scroll = max(0, min(config.config_scroll - delta, len(config.config_buttons) - 4.4))
                    elif homework_view.open:
                        homework_view.scroll = max(0, min(homework_view.scroll - delta, len(homework_view.rows()) - 4.4))
                    else:
                        stripped_schedule, shift = timeline_position()
                        timeline_scroll = max(-shift, min(len(stripped_schedule) - shift - 1, timeline_scroll - delta))

            elif event.type == pygame.WINDOWMINIMIZED or event.type == pygame.WINDOWHIDDEN:
                pygame.time.wait(500)

        if SNAPSHOT_DIR:
            frame_no += 1
            dev_snapshot(frame_no)

        window.screen.flip()
        clock.tick(60)
except KeyboardInterrupt:
    pass
except Exception as e:
    mac_platform.alert("An Exception has occurred!", "Something really, really, really bad probably happened if it wasn't caught by automated debugging. Or you typed something in a configuration menu that wasn't right. Likely, it is caused by invalid modification or corruption of the main configuration file.\n\nPaste the details below into a bug report form.", ("Ok.",), details=format_exception(e), warning=True)

window.quit_all()
