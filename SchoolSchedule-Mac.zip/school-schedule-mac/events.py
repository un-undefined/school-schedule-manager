"""After-school events, saved to events.json.

An event has a name, a start and end time ("15:30"), an icon and a color, and
either one date ("date": "2026-11-20") or weekdays it repeats on
("weekdays": [0, 2] = every Monday and Wednesday).

Events only show on school days, after the last class (main.apply_events puts
them into the day's schedule). Like homework.py, every method takes a lock
because the overlay and the settings web server both use this store.
"""

import copy
import datetime as _dt
import json
import os
import re
import threading
import uuid

TIME_RE = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
HEX_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
WEEKDAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]


def parse_time(text):
    m = TIME_RE.match(str(text or "").strip())
    if not m:
        raise ValueError("Pick a start and end time.")
    return int(m.group(1)), int(m.group(2))


class EventStore:
    def __init__(self, path):
        self.path = path
        self.lock = threading.RLock()
        self.events = []
        self._load()

    # - storage -
    def _load(self):
        if not os.path.exists(self.path):
            return
        try:
            with open(self.path, "r") as f:
                data = json.load(f)
            items = data.get("events", []) if isinstance(data, dict) else []
            self.events = [e for e in items if isinstance(e, dict) and "id" in e]
        except Exception:
            os.replace(self.path, self.path + ".broken")  # keep it instead of overwriting
            self.events = []

    def _save(self):
        tmp = self.path + ".tmp"
        with open(tmp, "w") as f:
            json.dump({"version": 1, "events": self.events}, f, indent=2)
        os.replace(tmp, self.path)

    # - checking what the page sends -
    @staticmethod
    def clean(data, icon_exists):
        name = str(data.get("name", "")).strip()
        if not name:
            raise ValueError("Give the event a name.")
        start, end = parse_time(data.get("start")), parse_time(data.get("end"))
        if end <= start:
            raise ValueError("The event has to end after it starts.")
        icon = str(data.get("icon") or "calendar-clock").strip().lower()
        if not icon_exists(icon):
            raise ValueError("There's no icon called \"%s\". Pick one from the suggestions." % icon)
        color = str(data.get("color") or "#E8A33D").strip()
        if not HEX_RE.match(color):
            raise ValueError("Pick a color for the event.")
        clean = {
            "name": name[:60],
            "start": "%d:%02d" % start,
            "end": "%d:%02d" % end,
            "icon": icon,
            "color": color.upper(),
            "date": None,
            "weekdays": [],
        }
        if data.get("repeat") == "weekly":
            days = sorted({int(d) for d in (data.get("weekdays") or [])})
            if not days or any(not 0 <= d <= 4 for d in days):
                raise ValueError("Pick at least one school day (Monday to Friday) for the event to repeat on.")
            clean["weekdays"] = days
        else:
            try:
                day = _dt.date.fromisoformat(str(data.get("date") or "")[:10])
            except ValueError:
                raise ValueError("Pick the date of the event.")
            if day.weekday() >= 5:
                raise ValueError("Events only show on school days, and %s is a weekend." % day.strftime("%A, %b %-d"))
            clean["date"] = day.isoformat()
        return clean

    # - changes -
    def save(self, data, icon_exists):
        """Add a new event, or update the one with data["id"]."""
        clean = self.clean(data, icon_exists)
        with self.lock:
            event_id = data.get("id")
            if event_id:
                for event in self.events:
                    if event["id"] == event_id:
                        event.update(clean)
                        self._save()
                        return copy.deepcopy(event)
                raise KeyError("That event no longer exists.")
            clean["id"] = uuid.uuid4().hex[:12]
            clean["created"] = _dt.datetime.now().isoformat(timespec="seconds")
            self.events.append(clean)
            self._save()
            return copy.deepcopy(clean)

    def delete(self, event_id):
        with self.lock:
            before = len(self.events)
            self.events = [e for e in self.events if e["id"] != event_id]
            if len(self.events) == before:
                raise KeyError("That event no longer exists.")
            self._save()

    # - views -
    def all(self):
        with self.lock:
            return sorted(copy.deepcopy(self.events), key=lambda e: (e["date"] is None, e["date"] or "", parse_time(e["start"])))

    def on_day(self, day):
        """Events that happen on this date, earliest first."""
        iso = day.isoformat()
        with self.lock:
            found = [copy.deepcopy(e) for e in self.events
                     if e.get("date") == iso or (not e.get("date") and day.weekday() in e.get("weekdays", []))]
        return sorted(found, key=lambda e: parse_time(e["start"]))
