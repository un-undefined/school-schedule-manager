"""Builds default.config.json.

On Windows this file was put in place by the installer. On the Mac it is
generated on first launch from the built-in schedule in school_schedule.py,
so the app works without any extra setup.
"""

import copy

import school_schedule as ss

# Style / behaviour defaults ("ui_config"). Colors are [r, g, b].
DEFAULT_UI_CONFIG = {
    "width": "376",
    "height": "94",
    "default_transparency": "200",
    "time_format": "%-I:%M %p",
    "scroll_speed": "0.7",
    "timeline_gradient": True,
    "use_main_accent_color": False,
    "main_accent_color": [76, 139, 245],
    "bg_color": [24, 25, 30],
    "progress_bar_bg_color": [45, 47, 56],
    "config_bg_color": [31, 33, 40],
    "button_bg_color": [37, 39, 47],
    "button_accent_color": [76, 139, 245],
    "text_color": [235, 236, 240],
    "muted_text_color": [140, 144, 156],
    # New in the Mac version: turn advisory days on or off.
    "advisory_enabled": True,
}


def _hm(dt):
    return "%d:%02d" % (dt.hour, dt.minute)


def _hex(rgb):
    return "#%02X%02X%02X" % tuple(rgb)


def build_default_config():
    manager = ss.ScheduleManager()  # loads the built-in ("default") schedule
    special = manager.special_days

    courses = [
        {
            "period": c.cid,
            "class_type": c.nid,
            "class_name": c.name,
            "icon": c.icon,
            "accent_color": _hex(c.accent_color),
        }
        for c in ss.ScheduleConfig.COURSES
    ]

    lunch_times = {
        day_type: [
            {"block_start": _hm(b.start_time), "block_end": _hm(b.end_time), "block_name": b.block_name}
            for b in blocks
        ]
        for day_type, blocks in ss.BlockInfo.LUNCH_TIMES.items()
    }

    block_times = {
        day_type: [
            {
                "start_time": _hm(b.start_time),
                "end_time": _hm(b.end_time),
                "block_type": b.block_type,
                "block_name": b.block_name,
            }
            for b in blocks
        ]
        for day_type, blocks in ss.BlockInfo.BLOCK_TIMES.items()
    }

    return {
        "ui_config": copy.deepcopy(DEFAULT_UI_CONFIG),
        "class_data": {
            "constant_data": {
                "class_schedules": copy.deepcopy(ss.BlockInfo.CLASS_SCHEDULES),
                "lunch_times": lunch_times,
                "block_times": block_times,
            },
            "yearly_data": {
                "student_data": {
                    "courses": courses,
                    "lunch_schedules": list(ss.ScheduleConfig.LUNCH_SCHEDULES),
                },
                "special_dates": {
                    "school_bounds": [special["school_start"], special["school_end"]],
                    "advisory": str(special["advisory"]),
                    "no_school": list(special["no_school"]),
                    "short_days": list(special["short_days"]),
                },
            },
        },
    }
