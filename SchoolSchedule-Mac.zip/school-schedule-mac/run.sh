#!/bin/bash
# Start School Schedule Manager (Mac version).
# The first run sets up a private Python environment in .venv (needs internet once).
cd "$(dirname "$0")" || exit 1

if [ ! -x .venv/bin/python ] || ! .venv/bin/python -c "import pygame, AppKit, lucide" >/dev/null 2>&1; then
  echo "Setting up (first run only)..."
  /usr/bin/python3 -m venv .venv || exit 1
  .venv/bin/python -m pip install --quiet --upgrade pip || exit 1
  .venv/bin/python -m pip install --quiet -r requirements.txt || exit 1
fi

exec .venv/bin/python main.py "$@"
