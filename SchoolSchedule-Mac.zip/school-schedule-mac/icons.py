"""Lucide icons as SVG text.

The Windows version called lucide.lucide_icon(), which comes from a different
"lucide" package than the one that installs on this Mac's Python 3.9. This
module gives the same result using the icon files bundled with the installed
package, and never crashes on an unknown icon name: it falls back to a
placeholder so a typo in "Edit Classes" can't take the whole app down.
"""

import functools
import importlib.util
import os
import zipfile
from xml.etree import ElementTree

# Icons the original app used that this icon set doesn't have (renamed upstream).
ALIASES = {
    "germ": "dna",
    "square-text": "notepad-text",
    "circle-help": "circle-question-mark",
    "help-circle": "circle-question-mark",
}

_FALLBACK_CANDIDATES = ("circle-question-mark", "circle-alert", "circle")


@functools.lru_cache(maxsize=1)
def _zip_path():
    spec = importlib.util.find_spec("lucide")
    if spec is None or spec.origin is None:
        raise RuntimeError("The 'lucide' package is not installed. Run ./run.sh to set things up.")
    return os.path.join(os.path.dirname(spec.origin), "lucide.zip")


@functools.lru_cache(maxsize=1)
def all_names():
    with zipfile.ZipFile(_zip_path()) as z:
        return tuple(sorted(n[:-4] for n in z.namelist() if n.endswith(".svg")))


@functools.lru_cache(maxsize=1)
def _name_set():
    return frozenset(all_names())


def exists(name):
    return resolve(name) is not None


def resolve(name):
    """Return the icon name that will actually be drawn, or None if unknown."""
    name = (name or "").strip().lower()
    if name in _name_set():
        return name
    alias = ALIASES.get(name)
    if alias in _name_set():
        return alias
    return None


@functools.lru_cache(maxsize=1)
def fallback_name():
    for candidate in _FALLBACK_CANDIDATES:
        if candidate in _name_set():
            return candidate
    return all_names()[0]


@functools.lru_cache(maxsize=512)
def _raw_svg(name):
    with zipfile.ZipFile(_zip_path()) as z:
        return z.read(name + ".svg").decode("utf-8")


def svg(name, **attrs):
    """SVG markup for an icon. Keyword names use underscores (stroke_width=2)."""
    real = resolve(name) or fallback_name()
    root = ElementTree.fromstring(_raw_svg(real))
    for node in root.iter():
        node.tag = node.tag.replace("{http://www.w3.org/2000/svg}", "")
    for key, value in attrs.items():
        root.attrib[key.replace("_", "-")] = str(value)
    root.attrib["xmlns"] = "http://www.w3.org/2000/svg"
    return ElementTree.tostring(root, encoding="unicode")
