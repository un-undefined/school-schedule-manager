[Setup]
AppName=WHS School Schedule Manager
AppVersion=1.0
; 1. Changed {autopf} to {userlocalappdata} so it installs directly to the user's local profile
DefaultDirName={localappdata}\WHSSchoolScheduleManager
DefaultGroupName=WHS School Schedule Manager
OutputDir=useroutput
OutputBaseFilename=WHSSchoolScheduleManagerSetup
Compression=lzma2
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64

; 2. ADD THESE LINES: Force the installer to run with lowest privileges (non-admin)
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
Name: "startup"; Description: "Create a shortcut to launch the app on computer startup"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
; Copy the main executable
Source: "app.whsssm\WHSSchoolScheduleManager.exe"; DestDir: "{app}"; Flags: ignoreversion

; Copy all internal files, including the default config
Source: "app.whsssm\_internal\*"; DestDir: "{app}\_internal"; Flags: ignoreversion recursesubdirs createallsubdirs

; Note: Because {app} now dynamically resolves to {userlocalappdata}\WHSSchoolScheduleManager,
; your source files below will install cleanly into the exact same folder location.
Source: "app.whsssm\_internal\default.config.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "app.whsssm\_internal\default.config.json"; DestName: "config.json"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
; Desktop Shortcut
Name: "{userdesktop}\WHS School Schedule Manager"; Filename: "{app}\WHSSchoolScheduleManager.exe"; Tasks: desktopicon

; Startup Shortcut
Name: "{userstartup}\WHS School Schedule Manager"; Filename: "{app}\WHSSchoolScheduleManager.exe"; Tasks: startup

[UninstallDelete]
; Updated to use {app} since everything sits in the same user-writable folder now
Type: files; Name: "{app}\default.config.json"
Type: files; Name: "{app}\config.json"
Type: dirifempty; Name: "{app}"
