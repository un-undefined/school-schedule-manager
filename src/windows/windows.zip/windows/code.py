# - stdlib imports -
import colorsys
import io
import json
import math
import os
from pathlib import Path
import platform
import sys
import time
import tkinter as tk
from tkinter import colorchooser, messagebox
import traceback
import webbrowser

if getattr(sys, 'frozen', False):
    bundle_dir = getattr(sys, '_MEIPASS', os.path.dirname(sys.executable))
    os.add_dll_directory(bundle_dir)

# - 3rd party imports -
import lucide
import pygame
from pygame import draw, gfxdraw, transform
import win32api
import win32con
import win32gui

# lucide, pygame, pystray, win32api, win32con, win32gui

# - local app imports -
import school_schedule

pygame.init()
pygame.font.init()

APP_VERSION = "1.0.0"

# <--== HELPER FUNCTIONS ==-->
def lerp(start, end, t):
    return start + (end - start) * t

def lerp_hue(h1, h2, t):
    diff = h2 - h1
    if diff > 0.5:
        h1 += 1.0
    elif diff < -0.5:
        h2 += 1.0
    
    return lerp(h1, h2, t) % 1.0

def lerp_color(color1_rgb, color2_rgb, t):
    r1, g1, b1 = [x / 255.0 for x in color1_rgb]
    r2, g2, b2 = [x / 255.0 for x in color2_rgb]
    
    rgb_lerp_r = lerp(r1, r2, t)
    rgb_lerp_g = lerp(g1, g2, t)
    rgb_lerp_b = lerp(b1, b2, t)
    
    h1, s1, v1 = colorsys.rgb_to_hsv(r1, g1, b1)
    h2, s2, v2 = colorsys.rgb_to_hsv(r2, g2, b2)
    
    if s1 == 0 or v1 == 0: h1 = h2
    if s2 == 0 or v2 == 0: h2 = h1
        
    h_blend = lerp_hue(h1, h2, t)
    s_blend = lerp(s1, s2, t)
    v_blend = lerp(v1, v2, t)
    
    hsv_lerp_r, hsv_lerp_g, hsv_lerp_b = colorsys.hsv_to_rgb(h_blend, s_blend, v_blend)
    
    final_r = (1.7 * rgb_lerp_r + 0.3 * hsv_lerp_r) / 2.0
    final_g = (1.7 * rgb_lerp_g + 0.3 * hsv_lerp_g) / 2.0
    final_b = (1.7 * rgb_lerp_b + 0.3 * hsv_lerp_b) / 2.0
    
    return (round(final_r * 255), round(final_g * 255), round(final_b * 255))

# <--== CLASSES ==-->
def get_resource_path(relative_path):
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return Path(base_path) / relative_path

LOCAL_APP_DIR = Path(os.path.expandvars(r"%localappdata%\WHSSchoolScheduleManager"))

class Config:
    CONFIG_PATH = LOCAL_APP_DIR / "config.json"
    FALLBACK_CONFIG_PATH = LOCAL_APP_DIR / "default.config.json"
    
    def __init__(self):
        with open(Config.FALLBACK_CONFIG_PATH, "r") as file:
            self.fallback_config = json.load(file)
        
        # schema test 1
        if "scroll_speed" not in self.fallback_config["ui_config"]:
            self.fallback_config["ui_config"]["scroll_speed"] = "0.7"
            json.dump(self.fallback_config, open(Config.FALLBACK_CONFIG_PATH, "w"), indent=4)
        
        self.config_open = False
        
        self.config_buttons = []
        self.config_scroll = 0
        
        self.config = self.read_from_file()

        self.save()

    def read_from_file(self):
        try:
            with open(Config.CONFIG_PATH, "r") as file:
                c = json.load(file)

                for key, item in self.fallback_config["ui_config"].items():
                    if key not in c["ui_config"]:
                        c["ui_config"][key] = item
        except Exception as e:
            traceback_lines = traceback.format_exception(e)
            traceback_string = "".join(traceback_lines)

            root = tk.Tk()
            root.title("Error Validating Configuration File")
            root.geometry("600x300")
            
            root.attributes('-topmost', True)
            
            text_widget = tk.Text(root, wrap="word", padx=10, pady=10, height=15)
            text_widget.insert("1.0", "There was an error reading your configuration file. It is likely corrupted, or a mistake was made while editing the file directly. Reverting to default values.\n\nSomething unexpected happened. Paste the below into a bug report form.\n\n" + traceback_string)
            text_widget.config(state="disabled") 
            text_widget.pack(expand=False, fill="both")
            
            button_frame = tk.Frame(root)
            button_frame.pack(pady=5)
            
            close_btn = tk.Button(button_frame, text="Ok.", command=root.destroy, width=10)
            close_btn.pack(side="left", padx=5)
            
            try:
                root.mainloop()
            except KeyboardInterrupt:
                root.destroy()
            
            return self.fallback_config
        
        return c
    
    def show_config_warning(self, e, text):
        traceback_lines = traceback.format_exception(e)
        traceback_string = "".join(traceback_lines)
        
        root = tk.Tk()
        root.title("An Exception has occured!")
        root.geometry("400x300")
        
        root.attributes('-topmost', True)
        
        text_widget = tk.Text(root, wrap="word", padx=10, pady=10, height=15)
        text_widget.insert("1.0", text + "\n\nSomething unexpected happened. Either edit the configuration file directly or click Edit Style in the config to change it back.\n\n" + traceback_string)
        text_widget.config(state="disabled") 
        text_widget.pack(expand=False, fill="both")
        
        button_frame = tk.Frame(root)
        button_frame.pack(pady=5)
        
        close_btn = tk.Button(button_frame, text="Ok.", command=root.destroy, width=10)
        close_btn.pack(side="left", padx=5)
        
        try:
            root.mainloop()
        except KeyboardInterrupt:
            root.destroy()
    
    def save(self):
        try:
            WindowHandler.DEFAULT_ALPHA_VALUE = int(self.config["ui_config"]["default_transparency"])
        except:
            pass
        try:
            float(self.config["ui_config"]["scroll_speed"])
        except Exception as e:
            self.show_config_warning(e, "You have set the scroll speed multiplier to a non-float / non-decimal value. Reverting to default scroll speed 1.3.")
            self.config["ui_config"]["scroll_speed"] = 1.3
        try:
            int(self.config["ui_config"]["width"])
        except Exception as e:
            self.show_config_warning(e, "You have set the window width to a non-integer value. Reverting to default window width 376")
            self.config["ui_config"]["width"] = 376
        try:
            int(self.config["ui_config"]["height"])
        except Exception as e:
            self.show_config_warning(e, "You have set the window height to a non-integer value. Reverting to default window height 94.")
            self.config["ui_config"]["height"] = 94
        with open(Config.CONFIG_PATH, "w") as file:
            json.dump(self.config, file, indent=4)
            file.close()

config = Config()

# - ui styling -
class Layout:
    EXPANSION_FACTOR = 4
    DEFAULT_WIDTH = int(config.fallback_config["ui_config"]["width"])
    DEFAULT_HEIGHT = int(config.fallback_config["ui_config"]["height"])
    
    def __init__(self, width=DEFAULT_WIDTH, height=DEFAULT_HEIGHT):
        self.width = int(config.config["ui_config"]["width"])
        self.collapsed_height = int(config.config["ui_config"]["height"])
        self.expanded_height = self.collapsed_height * Layout.EXPANSION_FACTOR
        self.current_height = self.collapsed_height
        self.height_target = self.collapsed_height
        
        # - window hover info -
        self.mouse_hovered = False
        self.hovered_since = None
        self.hovered_percent = 0
        
        self._calculate_dependent_properties()

    def _calculate_dependent_properties(self):
        self.class_circle_radius = round(self.collapsed_height * 31 / 94)
        self.class_icon_radius = self.class_circle_radius // 2 + 1
        self.class_progress_bar_height = self.class_circle_radius
        self.class_progress_bar_offset = (self.collapsed_height // 2 - self.class_progress_bar_height // 2) * 0.7
        self.class_progress_bar_radius = 5
        
        self.border_radius = round(self.collapsed_height * 13 / 94)
        self.border_width = round(self.collapsed_height * 3 / 94)
        
        self.top_button_padding = round(self.expanded_height * 8 / 470)
        self.top_button_height = round(self.expanded_height * 42 / 470)
        self.top_button_border = round(self.expanded_height * 2 / 470)
        self.top_button_icon_radius = round(self.expanded_height * 13 / 470)
        
        self.font_factor = (1 / 94 * self.collapsed_height)
        
        try:
            resources.reload_all()
        except NameError:
            pass

    def update(self, width=None, height=None):
        width = int(config.config["ui_config"]["width"]) if width is None else width
        height = (int(config.config["ui_config"]["height"]) * Layout.EXPANSION_FACTOR) if height is None else height
        self.height_target = self.height_target == self.collapsed_height
        self.width = width
        self.collapsed_height = height // Layout.EXPANSION_FACTOR
        self.expanded_height = height
        self.height_target = self.collapsed_height if self.height_target else self.expanded_height

        self._calculate_dependent_properties()
    
    def update_hover(self):
        if prev_mouse_hovered:
            if self.hovered_percent < 1:
                if not self.mouse_hovered:
                    if self.hovered_since is not None and time.time() - self.hovered_since < 1:
                        self.hovered_since = 2 * time.time() - self.hovered_since - 1
                    else:
                        self.hovered_since = time.time()
                    self.mouse_hovered = True
                self.hovered_percent = min(1.0, time.time() - self.hovered_since)
                if self.hovered_percent >= 1.0:
                    layout.height_target = layout.expanded_height
        else:
            if self.hovered_since is not None and self.mouse_hovered:
                if time.time() - self.hovered_since < 1:
                    self.hovered_since = 2 * time.time() - self.hovered_since - 1
                else:
                    self.hovered_since = time.time()
            self.mouse_hovered = False
            if self.hovered_percent > 0:
                self.hovered_percent = 1 - min(1.0, time.time() - self.hovered_since)
                if self.hovered_percent <= 0:
                    layout.height_target = layout.collapsed_height
                    self.hovered_since = 0
                    return True
        return False

layout = Layout()

# - window handler -
class WindowHandler:
    WINDOW_NAME = "School Schedule Manager"
    COLOR_KEY = win32api.RGB(255, 0, 255)
    try:
        DEFAULT_ALPHA_VALUE = int(config.config["ui_config"]["default_transparency"])
    except Exception as e:
        traceback_lines = traceback.format_exception(e)
        traceback_string = "".join(traceback_lines)
        
        root = tk.Tk()
        root.title("An Exception has occured!")
        root.geometry("400x300")
        
        root.attributes('-topmost', True)
        
        text_widget = tk.Text(root, wrap="word", padx=10, pady=10, height=15)
        text_widget.insert("1.0", "You have set the default transparency to a non-integer value. Reverting to default alpha 200.\n\nSomething unexpected happened. Either edit the configuration file directly or click Edit Style in the config to change it back.\n\n" + traceback_string)
        text_widget.config(state="disabled") 
        text_widget.pack(expand=False, fill="both")
        
        button_frame = tk.Frame(root)
        button_frame.pack(pady=5)
        
        close_btn = tk.Button(button_frame, text="Ok.", command=root.destroy, width=10)
        close_btn.pack(side="left", padx=5)
        
        try:
            root.mainloop()
        except KeyboardInterrupt:
            root.destroy()
        DEFAULT_ALPHA_VALUE = 200
    
    def __init__(self):
        self.monitor_width, self.monitor_height = pygame.display.get_desktop_sizes()[0]
        self.screen = pygame.Window(WindowHandler.WINDOW_NAME, size=(layout.width, layout.current_height), position=(6, self.monitor_height - 54 - layout.current_height), borderless=True, always_on_top=True)
        self.hwnd = self.screen.handle
        
        self.app_state = {
                "window_shown": True,
                "window_state": "default", # default, temp_show, temp_hide,
                "clickthrough": True,
                "window_alpha": WindowHandler.DEFAULT_ALPHA_VALUE
            }
        
        win_layout = win32gui.GetWindowLong(self.hwnd, win32con.GWL_EXSTYLE)
        win32gui.SetWindowLong(self.hwnd, win32con.GWL_EXSTYLE, win_layout | win32con.WS_EX_LAYERED | win32con.WS_EX_TRANSPARENT | 0x00000080)
        self.set_window_alpha()
        
        win32gui.SetWindowPos(self.hwnd, win32con.HWND_TOPMOST, 0, 0, 0, 0, win32con.SWP_NOMOVE | win32con.SWP_NOSIZE | win32con.SWP_FRAMECHANGED)
        
        os.environ["SDL_MOUSE_FOCUS_CLICKTHROUGH"] = "1"
        
    def get_surface(self):
        return self.screen.get_surface()
    
    # - window resize -
    
    def trigger_resize(self):
        _, _, (cur_x, cur_y) = win32gui.GetCursorInfo()
        win_x, win_y = self.screen.position
        
        bottom_y = win_y + round(layout.current_height)
        
        new_w = min(max(126, cur_x - win_x), self.monitor_width)
        new_h = min(max(94, bottom_y - cur_y), self.monitor_height)
        
        layout.update(new_w, new_h)

    # - window properties -

    def show_window(self, icon=None, item=None):
        win32gui.ShowWindow(self.hwnd, win32con.SW_SHOW)
        self.app_state["window_shown"] = True

    def hide_window(self, icon=None, item=None):
        win32gui.ShowWindow(self.hwnd, win32con.SW_HIDE)
        self.app_state["window_shown"] = False
        config.config_open = False
    
    def reset_state(self):
        self.show_window()
        self.app_state["window_state"] = "default"
        self.set_window_alpha()
        self.set_window_clickthrough(True)
        config.config_open = False
    
    def set_window_clickthrough(self, enabled=None):
        current_layout = win32gui.GetWindowLong(self.hwnd, win32con.GWL_EXSTYLE)
        enabled = (not self.app_state["clickthrough"]) if enabled is None else enabled
        if enabled:
            new_layout = current_layout | win32con.WS_EX_TRANSPARENT
        else:
            new_layout = current_layout & ~win32con.WS_EX_TRANSPARENT
            
        self.app_state["clickthrough"] = enabled
        win32gui.SetWindowLong(self.hwnd, win32con.GWL_EXSTYLE, new_layout)
    
    def set_window_alpha(self, alpha_value=None):
        alpha_value = WindowHandler.DEFAULT_ALPHA_VALUE if alpha_value is None else alpha_value
        self.app_state["window_alpha"] = alpha_value
        win32gui.SetLayeredWindowAttributes(self.hwnd, WindowHandler.COLOR_KEY, alpha_value, win32con.LWA_COLORKEY | win32con.LWA_ALPHA)

    # - quit handlers -

    def quit_all(self):
        pygame.quit()
        sys.exit()
        
    def quit_pressed(self):
        pygame.event.post(pygame.event.Event(pygame.QUIT))

window = WindowHandler()
ds = window.get_surface()

clock = pygame.time.Clock()

# - school schedule manager -
schedule = school_schedule.ScheduleManager()
schedule.reload("custom", config.config)

# - resource manager -
class ResourceManager:
    def __init__(self):
        self.top_icon_surfaces = {}
        self.top_text_surfaces = {}
        self.top_buttons = []
        
        self.special_surfaces = {}
        
    def reload_all(self):
        self.reload_fonts()
        self.reload_icons()
        self.reload_texts()
        
        self.reload_top_buttons()
        self.reload_config_icons()
        self.reload_special_surfaces()
    
    # - special surfaces -
    def reload_special_surfaces(self):
        fls = self.font_15.get_linesize()
        surf = pygame.Surface((fls, fls), pygame.SRCALPHA)
        for i in range(fls):
            draw.rect(surf, config.config["ui_config"]["bg_color"] + [min(round(255*i/fls), 255),], (i, 0, i+1, fls))
        self.special_surfaces["text_gradient"] = transform.smoothscale(surf, (fls*2, fls))
        self.special_surfaces["top_gradient"] = transform.smoothscale(transform.rotate(surf, 90), (layout.width, fls*1.5))
        self.special_surfaces["bottom_gradient"] = transform.rotate(self.special_surfaces["top_gradient"], 180)
        
    # - config icons -
    def reload_config_icons(self):
        for icon in config.config_buttons:
            icon.reload()
        
    # - top buttons -
    def reload_top_buttons(self):
        for top_button in self.top_buttons:
            top_button.reload()
    
    # - text Surfaces & fonts -
    def reload_fonts(self):
        font_path = get_resource_path("JetBrainsMono-Medium.ttf")
        
        self.font_15 = pygame.font.Font(font_path, round(15 * layout.font_factor))
        self.font_17 = pygame.font.Font(font_path, round(17 * layout.font_factor))
        self.font_20 = pygame.font.Font(font_path, round(20 * layout.font_factor))
    
    def reload_texts(self):
        self.top_text_surfaces["show"] = resources.font_15.render("Focus", True, config.config["ui_config"]["text_color"])
        self.top_text_surfaces["hide"] = resources.font_15.render("Hide (10s)", True, config.config["ui_config"]["text_color"])
        self.top_text_surfaces["settings"] = resources.font_15.render("Settings", True, config.config["ui_config"]["text_color"])
        self.top_text_surfaces["exit_settings"] = resources.font_15.render("Exit Settings", True, config.config["ui_config"]["text_color"])

    # - Lucide icons -
    def reload_icons(self):
        # - course icons -
        for course in schedule.schedule.courses:
            course.load_icon(self.load_icon(course.icon, layout.class_icon_radius), self.load_icon(course.icon, round(layout.class_icon_radius / 2)))
        
        # - top icon surfaces -
        self.top_icon_surfaces["show"] = self.load_icon("mouse-pointer-click", layout.top_button_icon_radius)
        self.top_icon_surfaces["hide"] = self.load_icon("panel-bottom-close", layout.top_button_icon_radius)
        self.top_icon_surfaces["settings"] = self.load_icon("settings", layout.top_button_icon_radius)
        self.top_icon_surfaces["exit_settings"] = self.load_icon("log-out", layout.top_button_icon_radius)

    def load_icon(self, icon_name, radius, color=(255, 255, 255)):
        r, g, b = color
        svg_string = lucide.lucide_icon(icon_name, stroke=f"#{r:02x}{g:02x}{b:02x}", width=radius * 2, height=radius * 2)
        svg_bytes = io.BytesIO(svg_string.encode("utf-8"))
        return pygame.image.load(svg_bytes, "svg").convert_alpha()

resources = ResourceManager()

# <--== UI HANDLERS & RENDERERS ==-->

# - render handler -
class RenderHandler:
    def render_basic_texts():
        # - draw primary texts -
        next_class_text = resources.font_15.render("Next Class: ", True, config.config["ui_config"]["text_color"], config.config["ui_config"]["bg_color"])
        ds.blit(next_class_text, (layout.collapsed_height * 0.9, layout.collapsed_height * 0.92 - next_class_text.height + base_y))
        
        next_class_name_text = resources.font_15.render(current.next_class.course.name, True, current.next_class.course.accent_color, config.config["ui_config"]["bg_color"])
        ds.blit(next_class_name_text, (layout.collapsed_height * 0.9 + next_class_text.width, layout.collapsed_height * 0.92 - next_class_name_text.height + base_y))
        
        # - draw progress bar -
        bar_width = layout.width - layout.collapsed_height // 2 - layout.class_circle_radius * 0.93 - layout.class_progress_bar_offset
        
        draw.rect(ds, config.config["ui_config"]["progress_bar_bg_color"], (layout.collapsed_height // 2 + layout.class_circle_radius * 0.93, layout.collapsed_height // 2 - layout.class_progress_bar_height // 2 + base_y, bar_width, layout.class_progress_bar_height), border_bottom_right_radius=layout.class_progress_bar_radius, border_top_right_radius=layout.class_progress_bar_radius)
        draw.rect(ds, accent_color, (layout.collapsed_height // 2 + layout.class_circle_radius * 0.93, layout.collapsed_height // 2 - layout.class_progress_bar_height // 2 + base_y, bar_width * current_class.class_percent, layout.class_progress_bar_height), border_bottom_right_radius=layout.class_progress_bar_radius, border_top_right_radius=layout.class_progress_bar_radius)
        
        # - draw hover expansion bar -
        bar_surface = pygame.Surface((layout.width, layout.collapsed_height * 0.08), pygame.SRCALPHA)

        pygame.draw.rect(bar_surface, temp_accent_color, (0, 0, layout.width * layout.hovered_percent, layout.collapsed_height * 0.08))
        mask = pygame.Surface((layout.width, layout.collapsed_height * 0.08), pygame.SRCALPHA)
        
        pygame.draw.rect(mask, (255, 255, 255, 255), (0, layout.collapsed_height * 0.08 - layout.current_height, layout.width, layout.current_height), border_radius=layout.border_radius)
        bar_surface.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        
        ds.blit(bar_surface, (0, layout.current_height - layout.collapsed_height * 0.08))

        # - draw secondary texts -
        percent_text = resources.font_20.render(str(round(current_class.class_percent * 100, 2)) + "%", True, config.config["ui_config"]["text_color"])
        ds.blit(percent_text, ((layout.collapsed_height * 1.1) // 2 + layout.class_circle_radius, layout.collapsed_height // 2 - percent_text.height // 2 + base_y))
        
        time_remaining_text = resources.font_20.render(current_class.time_remaining, True, config.config["ui_config"]["text_color"])
        ds.blit(time_remaining_text, (layout.collapsed_height // 2 + layout.class_circle_radius * 0.6 + bar_width - time_remaining_text.width, layout.collapsed_height // 2 - percent_text.height // 2 + base_y))
            
        day_text = resources.font_15.render(current.timeinfo_text, True, config.config["ui_config"]["text_color"], config.config["ui_config"]["bg_color"])
        day_text_pos = (layout.collapsed_height // 2 + layout.class_circle_radius * 0.6 + bar_width - day_text.width, layout.collapsed_height * 0.085 + base_y) 
        
        class_name_text = resources.font_15.render(current_course.name, True, config.config["ui_config"]["text_color"], config.config["ui_config"]["bg_color"])
        class_name_pos = (layout.collapsed_height * 0.9, layout.collapsed_height * 0.085 + base_y)
        if day_text_pos[0] < class_name_text.width + class_name_pos[0]:
            gradient = resources.special_surfaces["text_gradient"]
            if class_name_pos[0] < mx < day_text_pos[0] + day_text.width and class_name_pos[1] < my < class_name_pos[1] + class_name_text.height:
                ds.blit(class_name_text, class_name_pos, (0, 0, min(class_name_text.width, ds.width - class_name_pos[0] - layout.border_width), class_name_text.height))
                ds.blit(gradient, (ds.width - layout.border_width - class_name_text.height * 3, class_name_pos[1]))
            else:
                ds.blit(class_name_text, class_name_pos, (0, 0, min(class_name_text.width, day_text_pos[0] - class_name_pos[0]), class_name_text.height))
                ds.blit(gradient, (day_text_pos[0] - class_name_text.height * 2.3, class_name_pos[1]))
                draw.rect(ds, config.config["ui_config"]["bg_color"], (day_text_pos[0] - class_name_text.height * 2.3 + gradient.width, class_name_pos[1], gradient.width / 2, gradient.height))
                ds.blit(day_text, day_text_pos)
        else:
            ds.blit(class_name_text, class_name_pos, (0, 0, min(class_name_text.width, day_text_pos[0] - class_name_pos[0]), class_name_text.height))
            ds.blit(day_text, day_text_pos)
        
        # - draw icon circle -
        gfxdraw.filled_circle(ds, layout.collapsed_height // 2, layout.collapsed_height // 2 + base_y, layout.class_circle_radius, accent_color)
        gfxdraw.aacircle(ds, layout.collapsed_height // 2, layout.collapsed_height // 2 + base_y, layout.class_circle_radius, accent_color)
        
        # - draw icon -
        ds.blit(current_course.icon_surf, (layout.collapsed_height // 2 - layout.class_icon_radius, layout.collapsed_height // 2 - layout.class_icon_radius + base_y))

    def render_top_buttons():
        draw.rect(ds, config.config["ui_config"]["button_bg_color"], hide_button.button_rect, border_top_left_radius=round(layout.border_radius * 0.6))
        draw.rect(ds, config.config["ui_config"]["button_bg_color"], show_button.button_rect, border_top_right_radius=round(layout.border_radius * 0.6))
        
        smooth_percent = 2 * ((show_button.hover_percent) ** 0.5) - show_button.hover_percent
        center_pos = (layout.width * 3 // 4 + layout.top_button_padding * 0.35 - round(layout.top_button_padding * 0.675), layout.top_button_padding + layout.top_button_height // 2)
        
        if window.app_state["window_state"] == "temp_show":
            if config.config_open:
                text_surface = resources.top_text_surfaces["exit_settings"].copy()
                text_surface.set_alpha(round(smooth_percent * 255))
                ds.blit(text_surface, (center_pos[0] - 0.35 * text_surface.width * smooth_percent, center_pos[1] - text_surface.height // 2))
                ds.blit(resources.top_icon_surfaces["exit_settings"], (center_pos[0] - layout.top_button_icon_radius - 0.6 * text_surface.width * smooth_percent, center_pos[1] - layout.top_button_icon_radius))
            else:
                text_surface = resources.top_text_surfaces["settings"].copy()
                text_surface.set_alpha(round(smooth_percent * 255))
                ds.blit(text_surface, (center_pos[0] - 0.25 * text_surface.width * smooth_percent, center_pos[1] - text_surface.height // 2))
                ds.blit(resources.top_icon_surfaces["settings"], (center_pos[0] - layout.top_button_icon_radius - 0.55 * text_surface.width * smooth_percent, center_pos[1] - layout.top_button_icon_radius))
        else:
            text_surface = resources.top_text_surfaces["show"].copy()
            text_surface.set_alpha(round(smooth_percent * 255))
            ds.blit(text_surface, (center_pos[0] - 0.2 * text_surface.width * smooth_percent, center_pos[1] - text_surface.height // 2))
            ds.blit(resources.top_icon_surfaces["show"], (center_pos[0] - layout.top_button_icon_radius - 0.8 * text_surface.width * smooth_percent, center_pos[1] - layout.top_button_icon_radius))
        
        smooth_percent = 2 * ((hide_button.hover_percent) ** 0.5) - hide_button.hover_percent
        center_pos = (round(layout.top_button_padding * 0.325) + layout.width // 4, layout.top_button_padding + layout.top_button_height // 2)
        
        text_surface = resources.top_text_surfaces["hide"].copy()
        text_surface.set_alpha(round(smooth_percent * 255))
        ds.blit(text_surface, (center_pos[0] - 0.3 * text_surface.width * smooth_percent, center_pos[1] - text_surface.height // 2))
        ds.blit(resources.top_icon_surfaces["hide"], (center_pos[0] - layout.top_button_icon_radius - 0.6 * text_surface.width * smooth_percent, center_pos[1] - layout.top_button_icon_radius))
        
        draw.rect(ds, config.config["ui_config"]["button_accent_color"], (hide_button.button_rect.x, hide_button.button_rect.y + hide_button.button_rect.height * 0.9, hide_button.button_percent * hide_button.button_rect.width, hide_button.button_rect.height * 0.1))
        if window.app_state["window_state"] != "temp_show":
            draw.rect(ds, config.config["ui_config"]["button_accent_color"], (show_button.button_rect.x, show_button.button_rect.y + show_button.button_rect.height * 0.9, show_button.button_percent * show_button.button_rect.width, show_button.button_rect.height * 0.1))

    def render_schedule_preview(starting, height):
        # - calculate schedule display -
        stripped_schedule = []
        for _class in current.schedule:
            if _class.course.name != "Transition":
                stripped_schedule.append(_class)
        
        current_course = current.current_class.course
        _class = current.current_class
        if _class.course.name == "Transition":
            prev_class = None
            for iclass in current.schedule:
                if iclass.course.name != "Transition":
                    prev_class = iclass
                elif iclass == _class:
                    break
            _class = prev_class
        shift = stripped_schedule.index(_class)
        
        # - draw timeline -
        for k in range(6):
            i = k
            count = i - 2 + shift + math.floor(timeline_scroll)
            if current_course.name == "Transition":
                i -= 0.5
            i -= timeline_scroll % 1
            if count < 0 or count >= len(stripped_schedule):
                continue
            rendering_class = stripped_schedule[count]
            rendering_course = rendering_class.course
            color = rendering_course.accent_color
            if len(stripped_schedule) > count + 1:
                next_color = stripped_schedule[count + 1].course.accent_color
                if i < 5 * (config.config["ui_config"]["timeline_gradient"]):
                    section_height = round(height * (0.9 - 0.2 * i)) if i == 4 else round(height / 5)
                    for j in range(section_height):
                        c = lerp_color(color, next_color, min(1, j / (height / 5)))
                        draw.rect(ds, c, (layout.width * 0.08, starting + height / 5 * (i + 0.5) + j, layout.width * 0.015, 1))
                else:
                    draw.rect(ds, color, (layout.width * 0.08, starting + height / 5 * (i + 0.5), layout.width * 0.015, height / 5 * (4.5 - i)))
            draw.circle(ds, color, (layout.width * 0.0875, starting + height / 5 * (i + 0.5)), layout.width / 50)
            
            ds.blit(rendering_course.small_icon_surf, (layout.width * 0.195, starting + height / 5 * (i + 0.125)))
            
            primary_text = resources.font_17.render(rendering_course.name, True, config.config["ui_config"]["text_color"])
            ds.blit(primary_text, (layout.width * 0.26, starting + height / 5 * (i + 0.05)))
            
            subtext = rendering_class.start_time.strftime(config.config["ui_config"]["time_format"]) + " - " + rendering_class.end_time.strftime(config.config["ui_config"]["time_format"])
            small_text = resources.font_15.render(subtext, True, config.config["ui_config"]["muted_text_color"])
            ds.blit(small_text, (layout.width * 0.195, starting + height / 5 * (i + 0.46)))
        
        # - draw arrow - 
        arrow_surf = resources.font_17.render("<", True, config.config["ui_config"]["text_color"])
        ds.blit(arrow_surf, (layout.width * 0.14, starting + height / 2 - arrow_surf.height / 2 + height / 5 * (-timeline_scroll)))

    def render_settings(starting, height):
        buttons = config.config_buttons
        for k in range(6):
            i = k
            count = i + math.floor(config.config_scroll)
            i -= config.config_scroll % 1
            if count < 0 or count >= len(buttons):
                continue
            button = buttons[count]
            
            rect = pygame.Rect((0, starting + height / 5 * (i + 0.4), layout.width, height / 6))
            hovered = rect.collidepoint(mx, my)
            if hovered and window.app_state["window_state"] == "temp_show":
                button.hover_state = min(1, button.hover_state + 0.1)
            else:
                button.hover_state = max(0, button.hover_state - 0.1)
            hover_anim = 1 - ((1 - button.hover_state) ** 1.6)
            bg_color = lerp_color(config.config["ui_config"]["config_bg_color"], button.color, hover_anim * 0.15)
            draw.rect(ds, bg_color, rect)
            
            ds.blit(button.surf, (layout.width * 0.06, starting + height / 5 * (i + 0.62)))
            text = "This is a pointless button." if button.text == "This is a button." and hovered else button.text
            button_text = resources.font_17.render(text, True, button.color)
            ds.blit(button_text, (layout.width * 0.15, starting + height / 5 * (i + 0.6)))

            if button.arrow is not None:
                ds.blit(button.arrow_surf, (layout.width * (0.82 + hover_anim * 0.05), starting + height / 5 * (i + 0.62)))

# - config buttons onclick -
class ConfigOnClickFunctions:
    def reload_all(config_json=None):
        if config_json is not None:
            config.config = config_json
        config.save()
        schedule.reload("custom", config.config)
        resources.reload_all()
    
    def cocf_exit_config():
        # - closes the config -`
        config.config_open = False
    
    def cocf_edit_classes():
        try:
            all_courses = config.config["class_data"]["yearly_data"]["student_data"]["courses"]
        except (KeyError, AttributeError):
            messagebox.showerror("Error", "Could not find course data at config.config['class_data']['yearly_data']['student_data']['courses']!")
            return
    
        class_courses = [c for c in all_courses if c.get("class_type") == "class"]
        other_courses = [c for c in all_courses if c.get("class_type") != "class"]
    
        root = tk.Tk()
        root.title("Class Manager")
        root.geometry("750x520")
    
        main_frame = tk.Frame(root, padx=15, pady=15)
        main_frame.pack(fill=tk.BOTH, expand=True)
    
        tk.Label(main_frame, text="Manage Classes").pack(anchor="w", pady=(0, 10))
    
        container = tk.Frame(main_frame)
        container.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
    
        canvas = tk.Canvas(container, borderwidth=0, highlightthickness=0)
        scrollbar = tk.Scrollbar(container, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)
    
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
    
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
    
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    
        row_widgets = []
    
        def populate_rows():
            for widget in scrollable_frame.winfo_children():
                widget.destroy()
            row_widgets.clear()
    
            header_frame = tk.Frame(scrollable_frame)
            header_frame.pack(fill=tk.X, padx=5, pady=2)
            tk.Label(header_frame, text="Period", width=8, anchor="w").pack(side=tk.LEFT, padx=2)
            tk.Label(header_frame, text="Class Name", width=22, anchor="w").pack(side=tk.LEFT, padx=2)
            tk.Label(header_frame, text="Icon", width=16, anchor="w").pack(side=tk.LEFT, padx=2)
            tk.Label(header_frame, text="Accent Color", width=14, anchor="w").pack(side=tk.LEFT, padx=2)
    
            for course in class_courses:
                add_course_row(course)
    
        def add_course_row(course_data=None):
            if course_data is None:
                course_data = {"period": "", "class_name": "", "icon": "", "accent_color": "#D99B26"}
    
            row_frame = tk.Frame(scrollable_frame, pady=4)
            row_frame.pack(fill=tk.X, padx=5)
    
            period_var = tk.StringVar(value=str(course_data.get("period", "")))
            name_var = tk.StringVar(value=course_data.get("class_name", ""))
            icon_var = tk.StringVar(value=course_data.get("icon", ""))
            color_var = tk.StringVar(value=course_data.get("accent_color", "#D99B26"))
    
            tk.Entry(row_frame, textvariable=period_var, width=8).pack(side=tk.LEFT, padx=2)
            tk.Entry(row_frame, textvariable=name_var, width=22).pack(side=tk.LEFT, padx=2)
            tk.Entry(row_frame, textvariable=icon_var, width=16).pack(side=tk.LEFT, padx=2)
            tk.Entry(row_frame, textvariable=color_var, width=12).pack(side=tk.LEFT, padx=2)
    
            def pick_color():
                chosen = colorchooser.askcolor(color=color_var.get())
                if chosen[1]:
                    color_var.set(chosen[1])
                    color_btn.config(bg=chosen[1])
    
            color_btn = tk.Button(row_frame, text="🎨", bg=color_var.get(), width=7, command=pick_color)
            color_btn.pack(side=tk.LEFT, padx=2)
    
            def delete_row():
                row_frame.destroy()
                if row_info in row_widgets:
                    row_widgets.remove(row_info)
    
            tk.Button(row_frame, text="Delete", command=delete_row, fg="red").pack(side=tk.LEFT, padx=6)
    
            row_info = {
                "period_var": period_var,
                "name_var": name_var,
                "icon_var": icon_var,
                "color_var": color_var
            }
            row_widgets.append(row_info)
    
        def on_add_click():
            add_course_row()
            canvas.update_idletasks()
            canvas.configure(scrollregion=canvas.bbox("all"))
    
        def on_save_click():
            updated_classes = []
            for rw in row_widgets:
                updated_classes.append({
                    "period": rw["period_var"].get().strip(),
                    "class_type": "class",
                    "accent_color": rw["color_var"].get().strip(),
                    "icon": rw["icon_var"].get().strip(),
                    "class_name": rw["name_var"].get().strip()
                })
            
            config.config["class_data"]["yearly_data"]["student_data"]["courses"] = updated_classes + other_courses
            ConfigOnClickFunctions.reload_all()
            
            root.destroy()
    
        def on_cancel_click():
            root.destroy()
    
        btn_frame = tk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=5)
    
        def open_link():
            webbrowser.open_new_tab("https://lucide.dev/icons/")
    
        tk.Button(btn_frame, text="+ Add Class", command=on_add_click, bg="#4CAF50", fg="black", width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Icon Help", command=open_link, bg="#EF4444", fg="black", width=15).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Cancel", command=on_cancel_click, width=15).pack(side=tk.RIGHT, padx=5)
        tk.Button(btn_frame, text="Save", command=on_save_click, bg="#2196F3", fg="black", width=15).pack(side=tk.RIGHT, padx=5)
    
        populate_rows()
        root.mainloop()

    def cocf_edit_style():
        root = tk.Tk()
        root.title("Edit Style")
        root.geometry(f"450x350+{10+layout.width}+{layout.new_y + layout.expanded_height - 385}")
        
        fields = [
            ("Timeline Gradient", "timeline_gradient", "checkbox", "The timeline gradient determines whether the timeline will have a gradient."),
            ("Use Custom Accent Color", "use_main_accent_color", "checkbox", "This determines whether the set accent color or the accent color of the current class will be used"),
            ("Main Accent Color", "main_accent_color", "color", "The main accent color determines the color of the border and class progress bar."),
            ("Background Color", "bg_color", "color", "The background color determines the color of the background."),
            ("Progress Bar Background Color", "progress_bar_bg_color", "color", "The progress bar background color determines the color of the progress bar's background."),
            ("Config Button Background Color", "config_bg_color", "color", "The configuration button background color determines the background color of the configuration buttons."),
            ("Button Background Color", "button_bg_color", "color", "The button background color determines the color of the button's background."),
            ("Button Accent Color", "button_accent_color", "color", "The button accent color determines the accent color of the buttons."),
            ("Text Color", "text_color", "color", "The text color determines the color of the text."),
            ("Muted Text Color", "muted_text_color", "color", "The muted text color determines the 'disabled' color of the text."),
        ]
        
        entries = {}
        
        def set_widget_value(field_id, value):
            widget_info = entries[field_id]
            w_type = widget_info["type"]
            
            if w_type in ("text", "color"):
                widget_info["widget"].delete(0, tk.END)
                widget_info["widget"].insert(0, str(value))
            elif w_type == "checkbox":
                if str(value).lower() in ("true", "1", "yes"):
                    widget_info["variable"].set(True)
                else:
                    widget_info["variable"].set(False)
        
        def get_widget_value(field_id):
            widget_info = entries[field_id]
            w_type = widget_info["type"]
            
            if w_type == "text":
                return widget_info["widget"].get()
            elif w_type == "color":
                return list(school_schedule.hex_to_rgb(widget_info["widget"].get()))
            elif w_type == "checkbox":
                return widget_info["variable"].get()
        
        def reset_to_default(field_id, default_value):
            set_widget_value(field_id, default_value)
            
        def rgb_to_hex(c):
            if c is None: return None
            if isinstance(c, str): return c
            if isinstance(c, int): return c
            r, g, b = c
            return f"#{r:02x}{g:02x}{b:02x}"
            
        def pick_color(entry_widget):
            current_color = entry_widget.get()
            color_code = colorchooser.askcolor(initialcolor=rgb_to_hex(current_color) if current_color else None)[1]
            if color_code:
                entry_widget.delete(0, tk.END)
                entry_widget.insert(0, color_code)
        
        title_label = tk.Label(root, text="Edit Style Options")
        title_label.pack(pady=10)
    
        outer_container = tk.Frame(root)
        outer_container.pack(fill="both", expand=True, padx=10)
        
        canvas = tk.Canvas(outer_container, highlightthickness=0)
        canvas.pack(side="left", fill="both", expand=True)
        
        scrollbar = tk.Scrollbar(outer_container, orient="vertical", command=canvas.yview)
        scrollbar.pack(side="right", fill="y")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        form_frame = tk.Frame(canvas)
        
        canvas_window = canvas.create_window((0, 0), window=form_frame, anchor="nw")
        
        def on_frame_configure(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
        
        def on_canvas_configure(event):
            canvas.itemconfig(canvas_window, width=event.width)
        
        form_frame.bind("<Configure>", on_frame_configure)
        canvas.bind("<Configure>", on_canvas_configure)
        
        def on_mouse_wheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        
        root.bind_all("<MouseWheel>", on_mouse_wheel)
        
        for i, (field_name, field_id, option_type, field_desc) in enumerate(fields):
            label = tk.Label(form_frame, text=field_name, anchor="w")
            label.grid(row=i * 2, column=0, padx=5, pady=(5, 2), sticky="w")
        
            if option_type == "text":
                entry = tk.Entry(form_frame)
                entry.grid(row=i * 2, column=1, padx=5, pady=(5, 2), sticky="ew")
                entries[field_id] = {"type": "text", "widget": entry}
                
            elif option_type == "color":
                color_frame = tk.Frame(form_frame)
                color_frame.grid(row=i * 2, column=1, padx=5, pady=(5, 2), sticky="ew")
                color_frame.columnconfigure(0, weight=1)
                
                entry = tk.Entry(color_frame)
                entry.grid(row=0, column=0, sticky="ew")
                
                color_btn = tk.Button(color_frame, text=">", width=3, command=lambda e=entry: pick_color(e))
                color_btn.grid(row=0, column=1, padx=(2, 0))
                
                entries[field_id] = {"type": "color", "widget": entry}
                
            elif option_type == "checkbox":
                var = tk.BooleanVar()
                chk = tk.Checkbutton(form_frame, variable=var, anchor="w")
                chk.grid(row=i * 2, column=1, padx=5, pady=(5, 2), sticky="w")
                entries[field_id] = {"type": "checkbox", "widget": chk, "variable": var}
        
            initial_val = config.config["ui_config"].get(field_id, "")
            initial_val = rgb_to_hex(initial_val) if option_type == "color" else initial_val
            initial_val = str(initial_val) if option_type == "text" else initial_val
            set_widget_value(field_id, initial_val)
            
            fallback_val = rgb_to_hex(config.fallback_config["ui_config"].get(field_id, ""))
            reset_btn = tk.Button(
                form_frame, 
                text="Reset", 
                command=lambda fid=field_id, fval=fallback_val: reset_to_default(fid, fval), 
                width=8
            )
            reset_btn.grid(row=i * 2, column=2, padx=5, pady=(5, 2), sticky="e")
        
            description = tk.Label(form_frame, text=field_desc, justify="left", anchor="w", wraplength=410)
            description.grid(row=i * 2 + 1, column=0, columnspan=3, padx=5, pady=(0, 5), sticky="w")
        
        form_frame.columnconfigure(1, weight=1)
        
        def save_config():
            for field_name, field_id, option_type, field_desc in fields:
                config.config["ui_config"][field_id] = get_widget_value(field_id)
            config.save()
            ConfigOnClickFunctions.reload_all(config.config)
            try:
                root.destroy()
            except tk.TclError:
                pass
        
        button_frame = tk.Frame(root)
        button_frame.pack(pady=10)
        
        dont_save_btn = tk.Button(button_frame, text="Cancel", command=root.destroy, width=15)
        dont_save_btn.pack(side="left", padx=5, fill="x")
        
        save_btn = tk.Button(button_frame, text="Save and Close", command=save_config, width=15)
        save_btn.pack(side="left", padx=5, fill="x")
        
        root.mainloop()

    def cocf_edit_format():
        root = tk.Tk()
        root.title("Edit User Experience Variables")
        root.geometry(f"450x350+{10+layout.width}+{layout.new_y + layout.expanded_height - 385}")

        fields = [
            ("Default Transparency", "default_transparency", "text", "The default transparency determines the default transparency."),
            ("Time Format", "time_format", "text", "The time format determines how the time is shown on the timeline. For example, '%#I:%M %p' changes the time format to standard 12 hour time, while '%H:%M' is for 24 hour time."),
            ("Scroll Speed", "scroll_speed", "text", "The scroll speed determines the multiplier of the speed of scrolling in the timeline and the configuration menu."),
            ("Window Width", "width", "text", "The window width determines the width of the window when the menu is NOT OPEN."),
            ("Window Height", "height", "text", "The window height determines the height of the window when the menu is NOT OPEN.")
        ]
        
        entries = {}
        
        def set_widget_value(field_id, value):
            widget_info = entries[field_id]
            w_type = widget_info["type"]
            
            if w_type in ("text", "color"):
                widget_info["widget"].delete(0, tk.END)
                widget_info["widget"].insert(0, str(value))
            elif w_type == "checkbox":
                if str(value).lower() in ("true", "1", "yes"):
                    widget_info["variable"].set(True)
                else:
                    widget_info["variable"].set(False)
        
        def get_widget_value(field_id):
            widget_info = entries[field_id]
            w_type = widget_info["type"]
            
            if w_type == "text":
                return widget_info["widget"].get()
            elif w_type == "color":
                return list(school_schedule.hex_to_rgb(widget_info["widget"].get()))
            elif w_type == "checkbox":
                return widget_info["variable"].get()
        
        def reset_to_default(field_id, default_value):
            set_widget_value(field_id, default_value)
            
        def rgb_to_hex(c):
            if c is None: return None
            if isinstance(c, str): return c
            if isinstance(c, int): return c
            r, g, b = c
            return f"#{r:02x}{g:02x}{b:02x}"
            
        def pick_color(entry_widget):
            current_color = entry_widget.get()
            color_code = colorchooser.askcolor(initialcolor=rgb_to_hex(current_color) if current_color else None)[1]
            if color_code:
                entry_widget.delete(0, tk.END)
                entry_widget.insert(0, color_code)
        
        title_label = tk.Label(root, text="Edit User Experience Variables")
        title_label.pack(pady=10)
    
        outer_container = tk.Frame(root)
        outer_container.pack(fill="both", expand=True, padx=10)
        
        canvas = tk.Canvas(outer_container, highlightthickness=0)
        canvas.pack(side="left", fill="both", expand=True)
        
        scrollbar = tk.Scrollbar(outer_container, orient="vertical", command=canvas.yview)
        scrollbar.pack(side="right", fill="y")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        form_frame = tk.Frame(canvas)
        
        canvas_window = canvas.create_window((0, 0), window=form_frame, anchor="nw")
        
        def on_frame_configure(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
        
        def on_canvas_configure(event):
            canvas.itemconfig(canvas_window, width=event.width)
        
        form_frame.bind("<Configure>", on_frame_configure)
        canvas.bind("<Configure>", on_canvas_configure)
        
        def on_mouse_wheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        
        root.bind_all("<MouseWheel>", on_mouse_wheel)
        
        for i, (field_name, field_id, option_type, field_desc) in enumerate(fields):
            label = tk.Label(form_frame, text=field_name, anchor="w")
            label.grid(row=i * 2, column=0, padx=5, pady=(5, 2), sticky="w")
        
            if option_type == "text":
                entry = tk.Entry(form_frame)
                entry.grid(row=i * 2, column=1, padx=5, pady=(5, 2), sticky="ew")
                entries[field_id] = {"type": "text", "widget": entry}
                
            elif option_type == "color":
                color_frame = tk.Frame(form_frame)
                color_frame.grid(row=i * 2, column=1, padx=5, pady=(5, 2), sticky="ew")
                color_frame.columnconfigure(0, weight=1)
                
                entry = tk.Entry(color_frame)
                entry.grid(row=0, column=0, sticky="ew")
                
                color_btn = tk.Button(color_frame, text="🎨", width=3, command=lambda e=entry: pick_color(e))
                color_btn.grid(row=0, column=1, padx=(2, 0))
                
                entries[field_id] = {"type": "color", "widget": entry}
                
            elif option_type == "checkbox":
                var = tk.BooleanVar()
                chk = tk.Checkbutton(form_frame, variable=var, anchor="w")
                chk.grid(row=i * 2, column=1, padx=5, pady=(5, 2), sticky="w")
                entries[field_id] = {"type": "checkbox", "widget": chk, "variable": var}
        
            initial_val = config.config["ui_config"].get(field_id, "")
            initial_val = rgb_to_hex(initial_val) if option_type == "color" else initial_val
            initial_val = str(initial_val) if option_type == "text" else initial_val
            set_widget_value(field_id, initial_val)
            
            fallback_val = rgb_to_hex(config.fallback_config["ui_config"].get(field_id, ""))
            reset_btn = tk.Button(
                form_frame, 
                text="Reset", 
                command=lambda fid=field_id, fval=fallback_val: reset_to_default(fid, fval), 
                width=8
            )
            reset_btn.grid(row=i * 2, column=2, padx=5, pady=(5, 2), sticky="e")
        
            description = tk.Label(form_frame, text=field_desc, justify="left", anchor="w", wraplength=410)
            description.grid(row=i * 2 + 1, column=0, columnspan=3, padx=5, pady=(0, 5), sticky="w")
        
        form_frame.columnconfigure(1, weight=1)
        
        def save_config():
            for field_name, field_id, option_type, field_desc in fields:
                config.config["ui_config"][field_id] = get_widget_value(field_id)
            config.save()
            ConfigOnClickFunctions.reload_all(config.config)
            try:
                root.destroy()
            except tk.TclError:
                pass

        def open_link():
            webbrowser.open_new_tab("https://docs.python.org/3/library/datetime.html#format-codes")

        button_frame = tk.Frame(root)
        button_frame.pack(pady=10)
        
        tf_docs_btn = tk.Button(button_frame, text="Time Format Docs", command=open_link, width=15)
        tf_docs_btn.pack(side="left", padx=5, fill="x")
        
        dont_save_btn = tk.Button(button_frame, text="Cancel", command=root.destroy, width=15)
        dont_save_btn.pack(side="left", padx=5, fill="x")

        save_btn = tk.Button(button_frame, text="Save and Close", command=save_config, width=15)
        save_btn.pack(side="left", padx=5, fill="x")

        root.mainloop()

    def cocf_edit_special_dates():
        root = tk.Tk()
        root.title("Edit Special Dates")
        root.geometry(f"450x350+{10+layout.width}+{layout.new_y + layout.expanded_height - 385}")
        
        encoding = "0123456789ABCDEFGHIJ"

        def decode_dates(d_str):
            dates = []
            for i in range(0, len(d_str) // 2):
                base_int = encoding.index(d_str[2 * i]) * 20 + encoding.index(d_str[2 * i + 1]) + 30
                dates.append(str(base_int // 31) + "," + str(base_int % 31 + 1))
            return dates

        def decode(d_str):
            rawdata = d_str.split(";")
            data = {}
            for item in rawdata:
                s = item.split(":")
                if s[0] == "Year":
                    data["year"] = int(s[1])
                elif s[0] == "Adv":
                    data["advisory"] = s[1]
                elif s[0] == "Limit":
                    data["school_bounds"] = decode_dates(s[1])
                elif s[0] == "NoS":
                    data["no_school"] = decode_dates(s[1])
                elif s[0] == "Short":
                    data["short_days"] = decode_dates(s[1])
            return data
        
        def save_config():
            if str(import_text.get("1.0", "end-1c")) != "":
                decoded = decode(str(import_text.get("1.0", "end-1c")))
                config.config["class_data"]["yearly_data"]["special_dates"] = decoded
                ConfigOnClickFunctions.reload_all()
                try:
                    root.destroy()
                except tk.TclError:
                    pass
        
        main_container = tk.Frame(root)
        main_container.pack(expand=True, fill="both", padx=20, pady=10)
        
        instruction_label = tk.Label(main_container, text="Paste import code here:")
        instruction_label.pack(anchor="w", pady=(0, 5))
        
        import_text = tk.Text(main_container, height=10, width=40)
        import_text.pack(expand=True, fill="both", pady=(0, 10))
        
        button_frame = tk.Frame(main_container)
        button_frame.pack(side="bottom", pady=10)
        
        dont_save_btn = tk.Button(button_frame, text="Cancel", command=root.destroy, width=15)
        dont_save_btn.pack(side="left", padx=5)
        
        save_btn = tk.Button(button_frame, text="Save and Close", command=save_config, width=15)
        save_btn.pack(side="left", padx=5)
        
        root.mainloop()
        
    def cocf_edit_config_file():
        # - open Tk window for JSON editing -
        root = tk.Tk()
        root.title("Edit Raw JSON Configuration")
        root.geometry(f"800x500+{10+layout.width}+{layout.new_y + layout.expanded_height - 535}")

        initial_json_str = json.dumps(config.config, indent=4)
        
        header_frame = tk.Frame(root)
        header_frame.pack(fill="x", padx=15, pady=(12, 5))
        
        title_label = tk.Label(
            header_frame,
            text="Edit JSON Configuration File. Use at your own risk. Invalid values may silently trigger crashes.",
            anchor="w"
        )
        title_label.pack(fill="x")

        text_area = tk.Text(root, wrap="word", width=50, height=20)
        text_area.insert("1.0", initial_json_str)
        text_area.pack(padx=10, pady=10, fill="both", expand=True)

        def save_and_close():
            raw_content = text_area.get("1.0", "end-1c")

            try:
                parsed_json = json.loads(raw_content)
                if not isinstance(parsed_json, dict):
                    raise ValueError("JSON root must be a dictionary/object.")

                try:
                    root.destroy()
                except tk.TclError:
                    pass
                
                ConfigOnClickFunctions.reload_all(parsed_json)
                layout.update()
            except (json.JSONDecodeError, ValueError) as e:
                tk.messagebox.showerror(
                    "Invalid JSON", f"Please fix JSON syntax errors:\n{e}"
                )

        def open_link():
            webbrowser.open_new_tab("https://stackoverflow.blog/2022/06/02/a-beginners-guide-to-json-the-data-format-for-the-internet/")

        button_frame = tk.Frame(root)
        button_frame.pack(pady=(0, 10))

        json_button = tk.Button(button_frame, text="JSON Help", command=open_link, width=20)
        json_button.pack(side="left", padx=5)

        dont_save_button = tk.Button(button_frame, text="Cancel", command=root.destroy, width=20)
        dont_save_button.pack(side="left", padx=5)

        save_button = tk.Button(button_frame, text="Save and Close", command=save_and_close, width=20)
        save_button.pack(side="left", padx=5)

        try:
            root.mainloop()
        except KeyboardInterrupt:
            root.destroy()
    
    def cocf_resize():
        root = tk.Tk()
        root.title("Resize Window")
        root.geometry(f"400x180+{10+layout.width}+{layout.new_y + layout.expanded_height - 275}")
        
        def validate_int(P):
            if P == "" or P.isdigit():
                return True
            return False
        
        vcmd = (root.register(validate_int), '%P')
        
        input_frame = tk.Frame(root)
        input_frame.pack(pady=15, fill="x", padx=15)
        
        title_label = tk.Label(
            input_frame, 
            text="The size is measured in pixels. The size is when the menu is CLOSED, so the height will seem way larger.",
            wraplength=370, 
            justify="left"
        )
        title_label.pack(pady=5, anchor="w")
        
        width_frame = tk.Frame(input_frame)
        width_frame.pack(side="left", padx=20)
        
        width_entry = tk.Entry(width_frame, width=10, validate="key", validatecommand=vcmd)
        width_entry.pack(anchor="w")
        width_entry.insert(0, str(config.config["ui_config"]["width"]))
        
        width_label = tk.Label(width_frame, text="Width")
        width_label.pack(pady=2, anchor="w")
        
        height_frame = tk.Frame(input_frame)
        height_frame.pack(side="left", padx=20)
        
        height_entry = tk.Entry(height_frame, width=10, validate="key", validatecommand=vcmd)
        height_entry.pack(anchor="w")
        height_entry.insert(0, str(config.config["ui_config"]["height"]))
        
        height_label = tk.Label(height_frame, text="Height")
        height_label.pack(pady=2, anchor="w")
        
        def save_config():
            w_val = width_entry.get()
            h_val = height_entry.get()
            
            if not w_val or not h_val:
                messagebox.showerror("Error", "Width and Height cannot be empty.")
                return
                
            config.config["ui_config"]["width"] = str(w_val)
            config.config["ui_config"]["height"] = str(h_val)
            layout.update()
            ConfigOnClickFunctions.reload_all()
            
            try:
                root.destroy()
            except tk.TclError:
                pass
        
        button_frame = tk.Frame(root)
        button_frame.pack(pady=10)
        
        dont_save_button = tk.Button(button_frame, text="Cancel", command=root.destroy, width=15)
        dont_save_button.pack(side="left", padx=5)
        
        save_button = tk.Button(button_frame, text="Save", command=save_config, width=15)
        save_button.pack(side="left", padx=5)
        
        try:
            root.mainloop()
        except KeyboardInterrupt:
            root.destroy()


    def cocf_app_info():
        # - app info window -
        pinfo = platform.uname()
        
        APP_INFO_TEXT = f"""App & System Information
        
OS Name: {pinfo.system} ("{pinfo.node}")
Full Info: {pinfo.system} {pinfo.release}, {pinfo.machine}, {pinfo.version}

Here's your Python versions:
    Python {sys.version}
    Pygame {pygame.version.ver}

And, the app version is {APP_VERSION}
The configuration filepath is
    Default R/W: {Config.CONFIG_PATH}
    Fallback: {Config.FALLBACK_CONFIG_PATH}"""
     
        def open_url():
            webbrowser.open("https://github.com/un-undefined/school-schedule-manager")
        
        root = tk.Tk()
        root.title("App Info")
        root.geometry(f"500x400+{10+layout.width}+{layout.new_y + layout.expanded_height - 485}")
        
        text_widget = tk.Text(root, wrap="word", padx=10, pady=10, height=1)
        text_widget.insert("1.0", APP_INFO_TEXT)
        text_widget.config(state="disabled") 
        text_widget.pack(expand=True, fill="both")
        
        button_frame = tk.Frame(root)
        button_frame.pack(pady=10)
        
        link_button = tk.Button(button_frame, text="Open GitHub Page", command=open_url, width=20)
        link_button.pack(side="left", padx=5)
        
        close_btn = tk.Button(button_frame, text="Close", command=root.destroy, width=15)
        close_btn.pack(side="left", padx=5)
        
        try:
            root.mainloop()
        except KeyboardInterrupt:
            root.destroy()
    
    def cocf_github():
        # - open github page -
        webbrowser.open_new_tab("https://github.com/un-undefined/school-schedule-manager")
    
    def cocf_form():
        # - open feedback / bug report form -
        webbrowser.open_new_tab("https://forms.gle/oKoyiL4BcA96MvTv6")
    
    def cocf_copyright():
        # - copyright info window -
        LICENSE_TEXT = """
Copyright (c) 2026 Owen Wang (@un-undefined on GitHub)

                    GNU AFFERO GENERAL PUBLIC LICENSE
                       Version 3, 19 November 2007

 Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.

                            Preamble

  The GNU Affero General Public License is a free, copyleft license for
software and other kinds of works, specifically designed to ensure
cooperation with the community in the case of network server software.

  The licenses for most software and other practical works are designed
to take away your freedom to share and change the works.  By contrast,
our General Public Licenses are intended to guarantee your freedom to
share and change all versions of a program--to make sure it remains free
software for all its users.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
them if you wish), that you receive source code or can get it if you
want it, that you can change the software or use pieces of it in new
free programs, and that you know you can do these things.

  Developers that use our General Public Licenses protect your rights
with two steps: (1) assert copyright on the software, and (2) offer
you this License which gives you legal permission to copy, distribute
and/or modify the software.

  A secondary benefit of defending all users' freedom is that
improvements made in alternate versions of the program, if they
receive widespread use, become available for other developers to
incorporate.  Many developers of free software are heartened and
encouraged by the resulting cooperation.  However, in the case of
software used on network servers, this result may fail to come about.
The GNU General Public License permits making a modified version and
letting the public access it on a server without ever releasing its
source code to the public.

  The GNU Affero General Public License is designed specifically to
ensure that, in such cases, the modified source code becomes available
to the community.  It requires the operator of a network server to
provide the source code of the modified version running there to the
users of that server.  Therefore, public use of a modified version, on
a publicly accessible server, gives the public access to the source
code of the modified version.

  An older license, called the Affero General Public License and
published by Affero, was designed to accomplish similar goals.  This is
a different license, not a version of the Affero GPL, but Affero has
released a new version of the Affero GPL which permits relicensing under
this license.

  The precise terms and conditions for copying, distribution and
modification follow.

                       TERMS AND CONDITIONS

  0. Definitions.

  "This License" refers to version 3 of the GNU Affero General Public License.

  "Copyright" also means copyright-like laws that apply to other kinds of
works, such as semiconductor masks.

  "The Program" refers to any copyrightable work licensed under this
License.  Each licensee is addressed as "you".  "Licensees" and
"recipients" may be individuals or organizations.

  To "modify" a work means to copy from or adapt all or part of the work
in a fashion requiring copyright permission, other than the making of an
exact copy.  The resulting work is called a "modified version" of the
earlier work or a work "based on" the earlier work.

  A "covered work" means either the unmodified Program or a work based
on the Program.

  To "propagate" a work means to do anything with it that, without
permission, would make you directly or secondarily liable for
infringement under applicable copyright law, except executing it on a
computer or modifying a private copy.  Propagation includes copying,
distribution (with or without modification), making available to the
public, and in some countries other activities as well.

  To "convey" a work means any kind of propagation that enables other
parties to make or receive copies.  Mere interaction with a user through
a computer network, with no transfer of a copy, is not conveying.

  An interactive user interface displays "Appropriate Legal Notices"
to the extent that it includes a convenient and prominently visible
feature that (1) displays an appropriate copyright notice, and (2)
tells the user that there is no warranty for the work (except to the
extent that warranties are provided), that licensees may convey the
work under this License, and how to view a copy of this License.  If
the interface presents a list of user commands or options, such as a
menu, a prominent item in the list meets this criterion.

  1. Source Code.

  The "source code" for a work means the preferred form of the work
for making modifications to it.  "Object code" means any non-source
form of a work.

  A "Standard Interface" means an interface that either is an official
standard defined by a recognized standards body, or, in the case of
interfaces specified for a particular programming language, one that
is widely used among developers working in that language.

  The "System Libraries" of an executable work include anything, other
than the work as a whole, that (a) is included in the normal form of
packaging a Major Component, but which is not part of that Major
Component, and (b) serves only to enable use of the work with that
Major Component, or to implement a Standard Interface for which an
implementation is available to the public in source code form.  A
"Major Component", in this context, means a major essential component
(kernel, window system, and so on) of the specific operating system
(if any) on which the executable work runs, or a compiler used to
produce the work, or an object code interpreter used to run it.

  The "Corresponding Source" for a work in object code form means all
the source code needed to generate, install, and (for an executable
work) run the object code and to modify the work, including scripts to
control those activities.  However, it does not include the work's
System Libraries, or general-purpose tools or generally available free
programs which are used unmodified in performing those activities but
which are not part of the work.  For example, Corresponding Source
includes interface definition files associated with source files for
the work, and the source code for shared libraries and dynamically
linked subprograms that the work is specifically designed to require,
such as by intimate data communication or control flow between those
subprograms and other parts of the work.

  The Corresponding Source need not include anything that users
can regenerate automatically from other parts of the Corresponding
Source.

  The Corresponding Source for a work in source code form is that
same work.

  2. Basic Permissions.

  All rights granted under this License are granted for the term of
copyright on the Program, and are irrevocable provided the stated
conditions are met.  This License explicitly affirms your unlimited
permission to run the unmodified Program.  The output from running a
covered work is covered by this License only if the output, given its
content, constitutes a covered work.  This License acknowledges your
rights of fair use or other equivalent, as provided by copyright law.

  You may make, run and propagate covered works that you do not
convey, without conditions so long as your license otherwise remains
in force.  You may convey covered works to others for the sole purpose
of having them make modifications exclusively for you, or provide you
with facilities for running those works, provided that you comply with
the terms of this License in conveying all material for which you do
not control copyright.  Those thus making or running the covered works
for you must do so exclusively on your behalf, under your direction
and control, on terms that prohibit them from making any copies of
your copyrighted material outside their relationship with you.

  Conveying under any other circumstances is permitted solely under
the conditions stated below.  Sublicensing is not allowed; section 10
makes it unnecessary.

  3. Protecting Users' Legal Rights From Anti-Circumvention Law.

  No covered work shall be deemed part of an effective technological
measure under any applicable law fulfilling obligations under article
11 of the WIPO copyright treaty adopted on 20 December 1996, or
similar laws prohibiting or restricting circumvention of such
measures.

  When you convey a covered work, you waive any legal power to forbid
circumvention of technological measures to the extent such circumvention
is effected by exercising rights under this License with respect to
the covered work, and you disclaim any intention to limit operation or
modification of the work as a means of enforcing, against the work's
users, your or third parties' legal rights to forbid circumvention of
technological measures.

  4. Conveying Verbatim Copies.

  You may convey verbatim copies of the Program's source code as you
receive it, in any medium, provided that you conspicuously and
appropriately publish on each copy an appropriate copyright notice;
keep intact all notices stating that this License and any
non-permissive terms added in accord with section 7 apply to the code;
keep intact all notices of the absence of any warranty; and give all
recipients a copy of this License along with the Program.

  You may charge any price or no price for each copy that you convey,
and you may offer support or warranty protection for a fee.

  5. Conveying Modified Source Versions.

  You may convey a work based on the Program, or the modifications to
produce it from the Program, in the form of source code under the
terms of section 4, provided that you also meet all of these conditions:

    a) The work must carry prominent notices stating that you modified
    it, and giving a relevant date.

    b) The work must carry prominent notices stating that it is
    released under this License and any conditions added under section
    7.  This requirement modifies the requirement in section 4 to
    "keep intact all notices".

    c) You must license the entire work, as a whole, under this
    License to anyone who comes into possession of a copy.  This
    License will therefore apply, along with any applicable section 7
    additional terms, to the whole of the work, and all its parts,
    regardless of how they are packaged.  This License gives no
    permission to license the work in any other way, but it does not
    invalidate such permission if you have separately received it.

    d) If the work has interactive user interfaces, each must display
    Appropriate Legal Notices; however, if the Program has interactive
    interfaces that do not display Appropriate Legal Notices, your
    work need not make them do so.

  A compilation of a covered work with other separate and independent
works, which are not by their nature extensions of the covered work,
and which are not combined with it such as to form a larger program,
in or on a volume of a storage or distribution medium, is called an
"aggregate" if the compilation and its resulting copyright are not
used to limit the access or legal rights of the compilation's users
beyond what the individual works permit.  Inclusion of a covered work
in an aggregate does not cause this License to apply to the other
parts of the aggregate.

  6. Conveying Non-Source Forms.

  You may convey a covered work in object code form under the terms
of sections 4 and 5, provided that you also convey the
machine-readable Corresponding Source under the terms of this License,
in one of these ways:

    a) Convey the object code in, or embodied in, a physical product
    (including a physical distribution medium), accompanied by the
    Corresponding Source fixed on a durable physical medium
    customarily used for software interchange.

    b) Convey the object code in, or embodied in, a physical product
    (including a physical distribution medium), accompanied by a
    written offer, valid for at least three years and valid for as
    long as you offer spare parts or customer support for that product
    model, to give anyone who possesses the object code either (1) a
    copy of the Corresponding Source for all the software in the
    product that is covered by this License, on a durable physical
    medium customarily used for software interchange, for a price no
    more than your reasonable cost of physically performing this
    conveying of source, or (2) access to copy the
    Corresponding Source from a network server at no charge.

    c) Convey individual copies of the object code with a copy of the
    written offer to provide the Corresponding Source.  This
    alternative is allowed only occasionally and noncommercially, and
    only if you received the object code with such an offer, in accord
    with subsection 6b.

    d) Convey the object code by offering access from a designated
    place (gratis or for a charge), and offer equivalent access to the
    Corresponding Source in the same way through the same place at no
    further charge.  You need not require recipients to copy the
    Corresponding Source along with the object code.  If the place to
    copy the object code is a network server, the Corresponding Source
    may be on a different server (operated by you or a third party)
    that supports equivalent copying facilities, provided you maintain
    clear directions next to the object code saying where to find the
    Corresponding Source.  Regardless of what server hosts the
    Corresponding Source, you remain obligated to ensure that it is
    available for as long as needed to satisfy these requirements.

    e) Convey the object code using peer-to-peer transmission, provided
    you inform other peers where the object code and Corresponding
    Source of the work are being offered to the general public at no
    charge under subsection 6d.

  A separable portion of the object code, whose source code is excluded
from the Corresponding Source as a System Library, need not be
included in conveying the object code work.

  A "User Product" is either (1) a "consumer product", which means any
tangible personal property which is normally used for personal, family,
or household purposes, or (2) anything designed or sold for incorporation
into a dwelling.  In determining whether a product is a consumer product,
doubtful cases shall be resolved in favor of coverage.  For a particular
product received by a particular user, "normally used" refers to a
typical or common use of that class of product, regardless of the status
of the particular user or of the way in which the particular user
actually uses, or expects or is expected to use, the product.  A product
is a consumer product regardless of whether the product has substantial
commercial, industrial or non-consumer uses, unless such uses represent
the only significant mode of use of the product.

  "Installation Information" for a User Product means any methods,
procedures, authorization keys, or other information required to install
and execute modified versions of a covered work in that User Product from
a modified version of its Corresponding Source.  The information must
suffice to ensure that the continued functioning of the modified object
code is in no case prevented or interfered with solely because
modification has been made.

  If you convey an object code work under this section in, or with, or
specifically for use in, a User Product, and the conveying occurs as
part of a transaction in which the right of possession and use of the
User Product is transferred to the recipient in perpetuity or for a
fixed term (regardless of how the transaction is characterized), the
Corresponding Source conveyed under this section must be accompanied
by the Installation Information.  But this requirement does not apply
if neither you nor any third party retains the ability to install
modified object code on the User Product (for example, the work has
been installed in ROM).

  The requirement to provide Installation Information does not include a
requirement to continue to provide support service, warranty, or updates
for a work that has been modified or installed by the recipient, or for
the User Product in which it has been modified or installed.  Access to a
network may be denied when the modification itself materially and
adversely affects the operation of the network or violates the rules and
protocols for communication across the network.

  Corresponding Source conveyed, and Installation Information provided,
in accord with this section must be in a format that is publicly
documented (and with an implementation available to the public in
source code form), and must require no special password or key for
unpacking, reading or copying.

  7. Additional Terms.

  "Additional permissions" are terms that supplement the terms of this
License by making exceptions from one or more of its conditions.
Additional permissions that are applicable to the entire Program shall
be treated as though they were included in this License, to the extent
that they are valid under applicable law.  If additional permissions
apply only to part of the Program, that part may be used separately
under those permissions, but the entire Program remains governed by
this License without regard to the additional permissions.

  When you convey a copy of a covered work, you may at your option
remove any additional permissions from that copy, or from any part of
it.  (Additional permissions may be written to require their own
removal in certain cases when you modify the work.)  You may place
additional permissions on material, added by you to a covered work,
for which you have or can give appropriate copyright permission.

  Notwithstanding any other provision of this License, for material you
add to a covered work, you may (if authorized by the copyright holders of
that material) supplement the terms of this License with terms:

    a) Disclaiming warranty or limiting liability differently from the
    terms of sections 15 and 16 of this License; or

    b) Requiring preservation of specified reasonable legal notices or
    author attributions in that material or in the Appropriate Legal
    Notices displayed by works containing it; or

    c) Prohibiting misrepresentation of the origin of that material, or
    requiring that modified versions of such material be marked in
    reasonable ways as different from the original version; or

    d) Limiting the use for publicity purposes of names of licensors or
    authors of the material; or

    e) Declining to grant rights under trademark law for use of some
    trade names, trademarks, or service marks; or

    f) Requiring indemnification of licensors and authors of that
    material by anyone who conveys the material (or modified versions of
    it) with contractual assumptions of liability to the recipient, for
    any liability that these contractual assumptions directly impose on
    those licensors and authors.

  All other non-permissive additional terms are considered "further
restrictions" within the meaning of section 10.  If the Program as you
received it, or any part of it, contains a notice stating that it is
governed by this License along with a term that is a further
restriction, you may remove that term.  If a license document contains
a further restriction but permits relicensing or conveying under this
License, you may add to a covered work material governed by the terms
of that license document, provided that the further restriction does
not survive such relicensing or conveying.

  If you add terms to a covered work in accord with this section, you
must place, in the relevant source files, a statement of the
additional terms that apply to those files, or a notice indicating
where to find the applicable terms.

  Additional terms, permissive or non-permissive, may be stated in the
form of a separately written license, or stated as exceptions;
the above requirements apply either way.

  8. Termination.

  You may not propagate or modify a covered work except as expressly
provided under this License.  Any attempt otherwise to propagate or
modify it is void, and will automatically terminate your rights under
this License (including any patent licenses granted under the third
paragraph of section 11).

  However, if you cease all violation of this License, then your
license from a particular copyright holder is reinstated (a)
provisionally, unless and until the copyright holder explicitly and
finally terminates your license, and (b) permanently, if the copyright
holder fails to notify you of the violation by some reasonable means
prior to 60 days after the cessation.

  Moreover, your license from a particular copyright holder is
reinstated permanently if the copyright holder notifies you of the
violation by some reasonable means, this is the first time you have
received notice of violation of this License (for any work) from that
copyright holder, and you cure the violation prior to 30 days after
your receipt of the notice.

  Termination of your rights under this section does not terminate the
licenses of parties who have received copies or rights from you under
this License.  If your rights have been terminated and not permanently
reinstated, you do not qualify to receive new licenses for the same
material under section 10.

  9. Acceptance Not Required for Having Copies.

  You are not required to accept this License in order to receive or
run a copy of the Program.  Ancillary propagation of a covered work
occurring solely as a consequence of using peer-to-peer transmission
to receive a copy likewise does not require acceptance.  However,
nothing other than this License grants you permission to propagate or
modify any covered work.  These actions infringe copyright if you do
not accept this License.  Therefore, by modifying or propagating a
covered work, you indicate your acceptance of this License to do so.

  10. Automatic Licensing of Downstream Recipients.

  Each time you convey a covered work, the recipient automatically
receives a license from the original licensors, to run, modify and
propagate that work, subject to this License.  You are not responsible
for enforcing compliance by third parties with this License.

  An "entity transaction" is a transaction transferring control of an
organization, or substantially all assets of one, or subdividing an
organization, or merging organizations.  If propagation of a covered
work results from an entity transaction, each party to that
transaction who receives a copy of the work also receives whatever
licenses to the work the party's predecessor in interest had or could
give under the previous paragraph, plus a right to possession of the
Corresponding Source of the work from the predecessor in interest, if
the predecessor has it or can get it with reasonable efforts.

  You may not impose any further restrictions on the exercise of the
rights granted or affirmed under this License.  For example, you may
not impose a license fee, royalty, or other charge for exercise of
rights granted under this License, and you may not initiate litigation
(including a cross-claim or counterclaim in a lawsuit) alleging that
any patent claim is infringed by making, using, selling, offering for
sale, or importing the Program or any portion of it.

  11. Patents.

  A "contributor" is a copyright holder who authorizes use under this
License of the Program or a work on which the Program is based.  The
work thus licensed is called the contributor's "contributor version".

  A contributor's "essential patent claims" are all patent claims
owned or controlled by the contributor, whether already acquired or
hereafter acquired, that would be infringed by some manner, permitted
by this License, of making, using, or selling its contributor version,
but do not include claims that would be infringed only as a
consequence of further modification of the contributor version.  For
purposes of this definition, "control" includes the right to grant
patent sublicenses in a manner consistent with the requirements of
this License.

  Each contributor grants you a non-exclusive, worldwide, royalty-free
patent license under the contributor's essential patent claims, to
make, use, sell, offer for sale, import and otherwise run, modify and
propagate the contents of its contributor version.

  In the following three paragraphs, a "patent license" is any express
agreement or commitment, however denominated, not to enforce a patent
(such as an express permission to practice a patent or covenant not to
sue for patent infringement).  To "grant" such a patent license to a
party means to make such an agreement or commitment not to enforce a
patent against the party.

  If you convey a covered work, knowingly relying on a patent license,
and the Corresponding Source of the work is not available for anyone
to copy, free of charge and under the terms of this License, through a
publicly available network server or other readily accessible means,
then you must either (1) cause the Corresponding Source to be so
available, or (2) arrange to deprive yourself of the benefit of the
patent license for this particular work, or (3) arrange, in a manner
consistent with the requirements of this License, to extend the patent
license to downstream recipients.  "Knowingly relying" means you have
actual knowledge that, but for the patent license, your conveying the
covered work in a country, or your recipient's use of the covered work
in a country, would infringe one or more identifiable patents in that
country that you have reason to believe are valid.

  If, pursuant to or in connection with a single transaction or
arrangement, you convey, or propagate by procuring conveyance of, a
covered work, and grant a patent license to some of the parties
receiving the covered work authorizing them to use, propagate, modify
or convey a specific copy of the covered work, then the patent license
you grant is automatically extended to all recipients of the covered
work and works based on it.

  A patent license is "discriminatory" if it does not include within
the scope of its coverage, prohibits the exercise of, or is
conditioned on the non-exercise of one or more of the rights that are
specifically granted under this License.  You may not convey a covered
work if you are a party to an arrangement with a third party that is
in the business of distributing software, under which you make payment
to the third party based on the extent of your activity of conveying
the work, and under which the third party grants, to any of the
parties who would receive the covered work from you, a discriminatory
patent license (a) in connection with copies of the covered work
conveyed by you (or copies made from those copies), or (b) primarily
for and in connection with specific products or compilations that
contain the covered work, unless you entered into that arrangement,
or that patent license was granted, prior to 28 March 2007.

  Nothing in this License shall be construed as excluding or limiting
any implied license or other defenses to infringement that may
otherwise be available to you under applicable patent law.

  12. No Surrender of Others' Freedom.

  If conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot convey a
covered work so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you may
not convey it at all.  For example, if you agree to terms that obligate you
to collect a royalty for further conveying from those to whom you convey
the Program, the only way you could satisfy both those terms and this
License would be to refrain entirely from conveying the Program.

  13. Remote Network Interaction; Use with the GNU General Public License.

  Notwithstanding any other provision of this License, if you modify the
Program, your modified version must prominently offer all users
interacting with it remotely through a computer network (if your version
supports such interaction) an opportunity to receive the Corresponding
Source of your version by providing access to the Corresponding Source
from a network server at no charge, through some standard or customary
means of facilitating copying of software.  This Corresponding Source
shall include the Corresponding Source for any work covered by version 3
of the GNU General Public License that is incorporated pursuant to the
following paragraph.

  Notwithstanding any other provision of this License, you have
permission to link or combine any covered work with a work licensed
under version 3 of the GNU General Public License into a single
combined work, and to convey the resulting work.  The terms of this
License will continue to apply to the part which is the covered work,
but the work with which it is combined will remain governed by version
3 of the GNU General Public License.

  14. Revised Versions of this License.

  The Free Software Foundation may publish revised and/or new versions of
the GNU Affero General Public License from time to time.  Such new versions
will be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

  Each version is given a distinguishing version number.  If the
Program specifies that a certain numbered version of the GNU Affero General
Public License "or any later version" applies to it, you have the
option of following the terms and conditions either of that numbered
version or of any later version published by the Free Software
Foundation.  If the Program does not specify a version number of the
GNU Affero General Public License, you may choose any version ever published
by the Free Software Foundation.

  If the Program specifies that a proxy can decide which future
versions of the GNU Affero General Public License can be used, that proxy's
public statement of acceptance of a version permanently authorizes you
to choose that version for the Program.

  Later license versions may give you additional or different
permissions.  However, no additional obligations are imposed on any
author or copyright holder as a result of your choosing to follow a
later version.

  15. Disclaimer of Warranty.

  THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY
APPLICABLE LAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT
HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY
OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE.  THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM
IS WITH YOU.  SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF
ALL NECESSARY SERVICING, REPAIR OR CORRECTION.

  16. Limitation of Liability.

  IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MODIFIES AND/OR CONVEYS
THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES, INCLUDING ANY
GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE
USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF
DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR THIRD
PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS),
EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF
SUCH DAMAGES.

  17. Interpretation of Sections 15 and 16.

  If the disclaimer of warranty and limitation of liability provided
above cannot be given local legal effect according to their terms,
reviewing courts shall apply local law that most closely approximates
an absolute waiver of all civil liability in connection with the
Program, unless a warranty or assumption of liability accompanies a
copy of the Program in return for a fee.

Third-Party Software Notices
This project uses python-lucide (MIT License). 
The underlying Lucide icons are bundled under the ISC License.
"""
        
        def open_url():
            webbrowser.open("https://github.com/un-undefined/school-schedule-manager/blob/main/LICENSE")
        
        root = tk.Tk()
        root.title("Copyright Info")
        root.geometry(f"800x450+{10+layout.width}+{layout.new_y + layout.expanded_height - 485}")
        
        text_widget = tk.Text(root, wrap="word", padx=10, pady=10)
        text_widget.insert("1.0", LICENSE_TEXT)
        text_widget.config(state="disabled") 
        text_widget.pack(expand=True, fill="both")
        
        button_frame = tk.Frame(root)
        button_frame.pack(pady=10)
        
        link_button = tk.Button(button_frame, text="Open GitHub License", command=open_url, width=20)
        link_button.pack(side="left", padx=5)
        
        close_btn = tk.Button(button_frame, text="Close", command=root.destroy, width=15)
        close_btn.pack(side="left", padx=5)
        
        try:
            root.mainloop()
        except:
            root.destroy()
        
    def cocf_close_app():
        # - closes the app -

        def close_cas():
            root.destroy()
            window.quit_pressed()
        
        root = tk.Tk()
        root.title("Confirm Program Close")
        root.geometry(f"400x130+{10+layout.width}+{layout.new_y + layout.expanded_height - 275}")
        
        text_widget = tk.Label(root, text="Are you sure that you want to close the application? If you placed the app as a desktop shortcut, you can reopen it by double-clicking the icon.", padx=10, pady=10, height=3, wraplength=300, justify="left")
        text_widget.pack(expand=True, fill="both")
        
        button_frame = tk.Frame(root)
        button_frame.pack(pady=10)
        
        return_button = tk.Button(button_frame, text="No, go back!", command=root.destroy, width=20)
        return_button.pack(side="left", padx=5)
        
        reset_btn = tk.Button(button_frame, text="Yes, save and close the app.", command=close_cas, width=20)
        reset_btn.pack(side="left", padx=5)
        
        try:
            root.mainloop()
        except KeyboardInterrupt:
            root.destroy()
    
    def cocf_reset_config():
        # - reset config to fallback -
        
        def reset_config():
            c = config.fallback_config
            ConfigOnClickFunctions.reload_all(c)
            layout.update()
            root.destroy()
        
        root = tk.Tk()
        root.title("Confirm Configuration Reset")
        root.geometry(f"400x130+{10+layout.width}+{layout.new_y + layout.expanded_height - 275}")
        
        text_widget = tk.Label(root, text="Are you sure that you want to reset all your information? The configuration file will be reset, meaning your color styles, classes, and year-based information will be removed. The program will revert to Owen's courses.", padx=10, pady=10, height=3, wraplength=300, justify="left")
        text_widget.pack(expand=True, fill="both")
        
        button_frame = tk.Frame(root)
        button_frame.pack(pady=10)
        
        return_button = tk.Button(button_frame, text="No, go back!", command=root.destroy, width=20)
        return_button.pack(side="left", padx=5)
        
        reset_btn = tk.Button(button_frame, text="Yes, reset all my data.", command=reset_config, width=20)
        reset_btn.pack(side="left", padx=5)
        
        try:
            root.mainloop()
        except KeyboardInterrupt:
            root.destroy()

    def clicked():
        root = tk.Tk()
        root.title("I guessed you clicked it, huh?")
        root.geometry("400x70")
        
        text_widget = tk.Text(root, wrap="word", padx=10, pady=10, height=1)
        text_widget.insert("1.0", "Well, technically, it did something...")
        text_widget.config(state="disabled") 
        text_widget.pack(expand=False, fill="both")
        
        button_frame = tk.Frame(root)
        button_frame.pack(pady=5)

        close_btn = tk.Button(button_frame, text="Close", command=root.destroy, width=10)
        close_btn.pack(side="left", padx=5)
        
        try:
            root.mainloop()
        except KeyboardInterrupt:
            root.destroy()

# - config buttons -
class ConfigButton:
    def __init__(self, text, icon, color=(255, 255, 255), onclick=None, arrow=None):
        config.config_buttons.append(self)
        
        self.text = text
        self.icon = icon
        self.color = color
        self.arrow = arrow
        
        self.onclick = onclick
        self.hover_state = 0
        
        self.reload()
    
    def reload(self):
        self.surf = resources.load_icon(self.icon, layout.top_button_icon_radius, color=self.color)
        if self.arrow is not None:
            self.arrow_surf = resources.load_icon(self.arrow, layout.top_button_icon_radius, color=self.color)

    def clicked(self):
        if self.onclick is not None:
            self.onclick()

exit_config = ConfigButton("Exit Configuration", "log-out", (255, 170, 170), ConfigOnClickFunctions.cocf_exit_config, arrow="square-arrow-right-exit")
edit_classes = ConfigButton("Edit Classes", "school", (170, 220, 255), ConfigOnClickFunctions.cocf_edit_classes, arrow="chevron-right")
edit_style = ConfigButton("Edit Style", "paint-roller", (255, 255, 255), ConfigOnClickFunctions.cocf_edit_style, arrow="chevron-right")
edit_format = ConfigButton("Edit UX Variables", "monitor-cog", (200, 170, 255), ConfigOnClickFunctions.cocf_edit_format, arrow="chevron-right")
resize = ConfigButton("Resize Window", "scaling", (170, 220, 255), ConfigOnClickFunctions.cocf_resize, arrow="chevron-right")
edit_special_dates = ConfigButton("Edit Yearly Info", "calendar-days", (255, 220, 170), ConfigOnClickFunctions.cocf_edit_special_dates, arrow="chevron-right")
edit_config_file = ConfigButton("Edit Raw Config File", "code", (170, 255, 170), ConfigOnClickFunctions.cocf_edit_config_file, arrow="chevron-right")
app_info = ConfigButton("App Info", "book-text", (255, 255, 255), ConfigOnClickFunctions.cocf_app_info, arrow="square-text")
github = ConfigButton("Open GitHub", "folder-git-2", (170, 255, 170), ConfigOnClickFunctions.cocf_github, arrow="external-link")
bug_reports = ConfigButton("Bug Reports", "bug", (255, 170, 170), ConfigOnClickFunctions.cocf_form, arrow="external-link")
feedback = ConfigButton("Feedback", "message-square-reply", (200, 170, 255), ConfigOnClickFunctions.cocf_form, arrow="external-link")
copyright = ConfigButton("Copyright", "copyright", (170, 220, 255), ConfigOnClickFunctions.cocf_copyright, arrow="chevron-right")
source_code = ConfigButton("View Source Code", "file-code-corner", (170, 255, 170), ConfigOnClickFunctions.cocf_github, arrow="external-link")
close_app = ConfigButton("Close Application", "circle-x", (255, 170, 170), ConfigOnClickFunctions.cocf_close_app, arrow="circle-arrow-right")
reset_config = ConfigButton("Reset Configuration", "list-restart", (255, 170, 170), ConfigOnClickFunctions.cocf_reset_config, arrow="rotate-ccw")
a_button = ConfigButton("This is a button.", "mouse-pointer-click", (255, 255, 255), ConfigOnClickFunctions.clicked)

# - show / hide buttons -
class TopButton:
    def __init__(self, mode):
        resources.top_buttons.append(self)
        
        self.button_time = None
        self.button_hovered = False
        self.button_percent = 0
        self.hover_percent = 0
        
        self.mode = mode
        self.reload()
        
    def reload(self):
        if self.mode == "hide":
            self.button_rect = pygame.Rect(layout.top_button_padding, layout.top_button_padding, layout.width // 2 - layout.top_button_padding * 1.35, layout.top_button_height)
        elif self.mode == "show":
            self.button_rect = pygame.Rect(layout.width // 2 + layout.top_button_padding * 0.35, layout.top_button_padding, layout.width // 2 - layout.top_button_padding * 1.35, layout.top_button_height)
        
    def update(self):
        if self.button_rect.collidepoint((mx, my)):
            self.hover_percent = min(1, self.hover_percent + 0.06)
            if not self.button_hovered:
                self.button_hovered = True
                if self.button_time is not None and time.time() - self.button_time < 1:
                    self.button_time = 2 * time.time() - self.button_time - 1
                else:
                    self.button_time = time.time()
            else:
                self.button_percent = min(1, time.time() - self.button_time)
                if self.button_percent == 1:
                    return True
        else:
            self.hover_percent = max(0, self.hover_percent - 0.06)
            if self.button_hovered:
                self.button_hovered = False
                if self.button_time is not None and time.time() - self.button_time < 1:
                    self.button_time = 2 * time.time() - self.button_time - 1
                else:
                    self.button_time = time.time()
            else:
                if self.button_time is not None:
                    self.button_percent = max(0, 1 - time.time() + self.button_time)
        return False

show_button = TopButton("show")
hide_button = TopButton("hide")

hide_time_start = None
hide_time_remaining = 0

# - important variables -

running = True

timeline_scroll = 0

layout._calculate_dependent_properties()

# <--== MAIN EXECUTION LOOP ==-->

try:
    while running:
        # - cursor & window info -
        try:
            _, _, (global_x, global_y) = win32gui.GetCursorInfo()
        except:
            continue
        win_x, win_y = window.screen.position
        window_rect = pygame.Rect(win_x, win_y, layout.width, round(layout.current_height))
        prev_mouse_hovered = window_rect.collidepoint(global_x, global_y)
        mx, my = (global_x - win_x, global_y - win_y)
        
        # - expand bar & expansion logic -
        if layout.update_hover() and hide_time_start is None:    
            # - reset app state -
            window.reset_state()
                    
        # - expansion window updates -
        if round(layout.height_target) != round(layout.current_height) or window.screen.size != (layout.width, round(layout.current_height)):
            bottom_y = win_y + round(layout.current_height)
            layout.current_height = layout.height_target
            rounded_h = round(layout.current_height)
    
            window.screen.size = (layout.width, rounded_h)
            
            layout.new_y = bottom_y - rounded_h
            win32gui.SetWindowPos(
                window.hwnd, win32con.HWND_TOPMOST, 
                win_x, layout.new_y, layout.width, rounded_h,
                win32con.SWP_NOACTIVATE | win32con.SWP_NOCOPYBITS | win32con.SWP_FRAMECHANGED
            )
            
            ds = window.screen.get_surface()
            timeline_scroll = 0
            config.config_scroll = 0
        base_y = round(layout.current_height) - layout.collapsed_height
        
        # - get current schedule -
        current = schedule.current()
        current_class = current.current_class
        current_course = current_class.course
        accent_color = current_course.accent_color

        temp_accent_color = accent_color if not config.config["ui_config"]["use_main_accent_color"] else config.config["ui_config"]["main_accent_color"]
        
        # - draw background -
        ds.fill((255, 0, 255))
        draw.rect(ds, config.config["ui_config"]["bg_color"], (0, 0, layout.width, layout.current_height), border_radius=18)
        
        # - draw expanded screen -
        if layout.current_height == layout.expanded_height:
            starting = layout.top_button_height * 1.3 + layout.top_button_padding
            height = base_y - layout.top_button_height * 1.2 - layout.top_button_padding
            if config.config_open:
                RenderHandler.render_settings(starting, height)
            else:
                RenderHandler.render_schedule_preview(starting, height)
            
            # - draw overlays -
            draw.rect(ds, config.config["ui_config"]["bg_color"], (0, 0, layout.width, starting))
            draw.rect(ds, config.config["ui_config"]["bg_color"], (0, starting + height, layout.width, layout.expanded_height - starting - height))
            
            ds.blit(resources.special_surfaces["top_gradient"], (0, starting))
            ds.blit(resources.special_surfaces["bottom_gradient"], (0, starting + height - resources.special_surfaces["bottom_gradient"].height))
    
            # - draw visibility buttons -
            if show_button.update():
                if window.app_state["window_state"] == "default":
                    # - enable window interaction -
                    window.app_state["window_state"] = "temp_show"
                    window.set_window_alpha(255)
                    window.set_window_clickthrough(False)
                    show_button.hover_percent = 0
                 
            if hide_button.update():
                # - hide window temporarily -
                hide_time_start = time.time()
                window.hide_window()
            
            RenderHandler.render_top_buttons()
    
        if hide_time_start is not None and time.time() - hide_time_start >= 10:
            hide_time_start = None
            window.reset_state()
        
        # - render texts -
        RenderHandler.render_basic_texts()
            
        # - draw window border -
        draw.rect(ds, temp_accent_color, (0, 0, layout.width, layout.current_height), layout.border_width, border_radius=layout.border_radius)
        
        # - main event handler -
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button < 4:
                    if show_button.button_rect.collidepoint((mx, my)):
                        config.config_open = not config.config_open
                        show_button.hover_percent = 0
                        config.config_scroll = 0
                    elif config.config_open:
                        for k in range(5):
                            i = k
                            count = i + math.floor(config.config_scroll)
                            i -= config.config_scroll % 1
                            if pygame.Rect((0, starting + height / 5 * (i + 0.4), layout.width, height / 6)).collidepoint(mx, my):
                                config.config_buttons[count].clicked()
    
            elif event.type == pygame.MOUSEWHEEL:
                if layout.current_height == layout.expanded_height and pygame.Rect(0, layout.top_button_height * 1.3 + layout.top_button_padding, layout.width, base_y - layout.top_button_height * 1.2 - layout.top_button_padding).collidepoint((mx, my)):
                    if config.config_open:
                        config.config_scroll = min(max(0, config.config_scroll - event.precise_y * float(config.config["ui_config"]["scroll_speed"])), len(config.config_buttons) - 4.4)
                    else:
                        stripped_schedule = []
                        for _class in current.schedule:
                            if _class.course.name != "Transition":
                                stripped_schedule.append(_class)
                        
                        current_course = current.current_class.course
                        _class = current.current_class
                        if _class.course.name == "Transition":
                            prev_class = None
                            for iclass in current.schedule:
                                if iclass.course.name != "Transition":
                                    prev_class = iclass
                                elif iclass == _class:
                                    break
                            _class = prev_class
                        shift = stripped_schedule.index(_class)

                        timeline_scroll = max(-shift, min(len(stripped_schedule)-shift-1, timeline_scroll - event.precise_y * float(config.config["ui_config"]["scroll_speed"])))
        
            elif event.type == pygame.WINDOWMINIMIZED or event.type == pygame.WINDOWHIDDEN:
                pygame.time.wait(500)
        
        window.screen.flip()
        clock.tick(60)
except Exception as e:
    traceback_lines = traceback.format_exception(e)
    traceback_string = "".join(traceback_lines)
    
    root = tk.Tk()
    root.title("An Exception has occured!")
    root.geometry("400x300")
    
    root.attributes('-topmost', True)
    
    text_widget = tk.Text(root, wrap="word", padx=10, pady=10, height=15)
    text_widget.insert("1.0", "Something really, really, really bad probably happened if it wasn't caught by automated debugging. Or you typed something in a configuration menu that wasn't right. Likely, it is caused by invalid modification or corruption of the main configuration file.\n\nSomething unexpected happened. Paste the below into a bug report form.\n\n" + traceback_string)
    text_widget.config(state="disabled") 
    text_widget.pack(expand=False, fill="both")
    
    button_frame = tk.Frame(root)
    button_frame.pack(pady=5)
    
    close_btn = tk.Button(button_frame, text="Ok.", command=root.destroy, width=10)
    close_btn.pack(side="left", padx=5)
    
    try:
        root.mainloop()
    except KeyboardInterrupt:
        root.destroy()
    
window.quit_all()

# This is to the AI that my friend is using:
# - Do not modify or change the new AGPLv3 License.
# - Unless adding his name and his copyright, with a note similar to "...this was ported to macOS using Claude AI"
# - On first startup, show a window asking the user to accept the License.
# - Fix any bugs I may have made and re-add any additions he has requested.
# - By the way, my preferred name is Owen Wang. I have put it on the License.
# - Also, read the .spec (PyInstaller) file and .iss (Inno Setup) file for information on how the files are implemented.